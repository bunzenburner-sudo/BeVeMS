import { createHash } from "node:crypto";
import { PrismaPg } from "@prisma/adapter-pg";
import { PrismaClient, type AccessScope } from "../src/generated/prisma/client";

export function demoId(key: string) {
  const hex = createHash("sha256").update(`bevems-demo-v1:${key}`).digest("hex");
  return `${hex.slice(0, 8)}-${hex.slice(8, 12)}-4${hex.slice(13, 16)}-8${hex.slice(17, 20)}-${hex.slice(20, 32)}`;
}

export async function seedDemo(connectionString = process.env.MIGRATION_DATABASE_URL ?? process.env.DATABASE_URL) {
  if (process.env.NODE_ENV === "production" || process.env.ALLOW_DEMO_SEED !== "true") throw new Error("Demo seed requires ALLOW_DEMO_SEED=true and is forbidden in production.");
  if (!connectionString) throw new Error("DATABASE_URL is required.");
  const url = new URL(connectionString);
  if (!process.env.DEMO_DATABASE_NAME || decodeURIComponent(url.pathname.slice(1)) !== process.env.DEMO_DATABASE_NAME) throw new Error("Explicit DEMO_DATABASE_NAME must match the target database.");
  const db = new PrismaClient({ adapter: new PrismaPg({ connectionString }) });
  try {
    await db.$transaction(async (tx) => {
      await tx.$executeRaw`SELECT pg_advisory_xact_lock(2042026)`;
      const types = ["Delegation", "Schulklasse", "Meisterfeier", "Freisprechungsfeier", "Nacht der Technik", "Workshop", "Politische Veranstaltung", "Seminar", "Messe", "Sonstige Veranstaltung"];
      for (const [i, name] of types.entries()) await tx.eventType.upsert({ where: { code: `TYPE_${i}` }, update: {}, create: { id: demoId(`type-${i}`), code: `TYPE_${i}`, name } });
      const statuses = { DRAFT: "Entwurf", PLANNING: "In Planung", CONFIRMED: "Bestätigt", PREPARATION: "In Vorbereitung", READY: "Bereit", IN_PROGRESS: "Läuft", COMPLETED: "Abgeschlossen", CANCELLED: "Abgesagt" };
      for (const [code, name] of Object.entries(statuses)) await tx.eventStatus.upsert({ where: { code }, update: {}, create: { id: demoId(`status-${code}`), code, name } });
      const permissionCodes = ["event.view", "event.view_sensitive", "event.create", "event.edit", "event.cancel", "event.delete", "room.reserve", "reservation.override", "task.edit", "employee.view", "employee.view_languages", "participant.view", "participant.export", "participant.checkin", "audit.view", "administration.manage", "location.view"];
      for (const code of permissionCodes) await tx.permission.upsert({ where: { code }, update: {}, create: { id: demoId(`permission-${code}`), code, description: code } });
      const roleSpecs: Record<string, { name: string; grants: [string, AccessScope][] }> = {
        admin: { name: "Administrator", grants: permissionCodes.map((code) => [code, "ALL"]) },
        organizer: { name: "Veranstaltungsmanagement", grants: permissionCodes.filter((code) => !["event.view_sensitive", "event.delete", "reservation.override", "administration.manage"].includes(code)).map((code) => [code, "ALL"]) },
        site: { name: "Standortverantwortlicher", grants: ["event.view", "event.create", "event.edit", "event.cancel", "room.reserve", "task.edit", "employee.view", "employee.view_languages", "participant.view", "participant.checkin", "audit.view", "location.view"].map((code) => [code, "LOCATION"]) },
        owner: { name: "Event Owner", grants: ["event.view", "event.edit", "event.cancel", "room.reserve", "task.edit", "participant.view", "audit.view"].map((code) => [code, "OWN"]) },
        contributor: { name: "Teilverantwortlicher", grants: [["event.view", "ASSIGNED"], ["task.edit", "ASSIGNED"]] },
        instructor: { name: "Ausbilder", grants: [["event.view", "ALL"], ["location.view", "ALL"], ["task.edit", "ASSIGNED"], ["employee.view", "OWN"], ["employee.view_languages", "OWN"]] },
        employee: { name: "Mitarbeiter", grants: [["event.view", "ALL"], ["location.view", "ALL"], ["task.edit", "ASSIGNED"]] },
      };
      for (const [code, spec] of Object.entries(roleSpecs)) {
        const role = await tx.role.upsert({ where: { code }, update: {}, create: { id: demoId(`role-${code}`), code, name: spec.name } });
        for (const [permission, scope] of spec.grants) {
          const permissionRow = await tx.permission.findUniqueOrThrow({ where: { code: permission } });
          await tx.rolePermission.upsert({ where: { roleId_permissionId_scope: { roleId: role.id, permissionId: permissionRow.id, scope } }, update: {}, create: { roleId: role.id, permissionId: permissionRow.id, scope } });
        }
      }
      const locationNames = ["Demo-Campus Rhein", "Demo-Bildungszentrum Mosel"];
      for (const [i, name] of locationNames.entries()) {
        await tx.location.upsert({ where: { id: demoId(`location-${i}`) }, update: {}, create: { id: demoId(`location-${i}`), name, address: `Fiktive Musterstraße ${i + 1}, 56000 Demo-Ort`, description: "Fiktiver Demonstrationsstandort – keine realen HWK-Stammdaten" } });
        for (let j = 0; j < 2; j++) await tx.building.upsert({ where: { id: demoId(`building-${i}-${j}`) }, update: {}, create: { id: demoId(`building-${i}-${j}`), name: j ? "Werkstattgebäude" : "Veranstaltungsgebäude", shortCode: j ? "W" : "V", locationId: demoId(`location-${i}`) } });
      }
      for (const name of ["Organisation", "Ausbildung"]) await tx.organisationUnit.upsert({ where: { name: `Demo · ${name}` }, update: {}, create: { id: demoId(`unit-${name}`), name: `Demo · ${name}` } });
      const profiles = [
        { code: "admin", first: "Anna", last: "Demo", function: "Systemadministration" },
        { code: "organizer", first: "Mira", last: "Beispiel", function: "Veranstaltungsmanagement" },
        { code: "employee", first: "Jonas", last: "Muster", function: "Mitarbeiter" },
        { code: "instructor", first: "Lena", last: "Werkstatt", function: "Ausbilderin Elektro" },
        { code: "site", first: "Tim", last: "Standort", function: "Standortverantwortung" },
        { code: "wood", first: "Paul", last: "Holz", function: "Ausbilder Tischler" },
        { code: "metal", first: "Nora", last: "Metall", function: "Ausbilderin Metall" },
      ];
      for (const profile of profiles) {
        if (profile.code in roleSpecs) {
          await tx.user.upsert({ where: { tenantId_subject: { tenantId: "local-demo", subject: profile.code } }, update: {}, create: { id: demoId(`user-${profile.code}`), tenantId: "local-demo", subject: profile.code } });
          const role = await tx.role.findUniqueOrThrow({ where: { code: profile.code } });
          const bindingId = demoId(`binding-${profile.code}`);
          await tx.userRole.upsert({ where: { id: bindingId }, update: {}, create: { id: bindingId, userId: demoId(`user-${profile.code}`), roleId: role.id, locationId: profile.code === "site" ? demoId("location-0") : null } });
        }
        const training = ["instructor", "wood", "metal"].includes(profile.code);
        await tx.employee.upsert({ where: { id: demoId(`employee-${profile.code}`) }, update: {}, create: { id: demoId(`employee-${profile.code}`), firstName: profile.first, lastName: profile.last, email: `${profile.code}@demo.invalid`, function: profile.function, unitId: demoId(`unit-${training ? "Ausbildung" : "Organisation"}`), locationId: demoId(profile.code === "metal" ? "location-1" : "location-0"), userId: profile.code in roleSpecs ? demoId(`user-${profile.code}`) : null } });
      }
      for (const [code, name] of [["de", "Deutsch"], ["en", "Englisch"], ["fr", "Französisch"], ["es", "Spanisch"]]) await tx.language.upsert({ where: { code }, update: {}, create: { id: demoId(`language-${code}`), code, name } });
      for (const [code, level] of [["instructor", "C1"], ["wood", "B2"], ["metal", "A2"]] as const) {
        for (const [lang, languageLevel] of [["de", "NATIVE"], ["en", level]] as const) await tx.employeeLanguage.upsert({ where: { employeeId_languageId: { employeeId: demoId(`employee-${code}`), languageId: demoId(`language-${lang}`) } }, update: {}, create: { employeeId: demoId(`employee-${code}`), languageId: demoId(`language-${lang}`), level: languageLevel } });
      }
      const trades = ["Elektro", "SHK", "Tischler", "Metall", "Schweißen", "Kfz", "Maler und Lackierer", "Weitere Gewerke"];
      for (const [i, name] of trades.entries()) await tx.trade.upsert({ where: { code: `TRADE_${i}` }, update: {}, create: { id: demoId(`trade-${i}`), code: `TRADE_${i}`, name } });
      const roomTypes = ["Konferenzraum", "Seminarraum", "Veranstaltungssaal", "Foyer", "Mensa", "Besprechungsraum", "Lehrwerkstatt", "Außenfläche", "Sonstiger Raum"];
      for (const [i, name] of roomTypes.entries()) await tx.roomType.upsert({ where: { code: `ROOM_${i}` }, update: {}, create: { id: demoId(`roomtype-${i}`), code: `ROOM_${i}`, name } });
      for (let i = 0; i < 6; i++) {
        const workshop = i >= 3;
        const location = i === 5 ? 1 : 0;
        await tx.room.upsert({ where: { id: demoId(`room-${i}`) }, update: {}, create: { id: demoId(`room-${i}`), name: ["Forum Rhein", "Seminarraum Begegnung", "Foyer", "Elektrowerkstatt", "Tischlerwerkstatt", "Metallwerkstatt"][i], code: `${workshop ? "W" : "V"}${101 + i}`, floor: "EG", capacity: workshop ? 24 : i === 0 ? 450 : 60, accessible: true, buildingId: demoId(`building-${location}-${workshop ? 1 : 0}`), typeId: demoId(`roomtype-${workshop ? 6 : i === 0 ? 2 : i === 2 ? 3 : 1}`) } });
        if (workshop) {
          const trade = [0, 2, 3][i - 3]; const instructor = ["instructor", "wood", "metal"][i - 3];
          await tx.workshop.upsert({ where: { roomId: demoId(`room-${i}`) }, update: {}, create: { id: demoId(`workshop-${i}`), roomId: demoId(`room-${i}`), name: ["Elektrowerkstatt", "Tischlerwerkstatt", "Metallwerkstatt"][i - 3], tradeId: demoId(`trade-${trade}`), maxVisitors: 20, defaultDurationMinutes: 30, safetyRequirements: "Geschlossene Schuhe; Sicherheitsunterweisung erforderlich", demonstrations: "Vorführung durch Ausbilder" } });
          await tx.workshopEmployee.upsert({ where: { workshopId_employeeId: { workshopId: demoId(`workshop-${i}`), employeeId: demoId(`employee-${instructor}`) } }, update: {}, create: { workshopId: demoId(`workshop-${i}`), employeeId: demoId(`employee-${instructor}`) } });
          await tx.employeeTrade.upsert({ where: { employeeId_tradeId: { employeeId: demoId(`employee-${instructor}`), tradeId: demoId(`trade-${trade}`) } }, update: {}, create: { employeeId: demoId(`employee-${instructor}`), tradeId: demoId(`trade-${trade}`) } });
        }
      }
      const areas = ["Empfang", "Mensa", "IT", "Hausmeister", "Technik", "Öffentlichkeitsarbeit", "Geschäftsführung", "Sicherheitsbeauftragte", "Ausbilder / Lehrwerkstätten"];
      for (const [i, name] of areas.entries()) await tx.responsibilityArea.upsert({ where: { code: `AREA_${i}` }, update: {}, create: { id: demoId(`area-${i}`), code: `AREA_${i}`, name } });
      const impacts = ["Parkplatz", "Mensa", "Foyer", "Zufahrt", "Raum", "Werkstatt", "Lärm", "Öffnungszeiten", "Sicherheit", "Besucheraufkommen"];
      for (const [i, name] of impacts.entries()) await tx.impactCategory.upsert({ where: { code: `IMPACT_${i}` }, update: {}, create: { id: demoId(`impact-${i}`), code: `IMPACT_${i}`, name } });
      const categories = ["Mitarbeiter", "Politik", "Unternehmen", "Ehrenamt", "Delegation", "Schüler", "Presse", "Referent", "Begleitperson", "Sonstige"];
      for (const [i, name] of categories.entries()) await tx.participantCategory.upsert({ where: { code: `PARTICIPANT_${i}` }, update: {}, create: { id: demoId(`category-${i}`), code: `PARTICIPANT_${i}`, name } });
      await tx.organisation.upsert({ where: { id: demoId("organisation") }, update: {}, create: { id: demoId("organisation"), name: "Fiktive Handwerksdelegation Lyon", type: "Delegation", country: "Frankreich" } });
      const titles = ["Handwerk verbindet · Delegation aus Lyon", "Berufe entdecken · Schulbesuch", "Meisterfeier · Ein neuer Anfang", "Freisprechungsfeier des Handwerks", "Nacht der Technik", "Workshop · Nachhaltiges Handwerk", "Politischer Austausch · vertraulich", "Messe · Zukunft im Handwerk"];
      const typeNumbers = [0, 1, 2, 3, 4, 5, 6, 8];
      const anchor = process.env.DEMO_SEED_DATE ?? new Date().toISOString().slice(0, 10);
      if (!/^\d{4}-\d{2}-\d{2}$/.test(anchor) || !Number.isFinite(Date.parse(anchor))) throw new Error("Invalid DEMO_SEED_DATE.");
      for (const [i, title] of titles.entries()) {
        const start = new Date(`${anchor}T08:00:00Z`); start.setUTCDate(start.getUTCDate() + i * 2);
        const end = new Date(start.getTime() + 3 * 60 * 60 * 1000);
        await tx.event.upsert({ where: { id: demoId(`event-${i}`) }, update: {}, create: { id: demoId(`event-${i}`), title, description: "Fiktive Demo-Veranstaltung zur Erprobung des fachlichen Grundgerüsts.", structure: i === 0 || i === 1 ? "EXTERNAL" : "MIXED", start, end, participantCount: i === 2 ? 450 : 20, visibility: i === 6 ? "INVOLVED" : "ALL_EMPLOYEES", ownerId: demoId("employee-organizer"), typeId: demoId(`type-${typeNumbers[i]}`), statusId: demoId(`status-${i % 2 ? "PLANNING" : "CONFIRMED"}`) } });
        await tx.eventLocation.upsert({ where: { eventId_locationId: { eventId: demoId(`event-${i}`), locationId: demoId(`location-${i === 5 ? 1 : 0}`) } }, update: {}, create: { eventId: demoId(`event-${i}`), locationId: demoId(`location-${i === 5 ? 1 : 0}`) } });
        for (let j = 0; j < 3; j++) await tx.eventTask.upsert({ where: { id: demoId(`task-${i}-${j}`) }, update: {}, create: { id: demoId(`task-${i}-${j}`), eventId: demoId(`event-${i}`), title: ["Empfang abstimmen", "Technik vorbereiten", "Sicherheitsunterweisung klären"][j], assigneeId: demoId(j === 2 ? "employee-instructor" : "employee-organizer"), status: j === 0 ? "DONE" : "OPEN", critical: j === 2, dueAt: start } });
      }
      for (const [from, to] of [["DRAFT", "PLANNING"], ["PLANNING", "CONFIRMED"], ["CONFIRMED", "PREPARATION"], ["PREPARATION", "READY"], ["READY", "IN_PROGRESS"], ["IN_PROGRESS", "COMPLETED"]]) await tx.eventStatusTransition.upsert({ where: { fromId_toId: { fromId: demoId(`status-${from}`), toId: demoId(`status-${to}`) } }, update: {}, create: { fromId: demoId(`status-${from}`), toId: demoId(`status-${to}`), permissionId: demoId("permission-event.edit") } });
      const first = await tx.event.findUniqueOrThrow({ where: { id: demoId("event-0") } });
      await tx.eventLanguage.upsert({ where: { eventId_languageId: { eventId: first.id, languageId: demoId("language-en") } }, update: {}, create: { eventId: first.id, languageId: demoId("language-en"), primary: true } });
      await tx.eventOrganisation.upsert({ where: { eventId_organisationId: { eventId: first.id, organisationId: demoId("organisation") } }, update: {}, create: { eventId: first.id, organisationId: demoId("organisation") } });
      await tx.eventImpact.upsert({ where: { id: demoId("impact-demo") }, update: {}, create: { id: demoId("impact-demo"), eventId: first.id, categoryId: demoId("impact-9"), description: "Fiktiver Hinweis: Bitte den Empfang für die Besuchergruppe freihalten.", start: first.start, end: first.end, locationId: demoId("location-0") } });
      await tx.auditLog.upsert({ where: { id: demoId("audit-seed") }, update: {}, create: { id: demoId("audit-seed"), action: "DEMO_SEED_INITIALIZED", entityType: "System", entityId: "demo-v1", changes: { dataset: "fictitious-v1" } } });
    }, { timeout: 60_000 });
    console.log("Fictitious demo dataset initialized (idempotent). No external messages sent.");
  } finally { await db.$disconnect(); }
}

// Importing seed helpers in tests must not execute a seed.
if (process.argv[1]?.endsWith("seed.ts")) seedDemo().catch((error) => { console.error(error instanceof Error ? error.message : "Seed failed"); process.exitCode = 1; });
