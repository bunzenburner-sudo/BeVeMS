-- Existing templates stay private until an administrator assigns or explicitly shares them.
ALTER TABLE "EventTemplate" ADD COLUMN "ownerId" UUID;
ALTER TABLE "EventTemplate" ADD COLUMN "shared" BOOLEAN NOT NULL DEFAULT FALSE;
ALTER TABLE "EventTemplate" ADD CONSTRAINT "EventTemplate_ownerId_fkey" FOREIGN KEY ("ownerId") REFERENCES "Employee"(id) ON DELETE RESTRICT;
