BEGIN;

CREATE UNIQUE INDEX "UserRole_global_unique" ON "UserRole" ("userId", "roleId") WHERE "locationId" IS NULL;
CREATE UNIQUE INDEX "EventLanguage_primary_unique" ON "EventLanguage" ("eventId") WHERE "primary";

ALTER TABLE "Room" ADD CONSTRAINT "Room_capacity_positive" CHECK ("capacity" > 0);
ALTER TABLE "Workshop" ADD CONSTRAINT "Workshop_limits_positive" CHECK ("maxVisitors" > 0 AND "defaultDurationMinutes" > 0);
ALTER TABLE "Event" ADD CONSTRAINT "Event_interval_valid" CHECK ("start" < "end"),
  ADD CONSTRAINT "Event_count_valid" CHECK ("participantCount" >= 0),
  ADD CONSTRAINT "Event_version_valid" CHECK ("version" > 0),
  ADD CONSTRAINT "Event_cost_valid" CHECK (("actualCost" IS NULL AND "currency" IS NULL) OR ("actualCost" >= 0 AND "currency" ~ '^[A-Z]{3}$')),
  ADD CONSTRAINT "Event_series_key_valid" CHECK (("seriesId" IS NULL) = ("occurrenceKey" IS NULL)),
  ADD CONSTRAINT "Event_not_own_previous" CHECK ("previousId" IS DISTINCT FROM "id");
ALTER TABLE "EventParticipantGroup" ADD CONSTRAINT "ParticipantGroup_count_valid" CHECK ("count" >= 0);
ALTER TABLE "EventLessonLearned" ADD CONSTRAINT "Lesson_count_valid" CHECK ("actualParticipants" IS NULL OR "actualParticipants" >= 0);
ALTER TABLE "EventDocument" ADD CONSTRAINT "Document_size_valid" CHECK ("sizeBytes" >= 0);
ALTER TABLE "EventTemplate" ADD CONSTRAINT "Template_version_valid" CHECK ("version" > 0);
ALTER TABLE "EventTask" ADD CONSTRAINT "Task_priority_valid" CHECK ("priority" >= 0);
ALTER TABLE "OutboxMessage" ADD CONSTRAINT "Outbox_attempts_valid" CHECK ("attempts" >= 0);
ALTER TABLE "EmployeeUnavailability" ADD CONSTRAINT "EmployeeUnavailability_interval_valid" CHECK ("start" < "end");
ALTER TABLE "RoomBlock" ADD CONSTRAINT "RoomBlock_interval_valid" CHECK ("start" < "end");
ALTER TABLE "EventImpact" ADD CONSTRAINT "EventImpact_interval_valid" CHECK ("start" < "end");
ALTER TABLE "EventScheduleItem" ADD CONSTRAINT "Schedule_interval_valid" CHECK ("start" < "end" AND "sortOrder" >= 0);
ALTER TABLE "Reservation" ADD CONSTRAINT "Reservation_interval_valid" CHECK (
  "start" < "end" AND "setupMinutes" >= 0 AND "teardownMinutes" >= 0 AND "visitors" >= 0
  AND "occupancyStart" = "start" - "setupMinutes" * interval '1 minute'
  AND "occupancyEnd" = "end" + "teardownMinutes" * interval '1 minute'
);
ALTER TABLE "ReservationOverride" ADD CONSTRAINT "Override_reason_required" CHECK (length(trim("reason")) >= 10);

-- Composite references forbid moving a child into a different event.
ALTER TABLE "EventParticipantGroup" ADD CONSTRAINT "ParticipantGroup_id_event_unique" UNIQUE ("id", "eventId");
ALTER TABLE "EventParticipant" ADD CONSTRAINT "Participant_group_event_matches" FOREIGN KEY ("groupId", "eventId") REFERENCES "EventParticipantGroup" ("id", "eventId");
ALTER TABLE "EventScheduleItem" ADD CONSTRAINT "Schedule_id_event_unique" UNIQUE ("id", "eventId");
ALTER TABLE "Reservation" ADD CONSTRAINT "Reservation_schedule_event_matches" FOREIGN KEY ("scheduleItemId", "eventId") REFERENCES "EventScheduleItem" ("id", "eventId");
ALTER TABLE "ExternalContact" ADD CONSTRAINT "Contact_id_org_unique" UNIQUE ("id", "organisationId");
ALTER TABLE "EventOrganisation" ADD CONSTRAINT "Contact_organisation_matches" FOREIGN KEY ("contactId", "organisationId") REFERENCES "ExternalContact" ("id", "organisationId");

CREATE FUNCTION bevems_validate_schedule() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE event_start timestamptz; event_end timestamptz; room_building uuid; building_location uuid; workshop_room uuid;
BEGIN
  SELECT "start", "end" INTO event_start, event_end FROM "Event" WHERE "id" = NEW."eventId";
  IF NEW."start" < event_start OR NEW."end" > event_end THEN RAISE EXCEPTION 'Schedule outside event interval' USING ERRCODE = '23514'; END IF;
  IF NEW."workshopId" IS NOT NULL THEN
    SELECT "roomId" INTO workshop_room FROM "Workshop" WHERE "id" = NEW."workshopId";
    IF NEW."roomId" IS DISTINCT FROM workshop_room THEN RAISE EXCEPTION 'Workshop room mismatch' USING ERRCODE = '23514'; END IF;
  END IF;
  IF NEW."roomId" IS NOT NULL THEN
    SELECT "buildingId" INTO room_building FROM "Room" WHERE "id" = NEW."roomId";
    IF NEW."buildingId" IS DISTINCT FROM room_building THEN RAISE EXCEPTION 'Room building mismatch' USING ERRCODE = '23514'; END IF;
  END IF;
  IF NEW."buildingId" IS NOT NULL THEN
    SELECT "locationId" INTO building_location FROM "Building" WHERE "id" = NEW."buildingId";
    IF NEW."locationId" IS DISTINCT FROM building_location THEN RAISE EXCEPTION 'Building location mismatch' USING ERRCODE = '23514'; END IF;
  END IF;
  RETURN NEW;
END $$;
CREATE TRIGGER "Schedule_hierarchy_check" BEFORE INSERT OR UPDATE ON "EventScheduleItem" FOR EACH ROW EXECUTE FUNCTION bevems_validate_schedule();

-- Event edits must not invalidate existing schedule items.
CREATE FUNCTION bevems_validate_event_interval() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
  IF EXISTS (SELECT 1 FROM "EventScheduleItem" WHERE "eventId" = NEW."id" AND ("start" < NEW."start" OR "end" > NEW."end")) THEN
    RAISE EXCEPTION 'Existing schedule outside event interval' USING ERRCODE = '23514';
  END IF;
  RETURN NEW;
END $$;
CREATE TRIGGER "Event_schedule_interval_check" BEFORE UPDATE OF "start", "end" ON "Event" FOR EACH ROW EXECUTE FUNCTION bevems_validate_event_interval();

CREATE FUNCTION bevems_audit_append_only() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
  RAISE EXCEPTION 'Audit log is append-only' USING ERRCODE = '42501';
END $$;
CREATE TRIGGER "AuditLog_append_only" BEFORE UPDATE OR DELETE ON "AuditLog" FOR EACH ROW EXECUTE FUNCTION bevems_audit_append_only();

COMMIT;
