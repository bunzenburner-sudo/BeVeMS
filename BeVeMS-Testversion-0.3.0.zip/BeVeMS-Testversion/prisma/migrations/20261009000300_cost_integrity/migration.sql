BEGIN;
ALTER TABLE "Event" DROP CONSTRAINT "Event_cost_valid";
ALTER TABLE "Event" ADD CONSTRAINT "Event_cost_valid" CHECK (
  ("actualCost" IS NULL AND "currency" IS NULL)
  OR ("actualCost" IS NOT NULL AND "currency" IS NOT NULL AND "actualCost" >= 0 AND "currency" ~ '^[A-Z]{3}$')
);
COMMIT;
