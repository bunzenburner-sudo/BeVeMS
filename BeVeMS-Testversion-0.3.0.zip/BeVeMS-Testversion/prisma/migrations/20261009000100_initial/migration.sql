-- CreateSchema
CREATE SCHEMA IF NOT EXISTS "public";

-- CreateEnum
CREATE TYPE "AccessScope" AS ENUM ('ALL', 'LOCATION', 'OWN', 'ASSIGNED');

-- CreateEnum
CREATE TYPE "LanguageLevel" AS ENUM ('A1', 'A2', 'B1', 'B2', 'C1', 'C2', 'NATIVE');

-- CreateEnum
CREATE TYPE "ParticipantStructure" AS ENUM ('INTERNAL', 'EXTERNAL', 'MIXED');

-- CreateEnum
CREATE TYPE "Visibility" AS ENUM ('ALL_EMPLOYEES', 'LOCATIONS', 'UNITS', 'INVOLVED', 'GROUPS');

-- CreateEnum
CREATE TYPE "TaskStatus" AS ENUM ('OPEN', 'IN_PROGRESS', 'DONE');

-- CreateEnum
CREATE TYPE "RegistrationStatus" AS ENUM ('REGISTERED', 'WAITLIST', 'CANCELLED');

-- CreateEnum
CREATE TYPE "InvitationStatus" AS ENUM ('NOT_INVITED', 'INVITED', 'ACCEPTED', 'DECLINED', 'NO_RESPONSE');

-- CreateEnum
CREATE TYPE "CheckInMethod" AS ENUM ('QR', 'MANUAL');

-- CreateEnum
CREATE TYPE "ReservationStatus" AS ENUM ('TENTATIVE', 'CONFIRMED', 'CANCELLED', 'EXPIRED');

-- CreateEnum
CREATE TYPE "VendorReuse" AS ENUM ('YES', 'NO', 'UNDECIDED');

-- CreateEnum
CREATE TYPE "DeliveryState" AS ENUM ('PENDING', 'PROCESSING', 'SENT', 'FAILED');

-- CreateTable
CREATE TABLE "User" (
    "id" UUID NOT NULL,
    "tenantId" TEXT NOT NULL,
    "subject" TEXT NOT NULL,
    "active" BOOLEAN NOT NULL DEFAULT true,

    CONSTRAINT "User_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "Role" (
    "id" UUID NOT NULL,
    "code" TEXT NOT NULL,
    "name" TEXT NOT NULL,
    "active" BOOLEAN NOT NULL DEFAULT true,

    CONSTRAINT "Role_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "Permission" (
    "id" UUID NOT NULL,
    "code" TEXT NOT NULL,
    "description" TEXT NOT NULL,

    CONSTRAINT "Permission_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "RolePermission" (
    "id" UUID NOT NULL,
    "scope" "AccessScope" NOT NULL,
    "roleId" UUID NOT NULL,
    "permissionId" UUID NOT NULL,

    CONSTRAINT "RolePermission_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "UserRole" (
    "id" UUID NOT NULL,
    "userId" UUID NOT NULL,
    "roleId" UUID NOT NULL,
    "locationId" UUID,

    CONSTRAINT "UserRole_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "UserGroup" (
    "id" UUID NOT NULL,
    "name" TEXT NOT NULL,
    "active" BOOLEAN NOT NULL DEFAULT true,

    CONSTRAINT "UserGroup_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "GroupMembership" (
    "id" UUID NOT NULL,
    "userId" UUID NOT NULL,
    "groupId" UUID NOT NULL,

    CONSTRAINT "GroupMembership_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "OrganisationUnit" (
    "id" UUID NOT NULL,
    "name" TEXT NOT NULL,
    "active" BOOLEAN NOT NULL DEFAULT true,

    CONSTRAINT "OrganisationUnit_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "Employee" (
    "id" UUID NOT NULL,
    "firstName" TEXT NOT NULL,
    "lastName" TEXT NOT NULL,
    "email" TEXT NOT NULL,
    "function" TEXT,
    "active" BOOLEAN NOT NULL DEFAULT true,
    "userId" UUID,
    "unitId" UUID NOT NULL,
    "locationId" UUID NOT NULL,

    CONSTRAINT "Employee_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "Language" (
    "id" UUID NOT NULL,
    "code" TEXT NOT NULL,
    "name" TEXT NOT NULL,
    "active" BOOLEAN NOT NULL DEFAULT true,

    CONSTRAINT "Language_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "EmployeeLanguage" (
    "id" UUID NOT NULL,
    "level" "LanguageLevel" NOT NULL,
    "employeeId" UUID NOT NULL,
    "languageId" UUID NOT NULL,

    CONSTRAINT "EmployeeLanguage_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "Location" (
    "id" UUID NOT NULL,
    "name" TEXT NOT NULL,
    "address" TEXT NOT NULL,
    "description" TEXT,
    "active" BOOLEAN NOT NULL DEFAULT true,

    CONSTRAINT "Location_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "Building" (
    "id" UUID NOT NULL,
    "name" TEXT NOT NULL,
    "shortCode" TEXT NOT NULL,
    "description" TEXT,
    "active" BOOLEAN NOT NULL DEFAULT true,
    "locationId" UUID NOT NULL,

    CONSTRAINT "Building_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "RoomType" (
    "id" UUID NOT NULL,
    "code" TEXT NOT NULL,
    "name" TEXT NOT NULL,
    "active" BOOLEAN NOT NULL DEFAULT true,

    CONSTRAINT "RoomType_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "Room" (
    "id" UUID NOT NULL,
    "name" TEXT NOT NULL,
    "code" TEXT NOT NULL,
    "floor" TEXT,
    "capacity" INTEGER NOT NULL,
    "accessible" BOOLEAN NOT NULL DEFAULT false,
    "technicalNotes" TEXT,
    "active" BOOLEAN NOT NULL DEFAULT true,
    "buildingId" UUID NOT NULL,
    "typeId" UUID NOT NULL,

    CONSTRAINT "Room_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "Trade" (
    "id" UUID NOT NULL,
    "code" TEXT NOT NULL,
    "name" TEXT NOT NULL,
    "active" BOOLEAN NOT NULL DEFAULT true,

    CONSTRAINT "Trade_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "Workshop" (
    "id" UUID NOT NULL,
    "name" TEXT NOT NULL,
    "description" TEXT,
    "maxVisitors" INTEGER NOT NULL,
    "safetyRequirements" TEXT,
    "demonstrations" TEXT,
    "defaultDurationMinutes" INTEGER NOT NULL,
    "active" BOOLEAN NOT NULL DEFAULT true,
    "roomId" UUID NOT NULL,
    "tradeId" UUID NOT NULL,

    CONSTRAINT "Workshop_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "WorkshopEmployee" (
    "id" UUID NOT NULL,
    "workshopId" UUID NOT NULL,
    "employeeId" UUID NOT NULL,

    CONSTRAINT "WorkshopEmployee_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "WorkshopLanguage" (
    "id" UUID NOT NULL,
    "workshopId" UUID NOT NULL,
    "languageId" UUID NOT NULL,

    CONSTRAINT "WorkshopLanguage_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "EmployeeTrade" (
    "id" UUID NOT NULL,
    "employeeId" UUID NOT NULL,
    "tradeId" UUID NOT NULL,

    CONSTRAINT "EmployeeTrade_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "EmployeeUnavailability" (
    "id" UUID NOT NULL,
    "start" TIMESTAMPTZ(3) NOT NULL,
    "end" TIMESTAMPTZ(3) NOT NULL,
    "reasonCode" TEXT NOT NULL,
    "employeeId" UUID NOT NULL,

    CONSTRAINT "EmployeeUnavailability_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "Organisation" (
    "id" UUID NOT NULL,
    "name" TEXT NOT NULL,
    "type" TEXT NOT NULL,
    "country" TEXT,
    "address" TEXT,
    "website" TEXT,
    "active" BOOLEAN NOT NULL DEFAULT true,

    CONSTRAINT "Organisation_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "ExternalContact" (
    "id" UUID NOT NULL,
    "firstName" TEXT NOT NULL,
    "lastName" TEXT NOT NULL,
    "email" TEXT,
    "function" TEXT,
    "phone" TEXT,
    "organisationId" UUID NOT NULL,

    CONSTRAINT "ExternalContact_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "EventType" (
    "id" UUID NOT NULL,
    "code" TEXT NOT NULL,
    "name" TEXT NOT NULL,
    "active" BOOLEAN NOT NULL DEFAULT true,

    CONSTRAINT "EventType_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "EventStatus" (
    "id" UUID NOT NULL,
    "code" TEXT NOT NULL,
    "name" TEXT NOT NULL,
    "active" BOOLEAN NOT NULL DEFAULT true,

    CONSTRAINT "EventStatus_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "ImpactCategory" (
    "id" UUID NOT NULL,
    "code" TEXT NOT NULL,
    "name" TEXT NOT NULL,
    "active" BOOLEAN NOT NULL DEFAULT true,

    CONSTRAINT "ImpactCategory_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "ParticipantCategory" (
    "id" UUID NOT NULL,
    "code" TEXT NOT NULL,
    "name" TEXT NOT NULL,
    "active" BOOLEAN NOT NULL DEFAULT true,

    CONSTRAINT "ParticipantCategory_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "ResponsibilityArea" (
    "id" UUID NOT NULL,
    "code" TEXT NOT NULL,
    "name" TEXT NOT NULL,
    "active" BOOLEAN NOT NULL DEFAULT true,

    CONSTRAINT "ResponsibilityArea_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "EventStatusTransition" (
    "id" UUID NOT NULL,
    "fromId" UUID NOT NULL,
    "toId" UUID NOT NULL,
    "permissionId" UUID NOT NULL,

    CONSTRAINT "EventStatusTransition_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "EventSeries" (
    "id" UUID NOT NULL,
    "title" TEXT NOT NULL,
    "rrule" TEXT NOT NULL,
    "timeZone" TEXT NOT NULL DEFAULT 'Europe/Berlin',
    "active" BOOLEAN NOT NULL DEFAULT true,

    CONSTRAINT "EventSeries_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "EventTemplate" (
    "id" UUID NOT NULL,
    "name" TEXT NOT NULL,
    "version" INTEGER NOT NULL DEFAULT 1,
    "blueprint" JSONB NOT NULL,
    "active" BOOLEAN NOT NULL DEFAULT true,

    CONSTRAINT "EventTemplate_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "Event" (
    "id" UUID NOT NULL,
    "title" TEXT NOT NULL,
    "description" TEXT,
    "structure" "ParticipantStructure" NOT NULL,
    "start" TIMESTAMPTZ(3) NOT NULL,
    "end" TIMESTAMPTZ(3) NOT NULL,
    "timeZone" TEXT NOT NULL DEFAULT 'Europe/Berlin',
    "allDay" BOOLEAN NOT NULL DEFAULT false,
    "participantCount" INTEGER NOT NULL DEFAULT 0,
    "country" TEXT,
    "visibility" "Visibility" NOT NULL DEFAULT 'INVOLVED',
    "version" INTEGER NOT NULL DEFAULT 1,
    "occurrenceKey" TEXT,
    "reviewRequired" BOOLEAN NOT NULL DEFAULT false,
    "actualCost" DECIMAL(12,2),
    "currency" TEXT,
    "createdAt" TIMESTAMPTZ(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMPTZ(3) NOT NULL,
    "typeId" UUID NOT NULL,
    "statusId" UUID NOT NULL,
    "ownerId" UUID NOT NULL,
    "seriesId" UUID,
    "templateId" UUID,
    "previousId" UUID,

    CONSTRAINT "Event_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "EventLanguage" (
    "id" UUID NOT NULL,
    "primary" BOOLEAN NOT NULL DEFAULT false,
    "eventId" UUID NOT NULL,
    "languageId" UUID NOT NULL,

    CONSTRAINT "EventLanguage_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "EventTrade" (
    "id" UUID NOT NULL,
    "eventId" UUID NOT NULL,
    "tradeId" UUID NOT NULL,

    CONSTRAINT "EventTrade_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "EventOrganisation" (
    "id" UUID NOT NULL,
    "eventId" UUID NOT NULL,
    "organisationId" UUID NOT NULL,
    "contactId" UUID,

    CONSTRAINT "EventOrganisation_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "EventLocation" (
    "id" UUID NOT NULL,
    "eventId" UUID NOT NULL,
    "locationId" UUID NOT NULL,

    CONSTRAINT "EventLocation_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "EventVisibilityLocation" (
    "id" UUID NOT NULL,
    "eventId" UUID NOT NULL,
    "locationId" UUID NOT NULL,

    CONSTRAINT "EventVisibilityLocation_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "EventVisibilityUnit" (
    "id" UUID NOT NULL,
    "eventId" UUID NOT NULL,
    "unitId" UUID NOT NULL,

    CONSTRAINT "EventVisibilityUnit_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "EventVisibilityGroup" (
    "id" UUID NOT NULL,
    "eventId" UUID NOT NULL,
    "groupId" UUID NOT NULL,

    CONSTRAINT "EventVisibilityGroup_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "EventInvolvement" (
    "id" UUID NOT NULL,
    "eventId" UUID NOT NULL,
    "employeeId" UUID NOT NULL,

    CONSTRAINT "EventInvolvement_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "EventResponsibility" (
    "id" UUID NOT NULL,
    "eventId" UUID NOT NULL,
    "employeeId" UUID NOT NULL,
    "areaId" UUID NOT NULL,

    CONSTRAINT "EventResponsibility_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "EventTask" (
    "id" UUID NOT NULL,
    "title" TEXT NOT NULL,
    "description" TEXT,
    "dueAt" TIMESTAMPTZ(3),
    "status" "TaskStatus" NOT NULL DEFAULT 'OPEN',
    "critical" BOOLEAN NOT NULL DEFAULT false,
    "priority" INTEGER NOT NULL DEFAULT 0,
    "eventId" UUID NOT NULL,
    "assigneeId" UUID NOT NULL,
    "areaId" UUID,

    CONSTRAINT "EventTask_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "EventScheduleItem" (
    "id" UUID NOT NULL,
    "title" TEXT NOT NULL,
    "description" TEXT,
    "start" TIMESTAMPTZ(3) NOT NULL,
    "end" TIMESTAMPTZ(3) NOT NULL,
    "sortOrder" INTEGER NOT NULL,
    "internalNotes" TEXT,
    "eventId" UUID NOT NULL,
    "locationId" UUID,
    "buildingId" UUID,
    "roomId" UUID,
    "workshopId" UUID,
    "responsibleId" UUID,

    CONSTRAINT "EventScheduleItem_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "EventImpact" (
    "id" UUID NOT NULL,
    "description" TEXT NOT NULL,
    "start" TIMESTAMPTZ(3) NOT NULL,
    "end" TIMESTAMPTZ(3) NOT NULL,
    "publicSummary" TEXT,
    "eventId" UUID NOT NULL,
    "categoryId" UUID,
    "locationId" UUID,

    CONSTRAINT "EventImpact_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "ImpactAudience" (
    "id" UUID NOT NULL,
    "impactId" UUID NOT NULL,
    "groupId" UUID NOT NULL,

    CONSTRAINT "ImpactAudience_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "EventParticipantGroup" (
    "id" UUID NOT NULL,
    "name" TEXT NOT NULL,
    "count" INTEGER NOT NULL,
    "description" TEXT,
    "eventId" UUID NOT NULL,
    "organisationId" UUID,
    "categoryId" UUID NOT NULL,

    CONSTRAINT "EventParticipantGroup_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "EventParticipant" (
    "id" UUID NOT NULL,
    "firstName" TEXT NOT NULL,
    "lastName" TEXT NOT NULL,
    "email" TEXT,
    "function" TEXT,
    "registrationStatus" "RegistrationStatus" NOT NULL DEFAULT 'REGISTERED',
    "qrTokenHash" TEXT,
    "retentionUntil" TIMESTAMPTZ(3),
    "eventId" UUID NOT NULL,
    "organisationId" UUID,
    "employeeId" UUID,
    "groupId" UUID,
    "categoryId" UUID NOT NULL,

    CONSTRAINT "EventParticipant_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "EventInvitation" (
    "id" UUID NOT NULL,
    "participantId" UUID NOT NULL,
    "status" "InvitationStatus" NOT NULL DEFAULT 'NOT_INVITED',
    "sentAt" TIMESTAMPTZ(3),
    "respondedAt" TIMESTAMPTZ(3),

    CONSTRAINT "EventInvitation_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "CheckIn" (
    "id" UUID NOT NULL,
    "participantId" UUID NOT NULL,
    "checkedAt" TIMESTAMPTZ(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "method" "CheckInMethod" NOT NULL,
    "actorId" UUID NOT NULL,

    CONSTRAINT "CheckIn_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "Reservation" (
    "id" UUID NOT NULL,
    "start" TIMESTAMPTZ(3) NOT NULL,
    "end" TIMESTAMPTZ(3) NOT NULL,
    "setupMinutes" INTEGER NOT NULL DEFAULT 0,
    "teardownMinutes" INTEGER NOT NULL DEFAULT 0,
    "occupancyStart" TIMESTAMPTZ(3) NOT NULL,
    "occupancyEnd" TIMESTAMPTZ(3) NOT NULL,
    "visitors" INTEGER NOT NULL,
    "status" "ReservationStatus" NOT NULL DEFAULT 'TENTATIVE',
    "expiresAt" TIMESTAMPTZ(3),
    "externalReference" TEXT,
    "externalCheckedAt" TIMESTAMPTZ(3),
    "eventId" UUID NOT NULL,
    "roomId" UUID NOT NULL,
    "scheduleItemId" UUID,
    "createdById" UUID NOT NULL,

    CONSTRAINT "Reservation_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "ReservationInstructor" (
    "id" UUID NOT NULL,
    "reservationId" UUID NOT NULL,
    "employeeId" UUID NOT NULL,

    CONSTRAINT "ReservationInstructor_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "ReservationOverride" (
    "id" UUID NOT NULL,
    "conflictCode" TEXT NOT NULL,
    "conflictingResourceId" TEXT NOT NULL,
    "reason" TEXT NOT NULL,
    "approvedAt" TIMESTAMPTZ(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "reservationId" UUID NOT NULL,
    "approvedById" UUID NOT NULL,

    CONSTRAINT "ReservationOverride_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "RoomBlock" (
    "id" UUID NOT NULL,
    "start" TIMESTAMPTZ(3) NOT NULL,
    "end" TIMESTAMPTZ(3) NOT NULL,
    "reason" TEXT NOT NULL,
    "hard" BOOLEAN NOT NULL DEFAULT true,
    "roomId" UUID NOT NULL,

    CONSTRAINT "RoomBlock_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "EventLessonLearned" (
    "id" UUID NOT NULL,
    "eventId" UUID NOT NULL,
    "wentWell" TEXT,
    "wentBadly" TEXT,
    "nextTime" TEXT,
    "incidents" TEXT,
    "improvements" TEXT,
    "actualParticipants" INTEGER,

    CONSTRAINT "EventLessonLearned_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "Vendor" (
    "id" UUID NOT NULL,
    "company" TEXT NOT NULL,
    "contactName" TEXT,
    "email" TEXT,
    "phone" TEXT,
    "active" BOOLEAN NOT NULL DEFAULT true,

    CONSTRAINT "Vendor_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "EventVendor" (
    "id" UUID NOT NULL,
    "service" TEXT NOT NULL,
    "notes" TEXT,
    "reuse" "VendorReuse" NOT NULL DEFAULT 'UNDECIDED',
    "eventId" UUID NOT NULL,
    "vendorId" UUID NOT NULL,

    CONSTRAINT "EventVendor_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "EventDocument" (
    "id" UUID NOT NULL,
    "name" TEXT NOT NULL,
    "storageKey" TEXT NOT NULL,
    "mimeType" TEXT NOT NULL,
    "sizeBytes" INTEGER NOT NULL,
    "scanStatus" TEXT NOT NULL,
    "uploadedAt" TIMESTAMPTZ(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "eventId" UUID NOT NULL,
    "uploadedById" UUID NOT NULL,

    CONSTRAINT "EventDocument_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "EmailRecipient" (
    "id" UUID NOT NULL,
    "email" TEXT NOT NULL,
    "label" TEXT,
    "eventId" UUID NOT NULL,

    CONSTRAINT "EmailRecipient_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "CalendarInvitation" (
    "id" UUID NOT NULL,
    "recipientEmail" TEXT NOT NULL,
    "externalId" TEXT,
    "externalEtag" TEXT,
    "syncedVersion" INTEGER NOT NULL DEFAULT 0,
    "state" "DeliveryState" NOT NULL DEFAULT 'PENDING',
    "eventId" UUID NOT NULL,

    CONSTRAINT "CalendarInvitation_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "Notification" (
    "id" UUID NOT NULL,
    "title" TEXT NOT NULL,
    "body" TEXT NOT NULL,
    "readAt" TIMESTAMPTZ(3),
    "createdAt" TIMESTAMPTZ(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "userId" UUID NOT NULL,
    "eventId" UUID,

    CONSTRAINT "Notification_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "OutboxMessage" (
    "id" UUID NOT NULL,
    "dedupeKey" TEXT NOT NULL,
    "kind" TEXT NOT NULL,
    "payload" JSONB NOT NULL,
    "state" "DeliveryState" NOT NULL DEFAULT 'PENDING',
    "attempts" INTEGER NOT NULL DEFAULT 0,
    "nextAttemptAt" TIMESTAMPTZ(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "lockedUntil" TIMESTAMPTZ(3),
    "lastErrorCode" TEXT,
    "createdAt" TIMESTAMPTZ(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "eventId" UUID,

    CONSTRAINT "OutboxMessage_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "AuditLog" (
    "id" UUID NOT NULL,
    "action" TEXT NOT NULL,
    "entityType" TEXT NOT NULL,
    "entityId" TEXT NOT NULL,
    "changes" JSONB NOT NULL,
    "occurredAt" TIMESTAMPTZ(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "actorId" UUID,
    "eventId" UUID,

    CONSTRAINT "AuditLog_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE UNIQUE INDEX "User_tenantId_subject_key" ON "User"("tenantId", "subject");

-- CreateIndex
CREATE UNIQUE INDEX "Role_code_key" ON "Role"("code");

-- CreateIndex
CREATE UNIQUE INDEX "Permission_code_key" ON "Permission"("code");

-- CreateIndex
CREATE UNIQUE INDEX "RolePermission_roleId_permissionId_scope_key" ON "RolePermission"("roleId", "permissionId", "scope");

-- CreateIndex
CREATE UNIQUE INDEX "UserRole_userId_roleId_locationId_key" ON "UserRole"("userId", "roleId", "locationId");

-- CreateIndex
CREATE UNIQUE INDEX "UserGroup_name_key" ON "UserGroup"("name");

-- CreateIndex
CREATE UNIQUE INDEX "GroupMembership_userId_groupId_key" ON "GroupMembership"("userId", "groupId");

-- CreateIndex
CREATE UNIQUE INDEX "OrganisationUnit_name_key" ON "OrganisationUnit"("name");

-- CreateIndex
CREATE UNIQUE INDEX "Employee_email_key" ON "Employee"("email");

-- CreateIndex
CREATE UNIQUE INDEX "Employee_userId_key" ON "Employee"("userId");

-- CreateIndex
CREATE UNIQUE INDEX "Language_code_key" ON "Language"("code");

-- CreateIndex
CREATE UNIQUE INDEX "EmployeeLanguage_employeeId_languageId_key" ON "EmployeeLanguage"("employeeId", "languageId");

-- CreateIndex
CREATE UNIQUE INDEX "Building_locationId_shortCode_key" ON "Building"("locationId", "shortCode");

-- CreateIndex
CREATE UNIQUE INDEX "RoomType_code_key" ON "RoomType"("code");

-- CreateIndex
CREATE UNIQUE INDEX "Room_buildingId_code_key" ON "Room"("buildingId", "code");

-- CreateIndex
CREATE UNIQUE INDEX "Trade_code_key" ON "Trade"("code");

-- CreateIndex
CREATE UNIQUE INDEX "Workshop_roomId_key" ON "Workshop"("roomId");

-- CreateIndex
CREATE UNIQUE INDEX "WorkshopEmployee_workshopId_employeeId_key" ON "WorkshopEmployee"("workshopId", "employeeId");

-- CreateIndex
CREATE UNIQUE INDEX "WorkshopLanguage_workshopId_languageId_key" ON "WorkshopLanguage"("workshopId", "languageId");

-- CreateIndex
CREATE UNIQUE INDEX "EmployeeTrade_employeeId_tradeId_key" ON "EmployeeTrade"("employeeId", "tradeId");

-- CreateIndex
CREATE INDEX "EmployeeUnavailability_employeeId_start_end_idx" ON "EmployeeUnavailability"("employeeId", "start", "end");

-- CreateIndex
CREATE UNIQUE INDEX "EventType_code_key" ON "EventType"("code");

-- CreateIndex
CREATE UNIQUE INDEX "EventStatus_code_key" ON "EventStatus"("code");

-- CreateIndex
CREATE UNIQUE INDEX "ImpactCategory_code_key" ON "ImpactCategory"("code");

-- CreateIndex
CREATE UNIQUE INDEX "ParticipantCategory_code_key" ON "ParticipantCategory"("code");

-- CreateIndex
CREATE UNIQUE INDEX "ResponsibilityArea_code_key" ON "ResponsibilityArea"("code");

-- CreateIndex
CREATE UNIQUE INDEX "EventStatusTransition_fromId_toId_key" ON "EventStatusTransition"("fromId", "toId");

-- CreateIndex
CREATE INDEX "Event_start_end_idx" ON "Event"("start", "end");

-- CreateIndex
CREATE UNIQUE INDEX "Event_seriesId_occurrenceKey_key" ON "Event"("seriesId", "occurrenceKey");

-- CreateIndex
CREATE UNIQUE INDEX "EventLanguage_eventId_languageId_key" ON "EventLanguage"("eventId", "languageId");

-- CreateIndex
CREATE UNIQUE INDEX "EventTrade_eventId_tradeId_key" ON "EventTrade"("eventId", "tradeId");

-- CreateIndex
CREATE UNIQUE INDEX "EventOrganisation_eventId_organisationId_key" ON "EventOrganisation"("eventId", "organisationId");

-- CreateIndex
CREATE UNIQUE INDEX "EventLocation_eventId_locationId_key" ON "EventLocation"("eventId", "locationId");

-- CreateIndex
CREATE UNIQUE INDEX "EventVisibilityLocation_eventId_locationId_key" ON "EventVisibilityLocation"("eventId", "locationId");

-- CreateIndex
CREATE UNIQUE INDEX "EventVisibilityUnit_eventId_unitId_key" ON "EventVisibilityUnit"("eventId", "unitId");

-- CreateIndex
CREATE UNIQUE INDEX "EventVisibilityGroup_eventId_groupId_key" ON "EventVisibilityGroup"("eventId", "groupId");

-- CreateIndex
CREATE UNIQUE INDEX "EventInvolvement_eventId_employeeId_key" ON "EventInvolvement"("eventId", "employeeId");

-- CreateIndex
CREATE UNIQUE INDEX "EventResponsibility_eventId_employeeId_areaId_key" ON "EventResponsibility"("eventId", "employeeId", "areaId");

-- CreateIndex
CREATE INDEX "EventScheduleItem_eventId_sortOrder_idx" ON "EventScheduleItem"("eventId", "sortOrder");

-- CreateIndex
CREATE UNIQUE INDEX "ImpactAudience_impactId_groupId_key" ON "ImpactAudience"("impactId", "groupId");

-- CreateIndex
CREATE UNIQUE INDEX "EventParticipant_qrTokenHash_key" ON "EventParticipant"("qrTokenHash");

-- CreateIndex
CREATE UNIQUE INDEX "EventInvitation_participantId_key" ON "EventInvitation"("participantId");

-- CreateIndex
CREATE UNIQUE INDEX "CheckIn_participantId_key" ON "CheckIn"("participantId");

-- CreateIndex
CREATE INDEX "Reservation_roomId_occupancyStart_occupancyEnd_idx" ON "Reservation"("roomId", "occupancyStart", "occupancyEnd");

-- CreateIndex
CREATE UNIQUE INDEX "ReservationInstructor_reservationId_employeeId_key" ON "ReservationInstructor"("reservationId", "employeeId");

-- CreateIndex
CREATE INDEX "RoomBlock_roomId_start_end_idx" ON "RoomBlock"("roomId", "start", "end");

-- CreateIndex
CREATE UNIQUE INDEX "EventLessonLearned_eventId_key" ON "EventLessonLearned"("eventId");

-- CreateIndex
CREATE UNIQUE INDEX "EventDocument_storageKey_key" ON "EventDocument"("storageKey");

-- CreateIndex
CREATE UNIQUE INDEX "EmailRecipient_eventId_email_key" ON "EmailRecipient"("eventId", "email");

-- CreateIndex
CREATE UNIQUE INDEX "CalendarInvitation_eventId_recipientEmail_key" ON "CalendarInvitation"("eventId", "recipientEmail");

-- CreateIndex
CREATE UNIQUE INDEX "OutboxMessage_dedupeKey_key" ON "OutboxMessage"("dedupeKey");

-- CreateIndex
CREATE INDEX "OutboxMessage_state_nextAttemptAt_idx" ON "OutboxMessage"("state", "nextAttemptAt");

-- CreateIndex
CREATE INDEX "AuditLog_eventId_occurredAt_idx" ON "AuditLog"("eventId", "occurredAt");

-- AddForeignKey
ALTER TABLE "RolePermission" ADD CONSTRAINT "RolePermission_roleId_fkey" FOREIGN KEY ("roleId") REFERENCES "Role"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "RolePermission" ADD CONSTRAINT "RolePermission_permissionId_fkey" FOREIGN KEY ("permissionId") REFERENCES "Permission"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "UserRole" ADD CONSTRAINT "UserRole_userId_fkey" FOREIGN KEY ("userId") REFERENCES "User"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "UserRole" ADD CONSTRAINT "UserRole_roleId_fkey" FOREIGN KEY ("roleId") REFERENCES "Role"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "UserRole" ADD CONSTRAINT "UserRole_locationId_fkey" FOREIGN KEY ("locationId") REFERENCES "Location"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "GroupMembership" ADD CONSTRAINT "GroupMembership_userId_fkey" FOREIGN KEY ("userId") REFERENCES "User"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "GroupMembership" ADD CONSTRAINT "GroupMembership_groupId_fkey" FOREIGN KEY ("groupId") REFERENCES "UserGroup"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "Employee" ADD CONSTRAINT "Employee_userId_fkey" FOREIGN KEY ("userId") REFERENCES "User"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "Employee" ADD CONSTRAINT "Employee_unitId_fkey" FOREIGN KEY ("unitId") REFERENCES "OrganisationUnit"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "Employee" ADD CONSTRAINT "Employee_locationId_fkey" FOREIGN KEY ("locationId") REFERENCES "Location"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "EmployeeLanguage" ADD CONSTRAINT "EmployeeLanguage_employeeId_fkey" FOREIGN KEY ("employeeId") REFERENCES "Employee"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "EmployeeLanguage" ADD CONSTRAINT "EmployeeLanguage_languageId_fkey" FOREIGN KEY ("languageId") REFERENCES "Language"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "Building" ADD CONSTRAINT "Building_locationId_fkey" FOREIGN KEY ("locationId") REFERENCES "Location"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "Room" ADD CONSTRAINT "Room_buildingId_fkey" FOREIGN KEY ("buildingId") REFERENCES "Building"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "Room" ADD CONSTRAINT "Room_typeId_fkey" FOREIGN KEY ("typeId") REFERENCES "RoomType"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "Workshop" ADD CONSTRAINT "Workshop_roomId_fkey" FOREIGN KEY ("roomId") REFERENCES "Room"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "Workshop" ADD CONSTRAINT "Workshop_tradeId_fkey" FOREIGN KEY ("tradeId") REFERENCES "Trade"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "WorkshopEmployee" ADD CONSTRAINT "WorkshopEmployee_workshopId_fkey" FOREIGN KEY ("workshopId") REFERENCES "Workshop"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "WorkshopEmployee" ADD CONSTRAINT "WorkshopEmployee_employeeId_fkey" FOREIGN KEY ("employeeId") REFERENCES "Employee"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "WorkshopLanguage" ADD CONSTRAINT "WorkshopLanguage_workshopId_fkey" FOREIGN KEY ("workshopId") REFERENCES "Workshop"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "WorkshopLanguage" ADD CONSTRAINT "WorkshopLanguage_languageId_fkey" FOREIGN KEY ("languageId") REFERENCES "Language"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "EmployeeTrade" ADD CONSTRAINT "EmployeeTrade_employeeId_fkey" FOREIGN KEY ("employeeId") REFERENCES "Employee"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "EmployeeTrade" ADD CONSTRAINT "EmployeeTrade_tradeId_fkey" FOREIGN KEY ("tradeId") REFERENCES "Trade"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "EmployeeUnavailability" ADD CONSTRAINT "EmployeeUnavailability_employeeId_fkey" FOREIGN KEY ("employeeId") REFERENCES "Employee"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "ExternalContact" ADD CONSTRAINT "ExternalContact_organisationId_fkey" FOREIGN KEY ("organisationId") REFERENCES "Organisation"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "EventStatusTransition" ADD CONSTRAINT "EventStatusTransition_fromId_fkey" FOREIGN KEY ("fromId") REFERENCES "EventStatus"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "EventStatusTransition" ADD CONSTRAINT "EventStatusTransition_toId_fkey" FOREIGN KEY ("toId") REFERENCES "EventStatus"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "EventStatusTransition" ADD CONSTRAINT "EventStatusTransition_permissionId_fkey" FOREIGN KEY ("permissionId") REFERENCES "Permission"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "Event" ADD CONSTRAINT "Event_typeId_fkey" FOREIGN KEY ("typeId") REFERENCES "EventType"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "Event" ADD CONSTRAINT "Event_statusId_fkey" FOREIGN KEY ("statusId") REFERENCES "EventStatus"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "Event" ADD CONSTRAINT "Event_ownerId_fkey" FOREIGN KEY ("ownerId") REFERENCES "Employee"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "Event" ADD CONSTRAINT "Event_seriesId_fkey" FOREIGN KEY ("seriesId") REFERENCES "EventSeries"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "Event" ADD CONSTRAINT "Event_templateId_fkey" FOREIGN KEY ("templateId") REFERENCES "EventTemplate"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "Event" ADD CONSTRAINT "Event_previousId_fkey" FOREIGN KEY ("previousId") REFERENCES "Event"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "EventLanguage" ADD CONSTRAINT "EventLanguage_eventId_fkey" FOREIGN KEY ("eventId") REFERENCES "Event"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "EventLanguage" ADD CONSTRAINT "EventLanguage_languageId_fkey" FOREIGN KEY ("languageId") REFERENCES "Language"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "EventTrade" ADD CONSTRAINT "EventTrade_eventId_fkey" FOREIGN KEY ("eventId") REFERENCES "Event"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "EventTrade" ADD CONSTRAINT "EventTrade_tradeId_fkey" FOREIGN KEY ("tradeId") REFERENCES "Trade"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "EventOrganisation" ADD CONSTRAINT "EventOrganisation_eventId_fkey" FOREIGN KEY ("eventId") REFERENCES "Event"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "EventOrganisation" ADD CONSTRAINT "EventOrganisation_organisationId_fkey" FOREIGN KEY ("organisationId") REFERENCES "Organisation"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "EventOrganisation" ADD CONSTRAINT "EventOrganisation_contactId_fkey" FOREIGN KEY ("contactId") REFERENCES "ExternalContact"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "EventLocation" ADD CONSTRAINT "EventLocation_eventId_fkey" FOREIGN KEY ("eventId") REFERENCES "Event"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "EventLocation" ADD CONSTRAINT "EventLocation_locationId_fkey" FOREIGN KEY ("locationId") REFERENCES "Location"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "EventVisibilityLocation" ADD CONSTRAINT "EventVisibilityLocation_eventId_fkey" FOREIGN KEY ("eventId") REFERENCES "Event"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "EventVisibilityLocation" ADD CONSTRAINT "EventVisibilityLocation_locationId_fkey" FOREIGN KEY ("locationId") REFERENCES "Location"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "EventVisibilityUnit" ADD CONSTRAINT "EventVisibilityUnit_eventId_fkey" FOREIGN KEY ("eventId") REFERENCES "Event"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "EventVisibilityUnit" ADD CONSTRAINT "EventVisibilityUnit_unitId_fkey" FOREIGN KEY ("unitId") REFERENCES "OrganisationUnit"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "EventVisibilityGroup" ADD CONSTRAINT "EventVisibilityGroup_eventId_fkey" FOREIGN KEY ("eventId") REFERENCES "Event"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "EventVisibilityGroup" ADD CONSTRAINT "EventVisibilityGroup_groupId_fkey" FOREIGN KEY ("groupId") REFERENCES "UserGroup"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "EventInvolvement" ADD CONSTRAINT "EventInvolvement_eventId_fkey" FOREIGN KEY ("eventId") REFERENCES "Event"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "EventInvolvement" ADD CONSTRAINT "EventInvolvement_employeeId_fkey" FOREIGN KEY ("employeeId") REFERENCES "Employee"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "EventResponsibility" ADD CONSTRAINT "EventResponsibility_eventId_fkey" FOREIGN KEY ("eventId") REFERENCES "Event"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "EventResponsibility" ADD CONSTRAINT "EventResponsibility_employeeId_fkey" FOREIGN KEY ("employeeId") REFERENCES "Employee"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "EventResponsibility" ADD CONSTRAINT "EventResponsibility_areaId_fkey" FOREIGN KEY ("areaId") REFERENCES "ResponsibilityArea"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "EventTask" ADD CONSTRAINT "EventTask_eventId_fkey" FOREIGN KEY ("eventId") REFERENCES "Event"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "EventTask" ADD CONSTRAINT "EventTask_assigneeId_fkey" FOREIGN KEY ("assigneeId") REFERENCES "Employee"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "EventTask" ADD CONSTRAINT "EventTask_areaId_fkey" FOREIGN KEY ("areaId") REFERENCES "ResponsibilityArea"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "EventScheduleItem" ADD CONSTRAINT "EventScheduleItem_eventId_fkey" FOREIGN KEY ("eventId") REFERENCES "Event"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "EventScheduleItem" ADD CONSTRAINT "EventScheduleItem_locationId_fkey" FOREIGN KEY ("locationId") REFERENCES "Location"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "EventScheduleItem" ADD CONSTRAINT "EventScheduleItem_buildingId_fkey" FOREIGN KEY ("buildingId") REFERENCES "Building"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "EventScheduleItem" ADD CONSTRAINT "EventScheduleItem_roomId_fkey" FOREIGN KEY ("roomId") REFERENCES "Room"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "EventScheduleItem" ADD CONSTRAINT "EventScheduleItem_workshopId_fkey" FOREIGN KEY ("workshopId") REFERENCES "Workshop"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "EventScheduleItem" ADD CONSTRAINT "EventScheduleItem_responsibleId_fkey" FOREIGN KEY ("responsibleId") REFERENCES "Employee"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "EventImpact" ADD CONSTRAINT "EventImpact_eventId_fkey" FOREIGN KEY ("eventId") REFERENCES "Event"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "EventImpact" ADD CONSTRAINT "EventImpact_categoryId_fkey" FOREIGN KEY ("categoryId") REFERENCES "ImpactCategory"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "EventImpact" ADD CONSTRAINT "EventImpact_locationId_fkey" FOREIGN KEY ("locationId") REFERENCES "Location"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "ImpactAudience" ADD CONSTRAINT "ImpactAudience_impactId_fkey" FOREIGN KEY ("impactId") REFERENCES "EventImpact"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "ImpactAudience" ADD CONSTRAINT "ImpactAudience_groupId_fkey" FOREIGN KEY ("groupId") REFERENCES "UserGroup"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "EventParticipantGroup" ADD CONSTRAINT "EventParticipantGroup_eventId_fkey" FOREIGN KEY ("eventId") REFERENCES "Event"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "EventParticipantGroup" ADD CONSTRAINT "EventParticipantGroup_organisationId_fkey" FOREIGN KEY ("organisationId") REFERENCES "Organisation"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "EventParticipantGroup" ADD CONSTRAINT "EventParticipantGroup_categoryId_fkey" FOREIGN KEY ("categoryId") REFERENCES "ParticipantCategory"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "EventParticipant" ADD CONSTRAINT "EventParticipant_eventId_fkey" FOREIGN KEY ("eventId") REFERENCES "Event"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "EventParticipant" ADD CONSTRAINT "EventParticipant_organisationId_fkey" FOREIGN KEY ("organisationId") REFERENCES "Organisation"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "EventParticipant" ADD CONSTRAINT "EventParticipant_employeeId_fkey" FOREIGN KEY ("employeeId") REFERENCES "Employee"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "EventParticipant" ADD CONSTRAINT "EventParticipant_groupId_fkey" FOREIGN KEY ("groupId") REFERENCES "EventParticipantGroup"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "EventParticipant" ADD CONSTRAINT "EventParticipant_categoryId_fkey" FOREIGN KEY ("categoryId") REFERENCES "ParticipantCategory"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "EventInvitation" ADD CONSTRAINT "EventInvitation_participantId_fkey" FOREIGN KEY ("participantId") REFERENCES "EventParticipant"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "CheckIn" ADD CONSTRAINT "CheckIn_participantId_fkey" FOREIGN KEY ("participantId") REFERENCES "EventParticipant"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "CheckIn" ADD CONSTRAINT "CheckIn_actorId_fkey" FOREIGN KEY ("actorId") REFERENCES "User"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "Reservation" ADD CONSTRAINT "Reservation_eventId_fkey" FOREIGN KEY ("eventId") REFERENCES "Event"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "Reservation" ADD CONSTRAINT "Reservation_roomId_fkey" FOREIGN KEY ("roomId") REFERENCES "Room"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "Reservation" ADD CONSTRAINT "Reservation_scheduleItemId_fkey" FOREIGN KEY ("scheduleItemId") REFERENCES "EventScheduleItem"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "Reservation" ADD CONSTRAINT "Reservation_createdById_fkey" FOREIGN KEY ("createdById") REFERENCES "User"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "ReservationInstructor" ADD CONSTRAINT "ReservationInstructor_reservationId_fkey" FOREIGN KEY ("reservationId") REFERENCES "Reservation"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "ReservationInstructor" ADD CONSTRAINT "ReservationInstructor_employeeId_fkey" FOREIGN KEY ("employeeId") REFERENCES "Employee"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "ReservationOverride" ADD CONSTRAINT "ReservationOverride_reservationId_fkey" FOREIGN KEY ("reservationId") REFERENCES "Reservation"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "ReservationOverride" ADD CONSTRAINT "ReservationOverride_approvedById_fkey" FOREIGN KEY ("approvedById") REFERENCES "User"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "RoomBlock" ADD CONSTRAINT "RoomBlock_roomId_fkey" FOREIGN KEY ("roomId") REFERENCES "Room"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "EventLessonLearned" ADD CONSTRAINT "EventLessonLearned_eventId_fkey" FOREIGN KEY ("eventId") REFERENCES "Event"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "EventVendor" ADD CONSTRAINT "EventVendor_eventId_fkey" FOREIGN KEY ("eventId") REFERENCES "Event"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "EventVendor" ADD CONSTRAINT "EventVendor_vendorId_fkey" FOREIGN KEY ("vendorId") REFERENCES "Vendor"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "EventDocument" ADD CONSTRAINT "EventDocument_eventId_fkey" FOREIGN KEY ("eventId") REFERENCES "Event"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "EventDocument" ADD CONSTRAINT "EventDocument_uploadedById_fkey" FOREIGN KEY ("uploadedById") REFERENCES "User"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "EmailRecipient" ADD CONSTRAINT "EmailRecipient_eventId_fkey" FOREIGN KEY ("eventId") REFERENCES "Event"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "CalendarInvitation" ADD CONSTRAINT "CalendarInvitation_eventId_fkey" FOREIGN KEY ("eventId") REFERENCES "Event"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "Notification" ADD CONSTRAINT "Notification_userId_fkey" FOREIGN KEY ("userId") REFERENCES "User"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "Notification" ADD CONSTRAINT "Notification_eventId_fkey" FOREIGN KEY ("eventId") REFERENCES "Event"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "OutboxMessage" ADD CONSTRAINT "OutboxMessage_eventId_fkey" FOREIGN KEY ("eventId") REFERENCES "Event"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "AuditLog" ADD CONSTRAINT "AuditLog_actorId_fkey" FOREIGN KEY ("actorId") REFERENCES "User"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "AuditLog" ADD CONSTRAINT "AuditLog_eventId_fkey" FOREIGN KEY ("eventId") REFERENCES "Event"("id") ON DELETE RESTRICT ON UPDATE CASCADE;
