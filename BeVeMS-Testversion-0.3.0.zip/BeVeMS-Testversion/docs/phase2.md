# Phase 2: Umsetzung und Validierung

> Historischer Entwurfs-/Phasennachweis. Aktueller Implementierungsstand: [Phasen 3–6](phasen3-6.md).

## Ergebnis

Die Architektur aus Phase 1 hat ein ausführbares Grundgerüst erhalten. Prisma wurde auf die stabile Version 7.10.0 angehoben; die DB-URL liegt jetzt in `prisma.config.ts`, der generierte TypeScript-Client verwendet den PostgreSQL-Treiberadapter. Schema, Migrationen und Entwicklungspakete sind versioniert; generierte Dateien und Geheimnisse bleiben ignoriert.

Die Basisnavigation verwendet echte autorisierte Lesedienste. Sie demonstriert Rollen und Sichtbarkeit, stellt aber keine vollständigen Planungsfunktionen der Phase 3 dar. Verwaltungstabellen sind konfigurierbare Datenstrukturen; derzeit zeigt die Administration sie lesend. Demo-Daten sind ausschließlich fiktiv.

## Sicherheitsmaßnahmen und Grenzen

- Rechteprüfung in Fachservices und Query-Policies zusätzlich zum Seitenzugriff. Leere Grants bedeuten explizit keine Ergebnismenge; ungebundene Standortrechte werden verworfen.
- Aktive Rollen und Konten je Anfrage prüfen; keine dauerhaft im Sessiontoken gespeicherten Rollen. Sprachdaten nur berechtigt projizieren.
- Eigene Runtime-DB-Identität. Privilegierte Zugangsdaten nur in `.env.setup`, das Next.js nicht automatisch lädt. Standalone-Build entfernt getracete `.env`-Dateien.
- Seed und Demo-Credentials sind produktiv gesperrt. Demo-Sessiontokens funktionieren im Produktivmodus nicht.
- Audit-Zeilen sind append-only. Operator-Identitätszuordnungen sind auditiert. Vollständige Fachänderungs-, Export- und sensible Datenzugriffsaudits werden mit den entsprechenden Diensten ergänzt.
- SQL-Migrationen enthalten grundlegende Invarianten. Atomare Raum-/Ausbilderbuchungen, Sicherheitsblocks und Konfliktübersteuerung brauchen den Buchungsdienst der Phase 3. Noch keine Doppelbuchungssicherheit behaupten.
- Ein zusätzliches Recht allein macht ein vertrauliches Event nicht sichtbar. `event.view_sensitive` im ALL-Scope ist ein ausdrücklich vergebener administrativer Zugriff; seine Zugriffsauditierung bleibt vor Produktivfreigabe erforderlich.

## Prüfungen in der Cloud-Instanz

| Prüfung | Ergebnis |
|---|---|
| Offizielle Prisma-WASM-Schemavalidierung und Clientgenerierung | erfolgreich |
| Frische PostgreSQL-Instanz: drei versionierte Migrationen | angewendet |
| Migration erneut ausführen | keine offenen Migrationen |
| Demo-Seed wiederholen | unveränderte Datensatzanzahlen |
| Vitest Unit | 10 Tests bestanden |
| PostgreSQL-Integration | 21 Tests bestanden |
| Playwright/Chromium | 7 Tests bestanden |
| TypeScript | erfolgreich |
| Produktionsbuild und Standalone-Vorbereitung | erfolgreich |
| Standalone-Smoke: Datenbank, anonyme Zugriffe, CSP, abgelehnte Demo-Session | erfolgreich |
| Docker-Build und Container-Smoke mit PostgreSQL | erfolgreich, Runtime-UID 1000 |
| Runtime-Artefakt: keine `.env`-/Setup-Dateien oder Build-CA | geprüft |
| Produktionsabhängigkeiten: npm audit | keine gemeldeten Schwachstellen |

Integration prüft reale Abfragen für öffentliche, persönliche, Standort-, Gruppen- und Organisationseinheitensichtbarkeit, getrennte Sprachrechte, Kontodeaktivierung, SQL-Constraints, Audit-Schutz und Entra-Object-ID-Mapping. Browsertests prüfen unauthentifizierte Zugriffe, falsches Passwort, fehlenden CSRF-Token, Mitarbeiter-/Admin-/Ausbilderansichten, mobile Navigation und Abmelden. Der testspezifische `server-only`-Alias ist nur in Vitest wirksam.

Native Prisma-Engine-Downloads waren mit HTTP 403 blockiert. Offizielle WASM-Pakete ersetzen die ausführende Engine, ohne TLS-/Prüfsummenprüfung abzuschalten. Native CLI bleibt optional und ungetestet. Wegen gepinnter interner APIs müssen Schema, Generator, Migrationen und SQL-Funktionsausführung bei Upgrades gemeinsam neu geprüft werden.

Der Docker-Build benötigt in dieser Cloud die vorhandene Proxy-Namensauflösung per `--add-host`, die vorhandenen Proxy-Variablen und das bereitgestellte CA-Bundle als temporäres BuildKit-Secret. Ohne diese Konfiguration scheiterten die Downloads an DNS beziehungsweise TLS-Vertrauen. Die geprüfte Korrektur übernimmt die vorhandene vertrauenswürdige CA; Verifikation bleibt eingeschaltet. Node- und PostgreSQL-Images sind mit Digests fixiert. Die OpenSSL-Erkennungswarnung des Prisma-Generators bezieht sich auf native Engines; der geprüfte WASM-/PostgreSQL-Treiberbetrieb verwendet sie nicht.

Bekannte transitive Fehler in `deepmerge-ts`, `mysql2` und `esbuild` wurden durch getestete Versions-Overrides behoben. Der gesamte Development-Dependency-Scan meldet weiterhin ein nicht behobenes `braces`-/`micromatch`-Problem in der Prisma-Clientgenerator-Kette (GHSA-vfj7-8cjw-p6xm). Es betrifft Generator-Dateimuster; keine ungeprüften externen Glob-Muster an Buildwerkzeuge weiterreichen. Generatorpakete werden nicht ins Web-Standalone übernommen. Der Produktions-Dependency-Scan ist sauber. Aktualisierung prüfen, sobald ein Upstream-Fix vorliegt.

## Externe Konfiguration und nächste Phase

Reale Entra-Tenant-/App-Werte, Clientsecret, App-Zuweisungen und eingerichtete Mitarbeiter-/Rollenbindungen fehlen. Daher wurde kein echtes HWK-SSO geprüft. Das lokale Mapping ist implementiert und mit PostgreSQL getestet; die Tenant-Verbindung ist nach Einrichtung separat zu validieren.

Im Cloud-Konfigurationsentwurf sind die zusätzlichen Netzwerkziele `binaries.prisma.sh` für die optionale native CLI und `login.microsoftonline.com` für Entra gespeichert. Entwurfspeicherung veröffentlicht keine Umgebung und führt keine Befehle aus. Der WASM-Entwicklungsweg funktioniert bereits ohne den nativen Download.

Zusätzlich gespeichert: vollständiges `install_script` für Lockfile-Installation/Clientgenerierung, `start_skill` für Neustart und Prüfung von PostgreSQL und Dev-Server, Variablenanforderungen `ENTRA_TENANT_ID`/`ENTRA_CLIENT_ID` sowie die Secret-Anforderung `ENTRA_CLIENT_SECRET` für den Microsoft-Login-Endpunkt. Keine Secret-Werte wurden in die Konfiguration kopiert. Zum Aktivieren den Entwurf in den Umgebungseinstellungen prüfen und speichern, anschließend die Umgebung veröffentlichen. Eine Wiederherstellung in einer neuen Cloud-Aufgabe wurde nicht behauptet oder getestet.

Phase 3 folgt mit Event-Wizard, Stammdatenbearbeitung, Kalender, Aufgaben, Auswirkungen und verbindlichem Reservierungs-/Konfliktdienst. Produktivbetrieb setzt diese Fachfunktionen, HWK-Freigaben und Betriebs-/Datenschutzprozesse voraus.
