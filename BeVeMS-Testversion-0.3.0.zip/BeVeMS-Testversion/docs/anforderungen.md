# Rolle und Aufgabe

Du bist ein erfahrener Softwarearchitekt, Full-Stack-Entwickler und UX-Designer mit Erfahrung in:

- öffentlichen beziehungsweise öffentlich-rechtlichen Organisationen
- Veranstaltungsmanagement
- Ressourcen- und Raumplanung
- Microsoft-365-Integration
- datenschutzkritischen Anwendungen
- rollenbasierten Unternehmensanwendungen

Entwickle eine professionelle Webanwendung für die **Handwerkskammer Koblenz**.

Der Arbeitstitel lautet:

# HWK Veranstaltungs- & Besuchsmanagement

Die Anwendung soll eine zentrale Plattform für **besondere Veranstaltungen und externe Besuche** innerhalb der Handwerkskammer darstellen.

Sie soll NICHT das allgemeine Tagesgeschäft ersetzen.

Insbesondere folgende Vorgänge bleiben außerhalb des Systems:

- überbetriebliche Lehrgänge
- reguläre Weiterbildungen
- regulärer Unterricht
- tägliche Raumbelegungen des Ausbildungsbetriebs
- normale interne Besprechungen

Diese Vorgänge werden bereits über andere Systeme, insbesondere **ODAV**, organisiert.

Die neue Anwendung ist für besondere, organisationsrelevante Veranstaltungen bestimmt.

---

# 1. Strategisches Ziel

Die zentrale Frage der Anwendung lautet:

**Was findet wann und wo statt, wer ist beteiligt, wie weit ist die Vorbereitung und welche Auswirkungen hat die Veranstaltung auf den Betrieb?**

Die Anwendung soll vier eng miteinander verbundene Module besitzen:

# MODUL 1 – EVENTS

Veranstaltungen und Besuchergruppen verwalten.

# MODUL 2 – ORTE & RESSOURCEN

Standorte, Gebäude, Räume und Lehrwerkstätten verwalten und reservieren.

# MODUL 3 – AUFGABEN & ORGANISATION

Verantwortlichkeiten, Aufgaben, Ablaufpläne und Planungsfortschritt steuern.

# MODUL 4 – INFORMATION & KOMMUNIKATION

Mitarbeiter informieren, E-Mails versenden, Outlook-Termine erzeugen und betriebliche Auswirkungen transparent machen.

Die Module sollen technisch klar getrennt, fachlich aber miteinander verbunden sein.

---

# 2. Veranstaltung als zentrales Objekt

Das zentrale Objekt des Systems ist:

EVENT

Alle besonderen Termine werden darüber verwaltet.

Ein Event besitzt einen konfigurierbaren Event-Typ.

Standardmäßig sollen folgende Typen hinterlegt werden:

- Delegation
- Schulklasse
- Meisterfeier
- Freisprechungsfeier
- Nacht der Technik
- Workshop
- politische Veranstaltung
- Seminar
- Messe
- sonstige Veranstaltung

Diese Liste darf NICHT hart codiert sein.

Administratoren müssen jederzeit weitere Veranstaltungstypen hinzufügen, bearbeiten oder deaktivieren können.

---

# 3. Teilnehmerstruktur

Eine Veranstaltung kann sein:

- intern
- extern
- gemischt

Beispiele:

## Extern

Internationale Delegation.

## Intern

Besondere Mitarbeiterveranstaltung.

## Gemischt

Meisterfeier mit Mitarbeitern, Absolventen, Angehörigen, Politik und Ehrenamt.

---

# 4. Standorte, Gebäude und Räume

Es dürfen keine festen Standorte im Quellcode hinterlegt werden.

Administratoren müssen folgende Hierarchie verwalten können:

Standort  
→ Gebäude  
→ Räume / Bereiche / Lehrwerkstätten

Ein Standort besitzt beispielsweise:

- Name
- Adresse
- Beschreibung
- aktiv / inaktiv

Ein Gebäude besitzt:

- Name
- Standort
- Kurzbezeichnung
- Beschreibung

Ein Raum besitzt:

- Name
- Raumbezeichnung
- Gebäude
- Etage
- Kapazität
- Raumtyp
- Barrierefreiheit
- technische Hinweise
- aktiv / inaktiv

Raumtypen beispielsweise:

- Konferenzraum
- Seminarraum
- Veranstaltungssaal
- Foyer
- Mensa
- Besprechungsraum
- Lehrwerkstatt
- Außenfläche
- sonstiger Raum

Die Raumtypen müssen ebenfalls administrierbar sein.

---

# 5. Lehrwerkstätten

Lehrwerkstätten sind besondere Räume.

Pro Lehrwerkstatt müssen hinterlegt werden können:

- Name
- Gewerk
- Standort
- Gebäude
- Raum
- Beschreibung
- maximale Besucherzahl
- zuständige Ausbilder
- verfügbare Sprachen
- Sicherheitsanforderungen
- mögliche Vorführungen / Specials
- Standarddauer eines Besuches
- aktiv / inaktiv

Beispiele für Gewerke:

- Elektro
- SHK
- Tischler
- Metall
- Schweißen
- Kfz
- Maler und Lackierer
- weitere Gewerke

Die Gewerke müssen administrierbar sein.

---

# 6. Mitarbeiter und Ausbilder

Erstelle eine Mitarbeiterverwaltung.

Pro Mitarbeiter:

- Vorname
- Nachname
- E-Mail
- Funktion
- Organisationseinheit
- Standort
- aktiv / inaktiv

Mitarbeiter können bestimmten Lehrwerkstätten beziehungsweise Gewerken zugeordnet werden.

Bei Ausbildern müssen zusätzlich Sprachkenntnisse hinterlegt werden können.

---

# 7. Sprachkenntnisse

Verwende möglichst den Europäischen Referenzrahmen:

- A1
- A2
- B1
- B2
- C1
- C2
- Muttersprache

Beispiel:

Max Mustermann

Elektrotechnik

Deutsch – Muttersprache  
Englisch – C1  
Französisch – B1

Diese Daten dienen insbesondere zur Planung internationaler Delegationen.

Sprachkenntnisse sind personenbezogene interne Daten und dürfen nur für dafür berechtigte Personen sichtbar sein.

---

# 8. Intelligente Vorauswahl bei internationalen Delegationen

Bei der Anlage einer internationalen Delegation soll der Benutzer mindestens erfassen:

- Herkunftsland
- hauptsächliche Sprache
- weitere mögliche Sprachen
- Interessen / gewünschte Gewerke
- Teilnehmerzahl
- Zeitrahmen

Anschließend soll das System automatisch geeignete Lehrwerkstätten vorschlagen.

Dabei berücksichtigen:

1. gewünschtes Gewerk
2. Werkstattverfügbarkeit
3. Gruppengröße
4. Sprache der Delegation
5. Sprachkenntnisse der Ausbilder
6. Verfügbarkeit geeigneter Ausbilder

Darstellung beispielsweise:

### Elektrowerkstatt

Verfügbar

Ausbilder:
Thomas Müller

Englisch:
C1

**Empfehlung: sehr gut geeignet**

---

### Tischlerwerkstatt

Verfügbar

Ausbilder:
Peter Beispiel

Englisch:
B2

**Empfehlung: geeignet**

---

### Schweißwerkstatt

Verfügbar

Kein Ausbilder mit ausreichenden Englischkenntnissen.

**Hinweis: Übersetzung erforderlich**

Diese Logik soll zunächst regelbasiert umgesetzt werden und keine externe KI-API benötigen.

---

# 9. Reservierungen

Das System soll Räume und Lehrwerkstätten verbindlich reservieren können.

Vor jeder Reservierung muss eine Konfliktprüfung erfolgen.

Geprüft werden mindestens:

- Raum bereits reserviert
- Werkstatt bereits reserviert
- Veranstaltung überschneidet sich
- Auf- oder Abbauzeit kollidiert
- Kapazität reicht nicht aus
- Werkstatt ist gesperrt
- verantwortlicher Ausbilder ist bereits anderweitig eingeplant

Konflikte sollen vor dem Speichern deutlich angezeigt werden.

Eine Doppelbelegung soll nur mit entsprechender Berechtigung und dokumentierter manueller Übersteuerung möglich sein.

---

# 10. Externe Raumverwaltung / FM-System

Die Handwerkskammer verwendet zusätzlich ein separates FM-System zur Raumverwaltung.

Das konkrete Produkt ist derzeit nicht bekannt.

Deshalb:

Entwickle die Architektur so, dass später ein externer Raumbelegungsdienst integriert werden kann.

Erstelle dafür eine abstrahierte Schnittstelle, beispielsweise:

RoomAvailabilityProvider

oder

RoomManagementAdapter

Die Anwendung darf nicht fest von einem bestimmten FM-Produkt abhängig sein.

Spätere Möglichkeiten:

- REST API
- Microsoft Graph
- Datenbank-Schnittstelle
- Import
- Webservice

---

# 11. Hauptverantwortung und Teilverantwortung

Jede Veranstaltung benötigt mindestens einen:

EVENT OWNER

Zusätzlich können beliebig viele Teilverantwortliche hinterlegt werden.

Beispiele:

Gesamtorganisation  
Empfang  
Catering  
IT  
Technik  
Öffentlichkeitsarbeit  
Hausmeister  
Sicherheit  
Lehrwerkstätten  
Geschäftsführung

Eine Person kann für mehrere Bereiche verantwortlich sein.

---

# 12. Regelmäßig eingebundene interne Bereiche

Folgende Bereiche sollen als Standard vorhanden sein:

- Empfang
- Mensa
- IT
- Hausmeister
- Technik
- Öffentlichkeitsarbeit
- Geschäftsführung
- Sicherheitsbeauftragte
- Ausbilder / Lehrwerkstätten

Diese Liste muss administrierbar bleiben.

---

# 13. Aufgabenmanagement

Das Aufgabenmanagement soll bewusst einfach gehalten werden.

Eine Aufgabe besitzt:

- Titel
- Beschreibung
- verantwortliche Person
- Fälligkeitsdatum
- Status
- Bezug zur Veranstaltung

Status:

OPEN  
IN_PROGRESS  
DONE

Optional:

- Priorität

Keine komplexe Projektmanagementsoftware mit Gantt, Abhängigkeiten oder Ressourcenstunden entwickeln.

---

# 14. Planungsfortschritt

Der Planungsfortschritt einer Veranstaltung wird aus den Aufgaben berechnet.

Beispiel:

10 Aufgaben insgesamt

7 erledigt

→ Planungsfortschritt: 70 %

Darstellung als Fortschrittsbalken.

Zusätzlich soll zwischen normalen und kritischen offenen Aufgaben unterschieden werden können.

---

# 15. Ablaufplan

Für Veranstaltungen kann ein detaillierter Ablaufplan erstellt werden.

Ein Programmpunkt enthält:

- Beginn
- Ende
- Titel
- Beschreibung
- Standort
- Gebäude
- Raum
- Lehrwerkstatt
- verantwortliche Person
- interne Hinweise

Programmpunkte sollen per Drag-and-Drop sortiert werden können.

Für Delegationen beispielsweise:

09:00 Ankunft

09:15 Begrüßung

09:30 Elektrowerkstatt

10:00 SHK

10:30 Tischler

11:00 Gespräch Geschäftsführung

12:00 Mittagessen

---

# 16. Betriebliche Auswirkungen

Dieser Bereich ist ein zentrales Kernfeature.

Mitarbeiter müssen nicht nur wissen, DASS eine Veranstaltung stattfindet.

Sie müssen auch erkennen können, WAS dies für ihren Arbeitsalltag bedeutet.

Eine Veranstaltung kann beliebig viele betriebliche Auswirkungen besitzen.

Standardkategorien:

- Parkplatz
- Mensa
- Foyer
- Zufahrt
- Raum
- Werkstatt
- Lärm
- Öffnungszeiten
- Sicherheit
- Besucheraufkommen

Diese Kategorien müssen administrierbar sein.

Zusätzlich ist Freitext möglich.

Beispiel:

# Meisterfeier

## Auswirkungen auf den Betrieb

⚠ Parkplatz

Parkplatz P2 ist ab 13:00 Uhr gesperrt.

⚠ Foyer

Das Foyer in Gebäude A steht ab 12:00 Uhr nicht zur Verfügung.

⚠ Mensa

Die Mensa schließt an diesem Tag bereits um 14:30 Uhr.

⚠ Besucheraufkommen

Ab 16:00 Uhr werden rund 450 externe Gäste erwartet.

Diese Hinweise sollen für Mitarbeiter besonders prominent dargestellt werden.

---

# 17. Startseite für normale Mitarbeiter

Normale Mitarbeiter benötigen eine bewusst reduzierte Informationsansicht.

Keine komplexe Veranstaltungsplanung.

Startseite:

# Heute bei uns

Alle besonderen Veranstaltungen des Tages.

# Diese Woche

Relevante kommende Veranstaltungen.

# Betriebliche Hinweise

Auswirkungen auf:

- Parkplatz
- Mensa
- Gebäude
- Räume
- Zufahrt
- Sicherheit
- Besucheraufkommen

# Für mich relevant

Veranstaltungen, bei denen der aktuelle Mitarbeiter:

- Event Owner ist
- Teilverantwortlicher ist
- eine Aufgabe besitzt
- als Beteiligter eingetragen ist
- einen Programmpunkt verantwortet

---

# 18. Dashboard für Organisatoren

Organisatoren erhalten zusätzlich:

## Kommende Veranstaltungen

## Planungsfortschritt

## Offene Aufgaben

## Überfällige Aufgaben

## Raumkonflikte

## Veranstaltungen mit kritischen Punkten

## Meine Veranstaltungen

## Noch nicht bestätigte Reservierungen

---

# 19. Rollen und Berechtigungen

Berechtigungen dürfen nicht ausschließlich über fest programmierte Rollen geregelt sein.

Es soll ein administrierbares Rollen- und Rechtesystem geben.

Beispielrollen:

### Administrator

Vollzugriff.

### Veranstaltungsmanagement

Veranstaltungen erstellen, bearbeiten und organisieren.

### Standortverantwortlicher

Veranstaltungen und Ressourcen des eigenen Standortes verwalten.

### Event Owner

Eigene Veranstaltung umfassend verwalten.

### Teilverantwortlicher

Zugewiesene Bereiche und Aufgaben bearbeiten.

### Ausbilder

Eigene Werkstatt, Sprachkenntnisse und zugewiesene Besuche einsehen.

### Mitarbeiter

Informationszugriff.

Die konkreten Rechte müssen granular konfigurierbar sein.

Beispiele:

event.view

event.create

event.edit

event.delete

room.reserve

employee.view_languages

participant.view

participant.export

administration.manage

---

# 20. Sichtbarkeit einzelner Veranstaltungen

Nicht jede Veranstaltung muss automatisch für alle Mitarbeiter sichtbar sein.

Pro Veranstaltung soll eine Sichtbarkeit eingestellt werden können:

- alle Mitarbeiter
- Standort
- bestimmte Organisationseinheiten
- nur Beteiligte
- individuell definierte Benutzergruppen

Besonders sensible Veranstaltungen dürfen nur einem begrenzten Nutzerkreis angezeigt werden.

---

# 21. E-Mail-Kommunikation

Wenn ein Mitarbeiter als:

- Event Owner
- Teilverantwortlicher
- Aufgabenverantwortlicher

eingetragen wird, erhält er automatisch eine E-Mail.

Zusätzlich besitzt jede Veranstaltung ein Feld:

## Weitere E-Mail-Empfänger

Dort können zusätzliche Personen hinterlegt werden.

Diese erhalten relevante Informationen beziehungsweise Änderungen.

Architektur für:

Microsoft 365 / Exchange Online / Microsoft Graph.

---

# 22. Outlook-Termine

Beteiligte Personen sollen automatisch einen Outlook-Termin erhalten können.

Der Termin enthält mindestens:

- Veranstaltungsname
- Datum
- Uhrzeit
- Ort
- Rolle
- Link zur Veranstaltung
- kurze Beschreibung

Ändert sich der Termin, soll ein aktualisierter Termin versendet werden.

Wird die Veranstaltung abgesagt, soll auch der Outlook-Termin aktualisiert beziehungsweise abgesagt werden.

---

# 23. Microsoft-365-Integration

Die Handwerkskammer nutzt:

- Microsoft 365
- Exchange / Outlook
- Teams
- Entra ID
- SharePoint

Das System soll deshalb langfristig eng in diese Umgebung integrierbar sein.

Priorität:

## Entra ID

Single Sign-on.

## Microsoft Graph

E-Mails und Kalender.

Später denkbar:

## Teams

Benachrichtigungen.

## SharePoint

Dokumentenablage.

Implementiere Integrationen modular über Services beziehungsweise Adapter.

---

# 24. Teilnehmermanagement

Veranstaltungen sollen sowohl Teilnehmergruppen als auch Einzelteilnehmer verwalten können.

Teilnehmerfelder beispielsweise:

- Vorname
- Nachname
- Organisation
- Funktion
- E-Mail
- Teilnehmerkategorie
- Anmeldestatus
- Anwesenheitsstatus

Kategorien beispielsweise:

- Mitarbeiter
- Politik
- Unternehmen
- Ehrenamt
- Delegation
- Schüler
- Presse
- Referent
- Begleitperson
- sonstige

Diese Kategorien müssen administrierbar sein.

---

# 25. Einladungsmanagement

Die Anwendung soll Einladungen unterstützen.

Status:

- noch nicht eingeladen
- eingeladen
- zugesagt
- abgesagt
- keine Rückmeldung

Einladungslisten sollen erstellt und exportiert werden können.

Später sollen E-Mails direkt aus der Anwendung versendet werden können.

---

# 26. Anmeldung

Architektur für eine spätere Online-Anmeldung vorsehen.

Anforderungen:

- veranstaltungsspezifisches Formular
- individuelle Felder
- Datenschutzinformation
- Einwilligung falls erforderlich
- Teilnehmerlimit
- Warteliste
- Anmeldebestätigung

Diese Funktion darf in einer späteren Entwicklungsphase umgesetzt werden.

---

# 27. QR-Code Check-in

Für Veranstaltungen soll optional ein Check-in ermöglicht werden.

Jeder bestätigte Teilnehmer kann einen individuellen QR-Code erhalten.

Am Veranstaltungstag:

QR-Code scannen

→ Teilnehmer als anwesend markieren.

Zusätzlich muss manueller Check-in möglich sein.

---

# 28. Besucherorganisationen

Für externe Veranstaltungen soll eine Organisationsdatenbank entstehen.

Organisation:

- Name
- Typ
- Land
- Adresse
- Webseite optional
- Ansprechpartner
- frühere Besuche

Beispielsweise:

Ministerium

Handwerkskammer

Unternehmen

Verband

Schule

Botschaft

Internationale Organisation

---

# 29. Wiederholungsbesucher

Beim Anlegen einer neuen Delegation oder externen Veranstaltung soll geprüft werden:

War diese Organisation bereits bei uns?

Beispiel:

**Die Organisation war bereits dreimal zu Gast.**

12.05.2024

08.11.2025

03.04.2026

Alte Veranstaltungen sollen direkt geöffnet werden können.

---

# 30. Historie

Abgeschlossene Veranstaltungen müssen langfristig recherchierbar sein.

Die Historie enthält:

- Veranstaltung
- Veranstaltungsart
- Datum
- Teilnehmer
- Teilnehmerzahl
- externe Ansprechpartner
- besuchende Institutionen
- Ablaufplan
- besuchte Lehrwerkstätten
- verantwortliche Mitarbeiter
- beteiligte interne Bereiche
- Dienstleister
- Lessons Learned
- Dokumente
- optional tatsächliche Gesamtkosten

Wichtig:

Keine Kostenplanung oder Budgetsteuerung entwickeln.

Ein optionaler historischer Ist-Kostenwert darf jedoch dokumentiert werden.

---

# 31. Wiederkehrende Veranstaltungen

Unterstütze zwei Varianten:

## Serienveranstaltung

Beispielsweise regelmäßig wiederkehrender Termin.

## Jahreskopie

Beispielsweise:

Meisterfeier 2026

→ „Als Veranstaltung für 2027 kopieren“

Dabei können übernommen werden:

- Aufgaben
- Verantwortungsbereiche
- Ablaufstruktur
- Räume
- Checklisten
- interne Bereiche

Termine und Verantwortliche müssen anschließend überprüft werden.

---

# 32. Vorlagen

Veranstaltungen können als Vorlage gespeichert werden.

Beispiele:

- Internationale Delegation
- Schulklasse
- Meisterfeier
- Freisprechungsfeier
- Nacht der Technik
- Workshop
- Messe

Eine Vorlage kann enthalten:

- Standardaufgaben
- Standardverantwortlichkeiten
- typische Räume
- typische Ablaufpunkte
- Checklisten
- Kommunikationsschritte

---

# 33. Lessons Learned

Bei Abschluss einer Veranstaltung soll eine Nachbereitung möglich sein.

Felder:

- Was lief gut?
- Was lief schlecht?
- Was sollte beim nächsten Mal anders gemacht werden?
- besondere Vorkommnisse
- Verbesserungsvorschläge
- tatsächliche Teilnehmerzahl
- verwendete Dienstleister
- Dienstleister erneut einsetzen? Ja / Nein / Unentschieden

Bei einer Jahreskopie sollen relevante Lessons Learned der Vorveranstaltung angezeigt werden.

---

# 34. Dienstleister

Externe Dienstleister können einer Veranstaltung zugeordnet werden.

Beispielsweise:

- Catering
- Technik
- Security
- Veranstaltungsausstattung
- Fotograf
- sonstige

Pro Dienstleister:

- Unternehmen
- Ansprechpartner
- Kontaktdaten
- Leistung
- Bemerkung

Keine Lieferanten- oder Beschaffungssoftware entwickeln.

---

# 35. Dokumente

Veranstaltungen können Dokumente enthalten.

Beispiele:

- Einladung
- Ablaufplan
- Teilnehmerliste
- Sicherheitsinformationen
- Präsentationen
- Lageplan
- Cateringunterlagen
- Protokolle
- Fotos

Architektur so auslegen, dass später SharePoint als Dokumentenspeicher verwendet werden kann.

---

# 36. Suche

Globale Suche über:

- Veranstaltung
- Organisation
- Teilnehmer
- Ansprechpartner
- Standort
- Gebäude
- Raum
- Lehrwerkstatt
- Gewerk
- Mitarbeiter
- Datum
- Veranstaltungstyp

---

# 37. Kalender

Erstelle:

- Tagesansicht
- Wochenansicht
- Monatsansicht
- Listenansicht

Filter:

- Standort
- Gebäude
- Typ
- intern / extern / gemischt
- Verantwortlicher
- Status

---

# 38. Statusmodell

Events besitzen mindestens:

DRAFT

PLANNING

CONFIRMED

PREPARATION

READY

IN_PROGRESS

COMPLETED

CANCELLED

Statuswerte sollen technisch konfigurierbar beziehungsweise erweiterbar aufgebaut werden.

---

# 39. Datenschutz und Informationssicherheit

Diese Anwendung verarbeitet teilweise sensible personenbezogene und organisatorische Daten.

Datenschutz und Informationssicherheit haben höchste Priorität.

Berücksichtige insbesondere:

- DSGVO
- Datenminimierung
- Privacy by Design
- Privacy by Default
- rollenbasierte Zugriffe
- Least-Privilege-Prinzip
- sichere Authentifizierung
- Entra ID / SSO
- serverseitige Autorisierung
- serverseitige Validierung
- Schutz vor SQL Injection
- XSS-Schutz
- CSRF-Schutz
- sichere Sessionverwaltung
- verschlüsselte Übertragung
- verschlüsselte Speicherung sensibler Daten, soweit sinnvoll
- Audit Logging
- Zugriffstrennung
- Lösch- und Aufbewahrungskonzepte
- Export personenbezogener Daten
- nachvollziehbare Änderungen
- Schutz vor unberechtigten Teilnehmerlisten-Exports

Wichtig:

Eine ausgeblendete UI-Funktion ist keine ausreichende Berechtigungskontrolle.

Sämtliche Zugriffe müssen auch serverseitig geprüft werden.

---

# 40. Audit Log

Sicherheits- und organisationsrelevante Änderungen müssen protokolliert werden.

Beispiele:

09.10.2026 10:42  
Max Mustermann

Raum geändert:

A101 → B203

09.10.2026 11:13  
Maria Beispiel

Teilnehmer hinzugefügt.

09.10.2026 13:05  
Thomas Muster

Veranstaltungsstatus:

PLANNING → CONFIRMED

Audit-Logs dürfen nicht durch normale Benutzer veränderbar sein.

---

# 41. Deployment

Noch ist nicht entschieden, ob die Anwendung:

- On-Premises
- Private Cloud
- Public Cloud

betrieben wird.

Entwickle deshalb möglichst deployment-neutral.

Containerisierung:

Docker.

Konfiguration:

Environment Variables.

Keine unnötige Abhängigkeit von proprietärer Infrastruktur im Kernsystem.

Microsoft-Integrationen als Module beziehungsweise Adapter.

---

# 42. Technischer Stack

Bevorzugt:

## Frontend

Next.js  
React  
TypeScript

## Backend

Next.js Server Actions / API Routes oder klar abgegrenzte Services

## Datenbank

PostgreSQL

## ORM

Prisma

## Validierung

Zod oder vergleichbare Lösung

## Authentifizierung

Architektur auf Microsoft Entra ID vorbereiten.

## UI

professionelle Komponentenbibliothek

## Container

Docker

---

# 43. Softwarearchitektur

Vermeide einen monolithischen „alles in einer Datei“-Ansatz.

Strukturiere fachlich nach Domänen:

events/

locations/

rooms/

workshops/

employees/

participants/

tasks/

notifications/

reservations/

organisations/

audit/

integrations/

administration/

Dabei sollen Geschäftslogik und UI möglichst getrennt werden.

---

# 44. Datenmodell

Entwickle mindestens Entitäten für:

User

Role

Permission

Employee

EmployeeLanguage

Language

Organisation

ExternalContact

Event

EventType

EventStatus

EventResponsibility

EventParticipant

EventParticipantGroup

EventInvitation

EventScheduleItem

EventTask

EventImpact

EventLessonLearned

EventDocument

EventVendor

EventSeries

EventTemplate

Location

Building

Room

RoomType

Workshop

Trade

WorkshopEmployee

Reservation

RoomBlock

AuditLog

Notification

EmailRecipient

CalendarInvitation

CheckIn

Entwickle sinnvolle Relationen und normalisiere die Datenbank.

---

# 45. Aktuell NICHT Teil des MVP

Folgende Funktionen sollen ausdrücklich NICHT in der ersten Entwicklungsphase umgesetzt werden:

## Begrüßungsdisplays

Späterer Ideenspeicher.

## Digitale Türschilder

Späterer Ideenspeicher.

## Mehrsprachige Benutzeroberfläche

Späterer Ideenspeicher.

## Mitarbeiter-App

Späterer Ideenspeicher.

## Teams-Benachrichtigungen

Architektonisch vorbereiten, später umsetzen.

## vollständige SharePoint-Integration

Architektonisch vorbereiten.

## Kostenplanung

Nicht vorgesehen.

---

# 46. Ideenspeicher

Halte folgende zukünftige Erweiterungen in der Architektur beziehungsweise Dokumentation fest:

- automatische Begrüßungsbildschirme
- digitale Türschilder
- mehrsprachige Besucherbegrüßung
- mehrsprachige Benutzeroberfläche
- mobile Mitarbeiter-App
- Teams-Benachrichtigungen
- SharePoint-Dokumentenmanagement
- KI-gestützte Ablaufplanung
- automatische Delegationsrouten
- Besuchervorschläge nach Sprache
- Analyse vergangener Veranstaltungen
- intelligente Lessons-Learned-Auswertung

Nicht jetzt implementieren, sofern nicht technisch für eine saubere Architektur notwendig.

---

# 47. UX-Grundsatz

Das System besitzt drei Nutzungsebenen:

## Ebene 1 – INFORMIEREN

„Was ist heute beziehungsweise diese Woche los?“

Sehr einfach.

## Ebene 2 – MITARBEITEN

„Was muss ich tun?“

Eigene Aufgaben und Verantwortlichkeiten.

## Ebene 3 – ORGANISIEREN

„Wie plane und steuere ich die Veranstaltung?“

Vollständige Eventverwaltung.

Normale Mitarbeiter dürfen niemals durch Funktionen überfordert werden, die sie nicht benötigen.

---

# 48. Navigationsstruktur

Vorschlag:

## Startseite

Heute bei uns  
Diese Woche  
Betriebliche Hinweise  
Für mich relevant

## Veranstaltungen

Alle Veranstaltungen  
Kalender  
Neue Veranstaltung  
Vorlagen  
Serienveranstaltungen

## Teilnehmer & Gäste

Organisationen  
Ansprechpartner  
Teilnehmer

## Orte

Standorte  
Gebäude  
Räume  
Lehrwerkstätten  
Reservierungen

## Organisation

Aufgaben  
Mitarbeiter  
Ausbilder & Sprachen

## Historie

Abgeschlossene Veranstaltungen  
Lessons Learned

## Administration

Veranstaltungstypen  
Gewerke  
Sprachen  
Rollen & Rechte  
Kategorien  
Systemeinstellungen  
Integrationen

---

# 49. Neue Veranstaltung – Wizard

Entwickle einen übersichtlichen mehrstufigen Wizard.

## Schritt 1

Was findet statt?

- Titel
- Veranstaltungstyp
- intern / extern / gemischt
- Beschreibung

## Schritt 2

Wann?

- Datum
- Beginn
- Ende
- ggf. mehrtägig
- Serie

## Schritt 3

Wo?

- Standort
- Gebäude
- Räume
- Lehrwerkstätten

Konfliktprüfung durchführen.

## Schritt 4

Wer kommt?

- Teilnehmerzahl
- Teilnehmergruppen
- Organisation
- externe Ansprechpartner
- Herkunftsland
- Sprache

Bei Delegationen:

automatische Werkstatt- und Ausbildervorschläge.

## Schritt 5

Wer organisiert?

- Hauptverantwortlicher
- Teilverantwortliche
- interne Bereiche

## Schritt 6

Was muss vorbereitet werden?

Aufgaben erzeugen.

Optional aus Vorlage.

## Schritt 7

Auswirkungen auf den Betrieb

- Kategorien
- Zeitraum
- Beschreibung
- betroffene Mitarbeitergruppen

## Schritt 8

Kommunikation

- E-Mail-Empfänger
- Outlook-Einladung
- Sichtbarkeit

## Schritt 9

Zusammenfassung

Zeige:

- Veranstaltung
- Termin
- Orte
- Teilnehmer
- Verantwortliche
- offene Konflikte
- Auswirkungen
- Kommunikationsmaßnahmen

Erst danach Veranstaltung bestätigen.

---

# 50. Demo-Daten

Erstelle sinnvolle Seed-Daten.

Mindestens:

1. internationale Delegation
2. Schulklasse
3. Meisterfeier
4. Freisprechungsfeier
5. Nacht der Technik
6. Workshop
7. politische Veranstaltung
8. Messe

Erstelle außerdem:

mehrere Standorte

mehrere Gebäude

mehrere Räume

mehrere Lehrwerkstätten

mehrere Gewerke

mehrere Ausbilder mit unterschiedlichen Sprachkenntnissen

Damit alle wichtigen Funktionen demonstrierbar sind.

---

# 51. Tests

Automatisierte Tests insbesondere für:

- Rollen und Rechte
- Raumreservierungen
- Doppelbuchungen
- Werkstattverfügbarkeit
- Sprachmatching
- Ausbildervorschläge
- Planungsfortschritt
- Serienveranstaltungen
- Einladungstatus
- Outlook-Terminlogik
- Zugriff auf personenbezogene Daten
- Audit Logging

---

# 52. Vorgehensweise

Beginne NICHT sofort mit massenhaft UI-Code.

Arbeite strukturiert.

## PHASE 1 – Fachliches Modell

Liefere zunächst:

1. Systemarchitektur
2. Domänenmodell
3. Datenmodell
4. Rollen- und Berechtigungsmatrix
5. Integrationsarchitektur
6. Seitenstruktur
7. User Flows

## PHASE 2 – Technisches Grundgerüst

Erstelle:

- Repository-Struktur
- Datenbank
- Prisma-Schema
- Authentication
- Authorization
- Seed-Daten
- Basisnavigation

## PHASE 3 – MVP

Implementiere:

- Startseite
- Veranstaltungskalender
- Veranstaltungen
- Wizard „Neue Veranstaltung“
- Standorte
- Gebäude
- Räume
- Lehrwerkstätten
- Mitarbeiter
- Ausbilder
- Sprachkenntnisse
- Aufgaben
- Planungsfortschritt
- betriebliche Auswirkungen
- Raumreservierungen
- Konfliktprüfung

## PHASE 4 – Kommunikation

Implementiere:

- E-Mail-Logik
- Outlook-Kalendereinladungen
- Notifications

## PHASE 5 – Teilnehmermanagement

Implementiere:

- Teilnehmer
- Organisationen
- Einladungen
- Zusagen
- Absagen
- Teilnehmerlisten
- QR-Code
- Check-in

## PHASE 6 – Historie

Implementiere:

- abgeschlossene Veranstaltungen
- Kopierfunktion
- Serien
- Vorlagen
- Lessons Learned
- Dienstleister
- Audit Log

---

# 53. Dokumentation

Erstelle eine ausführliche README.md.

Enthalten sein müssen:

- fachlicher Zweck
- Systemarchitektur
- Technologie
- Installation
- Docker
- Umgebungsvariablen
- Datenbank
- Migrationen
- Seed-Daten
- Rollenmodell
- Integrationen
- Entwicklungsumgebung
- Produktivbetrieb
- Datenschutz
- Backup-Konzept
- Deploymentoptionen

---

# 54. Entscheidungsgrundsätze

Wenn bei der Implementierung Entscheidungen notwendig werden:

Priorisiere in dieser Reihenfolge:

1. Informationssicherheit
2. Datenschutz
3. einfache Bedienung
4. fachlich korrekte Prozesse
5. Wartbarkeit
6. Erweiterbarkeit
7. Performance
8. visuelle Gestaltung

Vermeide Overengineering.

Das System soll professionell und langfristig wartbar sein.

---

# 55. Endziel

Das System soll langfristig zur zentralen Informations- und Organisationsplattform für besondere Veranstaltungen der Handwerkskammer Koblenz werden.

Ein normaler Mitarbeiter muss innerhalb weniger Sekunden beantworten können:

**Was ist heute los?**

**Was findet diese Woche statt?**

**Gibt es Einschränkungen für mich?**

**Bin ich an einer Veranstaltung beteiligt?**

Ein Organisator muss zusätzlich beantworten können:

**Wie weit ist die Planung?**

**Welche Aufgaben sind offen?**

**Wer ist verantwortlich?**

**Welche Räume sind reserviert?**

**Gibt es Konflikte?**

**Wer nimmt teil?**

**Welche Lehrwerkstätten werden besucht?**

**Welche Ausbilder passen sprachlich zur Delegation?**

**Wer muss informiert werden?**

**Welche Auswirkungen hat die Veranstaltung auf den Betrieb?**

---

# DEINE ERSTE AUFGABE

Beginne jetzt ausschließlich mit PHASE 1.

Erstelle noch keinen vollständigen Anwendungscode.

Liefere zunächst:

1. eine vorgeschlagene Gesamtarchitektur
2. die vier Domänenmodule und deren Abhängigkeiten
3. ein Entity-Relationship-Modell
4. das Prisma-Datenmodell als ersten Entwurf
5. eine Rollen- und Berechtigungsmatrix
6. die Microsoft-365-Integrationsarchitektur
7. die Reservierungs- und Konfliktlogik
8. die Logik für internationale Delegationen und Sprachmatching
9. die Navigations- und Seitenstruktur
10. die wichtigsten User Flows
11. eine MVP-Abgrenzung
12. eine Liste technischer und fachlicher Annahmen

Markiere Entscheidungen, die später noch mit der Handwerkskammer geklärt werden müssen, ausdrücklich als:

**OFFENE ENTSCHEIDUNG**

Treffe bei allen anderen Punkten selbstständig sinnvolle und begründete Architekturentscheidungen.