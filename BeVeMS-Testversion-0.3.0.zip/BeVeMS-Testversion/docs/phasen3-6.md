# BeVeMS: Planungs-, Kommunikations-, Teilnehmer- und Historienausbau

Stand: 16.10.2026. Dieses Dokument ergänzt den historischen Phase-2-Nachweis. Die ursprünglichen Anforderungen bleiben in `anforderungen.md` unverändert.

## Bedienbare Abläufe

| Bereich | Implementierung |
| --- | --- |
| Veranstaltungsplanung | Neunstufiger Wizard, private Entwürfe, Bearbeitung mit Versionsprüfung, konfigurierte Statusübergänge, Absage samt lokaler Buchungen |
| Wizard | Grunddaten, Berlin-Zeit, Standort, Teilnehmerzahl/Land/Sprache/Gewerke, Owner, erste Aufgabe, erster Betriebshinweis, Empfänger, Sichtbarkeit und Zusammenfassung; nach Anlage ergänzt die Planungsseite Ressourcen, weitere Aufgaben und Verantwortungen |
| Kalender | Tag, Woche, Monat, Liste; Zeitraum, Standort, Gebäude, Typ, Struktur, Status und Owner-ID als serverseitige Filter; dieselbe Sichtbarkeit wie Eventdetail |
| Startseite | Heutige und kommende Termine, Betriebshinweise der kommenden Woche, eigene Beteiligungen, eigene offene Aufgaben sowie Fortschritt, kritische/überfällige Aufgaben und unbestätigte Reservierungen für berechtigte Planer |
| Organisation | Aufgaben mit Verantwortlichen, Fristen und Status, kritische Aufgaben, berechneter Fortschritt, Teilverantwortungen, Ablaufpunkte mit internen Hinweisen, Drag-and-drop sowie Tastatur-Sortierung |
| Auswirkungen | Kategorie, Zeit, interne Beschreibung, getrennte sichtbare Zusammenfassung, optionale Gruppenzielgruppen, prominent auf Start- und Detailseiten |
| Reservierungen | Räume und Werkstätten als dieselbe physische Ressource, Ausbilder, Auf-/Abbaupuffer, Kapazitäten, Sperren, Ausfälle, transaktional geprüfte Doppelbelegungen, Vormerkungen mit Ablauf und erneute Prüfung bei Bestätigung |
| Delegationsmatching | Gewerk, Gruppengröße, aktive Ressourcen, lokale Raum-/Ausbilderverfügbarkeit; B2 als geeignete Fachsprache, Hauptsprache vor Alternativen; separate Autorisierung vor Abruf von Sprachprofilen |
| Stammdaten | Kataloge anlegen/ändern/deaktivieren, Standorte/Gebäude/Räume/Werkstätten/Mitarbeiter anlegen und bearbeiten, Sprachen und Ausbilderzuordnung; Rollenrechte nach Scope ändern, Schutz der letzten aktiven Administration |
| Kommunikation | Interne Benachrichtigungen, zusätzliche Empfänger, getrennte Mail-/Kalender-Outbox, optionaler Graph-Worker, Outlook create/update/cancel, Abwahl von Kalenderempfängern, Versandprotokoll und bewusste Wiederaufnahme fehlgeschlagener Zustellungen |
| Gäste | Organisationen, Ansprechpartner, sichtbare frühere Besuche, Event-Zuordnung, Teilnehmergruppen und Einzelteilnehmer, Einladung-/Antwortstatus, berechtigter CSV-Export, QR-Ausgabe und Check-in per Scanner-Token oder manuell |
| Dokumente | Private Dateispeicherung über Adapter, Dateityp-/Größenprüfung, ClamAV-INSTREAM-Adapter, Quarantäne bei fehlendem/gestörtem Scanner, autorisierte und auditierte Downloads erst nach CLEAN |
| Historie | Abgeschlossene Events, Jahres-/Datums-Kopie, tägliche/wöchentliche/monatliche Serien mit IANA-Zeitzone, private Vorlagen, Lessons Learned und historische Ist-Kosten, Dienstleister und unveränderliches Änderungsprotokoll |
| Suche | Sichtbare Events/Typen/Datum, autorisierte Teilnehmer, Organisationen/Ansprechpartner, Räume/Gebäude/Standorte/Werkstätten/Gewerke und berechtigt sichtbare Mitarbeiter |

## Sicherheits- und Fachentscheidungen

- Default-Sichtbarkeit bleibt INVOLVED. Erstellen und Bearbeiten prüfen den alten und den neuen Berechtigungskontext. Nicht sichtbare Event-IDs geben keine Existenzdetails preis.
- Event-Mutationen sperren die Eventzeile. Jede Buchung sperrt zusätzlich Raum- und Ausbilderkennungen in deterministischer Reihenfolge per PostgreSQL-Transaktionslock. Eine parallele Buchung prüft anschließend den bereits aktualisierten Datenbestand.
- Abgelaufene Vormerkungen blockieren nicht mehr. CONFIRMED bleibt verbindlich; Stornierungen geben Ressourcen frei. Harte Sicherheitsblocks, inaktive Ressourcen, fehlende Ausbilder und Kapazitätsgrenzen sind nicht übersteuerbar. Weiche Konflikte brauchen `reservation.override`, mindestens 15 Zeichen Begründung und einen Freigabedatensatz je Konflikt. Titel fremder Events erscheinen nicht in Fehlermeldungen.
- Ohne FM-Anbindung wird keine organisationsweite Verfügbarkeit behauptet. Eine lokale Bestätigung braucht eine explizite Erklärung, dass die externe Belegung separat geklärt wurde. `RoomAvailabilityProvider` liefert bei fehlender Anbindung UNKNOWN.
- Terminänderungen mit aktiven Buchungen/Ablaufpunkten werden abgewiesen. Die Ressourcen/Ablaufpunkte zuerst lösen, dann verschieben und neu prüfen. Eine automatische komplexe Umplanung ist bewusst nicht vorhanden.
- Berlin-Zeit gilt unabhängig von der Browserzeitzone. Nicht existente oder doppeldeutige Uhrzeiten bei Sommerzeitwechsel werden im Editor abgewiesen. Serien halten die lokale Uhrzeit pro Auftreten konstant.
- READY erfordert erledigte kritische Aufgaben und bestätigte Ressourcen. Kopien/Vorlagen bleiben DRAFT, INVOLVED und prüfpflichtig; vor Bestätigung ist eine ausdrückliche fachliche Prüfung erforderlich. Teilnehmer, QR-Codes, Zusagen, Dokumente, Empfänger und aktive Buchungen werden nicht kopiert.
- Vorlagen sind standardmäßig privat beim Ersteller. Ein globales Erstellrecht veröffentlicht keine Vorlage aus einem sensiblen Event. Administratoren können bestehende Vorlagen betreuen; ein freigegebener Shared-Status ist im Modell vorbereitet.
- QR-Inhalte sind zufällige 256-Bit-Tokens ohne personenbezogene Inhalte. Nur SHA-256 wird gespeichert. Neue Ausgabe ersetzt den alten Hash. Ausgabe und Scan sind berechtigt, Check-in setzt Zusage und REGISTERED voraus und ist vom Vortag bis zum Folgetag möglich; wiederholter Scan ist idempotent. Die QR-Grafik wird über POST geladen, Geheimnisse erscheinen nicht in URLs. USB-Scanner/Tokeneingabe werden unterstützt; Kamera-Decodierung ist keine enthaltene Funktion.
- CSV-Export besitzt ein eigenes Recht, schreibt einen Audit-Eintrag und schützt vor Tabellenformeln. Löschungen entfernen Einladung und Check-in, der datensparsame Audit-Nachweis bleibt erhalten.
- Alle Fachänderungen und ihre Audit-Einträge werden in derselben Transaktion gespeichert. Audit-UPDATE/DELETE bleiben der Runtime-Identität verwehrt.

## Microsoft Graph in Betrieb nehmen

Die Entra-Anmelde-App und die Graph-Versand-App können getrennt bleiben. Der Worker verwendet Client Credentials mit Mail.Send und Calendars.ReadWrite als Application Permissions. Admin Consent und Exchange Application RBAC beziehungsweise eine passende Mailbox-Begrenzung auf das einzige Veranstaltungs-Postfach müssen tenantseitig eingerichtet werden. Keine tenantweiten Mailboxrechte ohne Begrenzung übernehmen.

Zusätzlich zu DATABASE_URL konfigurieren:

| Variable | Bedeutung |
| --- | --- |
| ENTRA_TENANT_ID | Expliziter Tenant |
| GRAPH_CLIENT_ID / GRAPH_CLIENT_SECRET | Separate Versand-App; Secret ausschließlich im Secret Store |
| GRAPH_SENDER | Eingeschränktes Veranstaltungs-Postfach |
| APP_BASE_URL | Kanonische HTTPS-Adresse für Links und Origin-Prüfung |
| GRAPH_DELIVERY_ENABLED | Nur `true` aktiviert den Versandbefehl |

`npm run worker:communication` verarbeitet höchstens 20 Aufträge pro Lauf; per Scheduler wiederholen. Keine automatische Ausführung beim Setup, Build oder Webstart. Mail und Kalender haben getrennte Aufträge. Datenbank-Lease verhindert parallele Workerzustellungen. Graph-Throttling wird mit Retry-After behandelt. Ein unklarer Netzwerkausgang wird FAILED / DELIVERY_OUTCOME_UNKNOWN statt blind erneut gesendet; zuerst Postfach prüfen, dann im Versandprotokoll ausdrücklich erneut freigeben. Graph-Mail garantiert technisch keine Exactly-once-Zustellung. Vor Zustellung werden aktuelle Empfänger nochmals geprüft. Nachrichten enthalten keine Teilnehmerlisten, internen Beschreibungen oder Sprachprofile.

Einladungsstatus bei Gästen ist zunächst ein dokumentierter Organisationsstatus. Öffentliche RSVP-Links und Online-Anmeldung sind gemäß ursprünglicher MVP-Abgrenzung spätere Erweiterungen. Kalenderabgleich ist für die explizit vorgemerkten Organisatoren/Empfänger umgesetzt; eine automatisierte Graph-Verarbeitung eingehender Gästeantworten ist nicht enthalten.

Der echte HWK-Tenant, Exchange-Zugriff und tatsächliche Zustellungen wurden nicht geprüft und während Entwicklung nicht verwendet.

## Dokumentablage und Scanner

`DOCUMENT_STORAGE_PATH` auf ein privates persistentes Verzeichnis setzen; Web- und Dokumentworker benötigen dieselbe Ablage. Im Webcontainer: `/var/lib/bevems/documents`, UID 1000. Das Verzeichnis als persistentes Volume mounten und mit Datenbankreferenzen gemeinsam sichern. Keine Ablage unter `public/`, keine öffentlichen Storage-URLs.

`CLAMAV_HOST` und optional `CLAMAV_PORT` (3310) zeigen auf einen vertrauenswürdigen internen clamd-Dienst mit aktuellen Signaturen. Ohne Dienst bleiben Dateien PENDING und können nicht heruntergeladen werden. `npm run worker:documents` prüft bis zu 50 ausstehende Dateien. Erkannte Schadsoftware wird gesperrt und aus dem Dateispeicher entfernt. Scanner-Datenverkehr bleibt im privaten Netz. Kein ClamAV-Dienst wurde hier eingerichtet oder als live getestet. SharePoint kann später `DocumentStorage` ersetzen.

## Workercontainer

```sh
docker build --target runtime -t bevems:web .
docker build --target worker -t bevems:worker .
```

Der letzte Standardtarget ist der Webruntime. Der Worker-Target enthält Source/TSX und die exakt installierte Laufzeitabhängigkeitsmenge (30 Pakete inklusive verschachtelter Versionsvarianten). Entwicklungs- und reine Peer-Werkzeuge wie die Prisma-CLI werden nicht übernommen. Konfiguration zur Laufzeit injizieren, `.env.setup` niemals in Web oder Worker laden. Worker mit demselben Netzwerk und Dokumentvolume, jedoch eigenen Secrets ausführen. Standardkommando ist der explizit geschützte Kommunikationsworker; für Scans `npm run worker:documents` verwenden. Alle Prozesse laufen unprivilegiert. In der Cloud gilt die Proxy-/CA-Variante der README auch für beide Targets.

## Aufbewahrung und Grenzen

`PARTICIPANT_RETENTION_DAYS` legt beim Anlegen der Einzelteilnehmer die technische Frist fest (Default 180 Tage). Die Rechtsgrundlage/Frist ist **OFFENE ENTSCHEIDUNG** und muss vor Produktivbetrieb freigegeben werden. Bestehende Datensätze werden durch eine spätere Variablenänderung nicht rückwirkend umdatiert.

`npm run participants:retention` zählt zunächst nur fällige Datensätze (maximal 500). Erst `PARTICIPANT_RETENTION_APPROVED=true` zusammen mit `npm run participants:retention -- --apply` löscht Daten aus abgeschlossenen/abgesagten Events einschließlich Einladungen und Check-ins mit Audit-Nachweis. Mehrfach ausführen, bis keine Kandidaten mehr vorliegen. Es wurde hier kein Löschlauf auf Entwicklungs- oder Produktivdaten ausgeführt. Organisationen, Ansprechpartner, Dokumente und Backups benötigen jeweils eine eigene freigegebene Frist und Betreiberprozesse.

Bewusste Vereinfachungen: Ressourcen werden nach dem Wizard am gespeicherten Entwurf gebucht; mehrere Aufgaben/Auswirkungen/Verantwortungen werden dort ergänzt. Eine Serie erzeugt begrenzt einzelne prüfpflichtige Entwürfe; es gibt keinen Editor „alle zukünftigen Termine gemeinsam ändern“. Ablauf-Sortierung ersetzt keine automatische Routenplanung. Große Listen sind begrenzt (Events 100, Kalender 1000, Suche 30 je Kategorie); produktive Massendaten benötigen Pagination. Kein Kosten-/Beschaffungsmodul, keine Teams-/SharePoint-Vollintegration, keine ODAV-Synchronisation, keine automatische FM-Buchung und keine öffentlich zugängliche Anmeldung.

## Validierung

Automatisierte Prüfungen: **74 Tests bestanden** (21 Unit-/Adaptertests, 43 PostgreSQL-Integrationstests, 10 Chromium-Browsertests). Typecheck, offizielle Prisma-Schemavalidierung mit negativem Gegenbeispiel und Produktionsbuild bestanden. Der Webcontainer wurde mit echter lokaler Datenbank geprüft: Health 200, anonyme APIs/Exporte/Dokumente 401, produktiv kein Demo-Login, CSP-Nonce, UID 1000, keine eingebetteten `.env`-Dateien und beschreibbare private Ablage. Produktionsabhängigkeiten: `npm audit --omit=dev` ohne bekannte Schwachstellen.

Auch der endgültige Workercontainer wurde gebaut und gestartet: externe Zustellung standardmäßig verweigert, UID 1000, keine `.env`-/Setup-Dateien oder Prisma-CLI, private Ablage beschreibbar, echter PostgreSQL-Aufbewahrungs-Dry-Run erfolgreich (keine Löschung). Container-Dateirechte und die Laufzeitpaketmenge wurden dabei korrigiert; Speicherengpässe des Cloud-Dockerbuilders wurden durch Bereinigung eigener alter Testimages und reproduzierbarer Buildcaches behoben. Datenbankvolumes und private Dokumente blieben erhalten. Live-Graph-Zustellung wurde dabei nicht aktiviert.

Nach Änderungen an der Benachrichtigungsqueue wurden die betroffenen 20 Planungsintegrationstests erneut erfolgreich ausgeführt. Der Aufbewahrungsbefehl wurde zusätzlich als echter Dry-Run gestartet (0 Kandidaten, 0 Löschungen). Die Löschfunktion und initiale Entra-Adminbindung wurden ausschließlich mit isolierten Testdaten geprüft. Unit- und Adaptertests verwenden Fake-Transport; PostgreSQL-Integrationstests laufen nur in der dedizierten Testdatenbank und setzen ausschließlich deren Testdaten zurück. Browserprüfungen verwenden die fiktive lokale Demo. Echte Tenant-/FM-/ClamAV-Abnahmen, produktive Restore-Tests und fachliche Abnahme sind gesondert erforderlich.

## Ersteinrichtung ohne Demo-Daten

Nach Migrationen und Runtime-Provisionierung kann eine vollständig leere Installation ohne Demo-Seed initialisiert werden. Im geschützten Laufzeitkontext die realen Werte für `ENTRA_TENANT_ID`, `BOOTSTRAP_ADMIN_OBJECT_ID` (Entra-oid), `BOOTSTRAP_ADMIN_FIRST_NAME`, `BOOTSTRAP_ADMIN_LAST_NAME`, `BOOTSTRAP_ADMIN_EMAIL`, `BOOTSTRAP_LOCATION_NAME`, `BOOTSTRAP_LOCATION_ADDRESS` und `BOOTSTRAP_UNIT_NAME` konfigurieren. Dann ausdrücklich `ALLOW_INITIAL_BOOTSTRAP=true` setzen und einmal `npm run installation:bootstrap` ausführen. Danach das Flag und die Bootstrap-Werte entfernen.

Der Befehl legt ausschließlich konfigurierbare Standardkataloge, einen echten Standort, eine Organisationseinheit und die explizite initiale Entra-Adminbindung an; keine Demo-Events und keine Mailzustellung. Sobald Benutzer, Mitarbeiter oder Standorte existieren, verweigert er eine erneute Initialisierung. Weitere Mitarbeiter entstehen in der Administration, ihre Entra-Bindungen über `db:provision-user`. Die tatsächliche Erstinitialisierung wird erst in eurer leeren Zielinstallation vorgenommen; hier wurde sie ausschließlich in der isolierten Testdatenbank geprüft.
