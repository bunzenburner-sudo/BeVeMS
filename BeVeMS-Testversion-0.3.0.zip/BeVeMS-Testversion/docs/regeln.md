# Berechtigungen, Integrationen und Fachregeln

## Rollen- und Berechtigungsmatrix

Rollen sind administrierbare Datensätze. `RolePermission` kombiniert einen Permission-Code mit dem Geltungsbereich ALL, LOCATION, OWN oder ASSIGNED. UserRole kann Standortbezug besitzen. Folgende Matrix ist eine Seed-Vorgabe, kein fest programmierter Rollenschalter.

| Recht | Admin | Management | Standort | Owner | Teilverantwortlich | Ausbilder | Mitarbeiter |
|---|---|---|---|---|---|---|---|
| event.view | alle | sichtbar | Standort/sichtbar | eigene | zugewiesen | zugewiesen/sichtbar | sichtbar |
| event.create | ja | ja | Standort | nein | nein | nein | nein |
| event.edit / event.cancel | alle | alle im Scope | Standort | eigene | zugewiesener Bereich | nein | nein |
| event.delete | ja¹ | nein | nein | nein | nein | nein | nein |
| room.reserve | alle | alle im Scope | Standort | eigene Events | nein | nein | nein |
| reservation.override | ja² | nein | nein | nein | nein | nein | nein |
| task.edit | alle | im Scope | Standort | eigene Events | zugewiesene | zugewiesene | zugewiesene |
| employee.view_languages | alle | Planungszweck | Standort | eigene Planung | nein | eigene Daten | nein |
| participant.view | alle | im Scope | Standort | eigene Events | explizit³ | nein | nein |
| participant.export | alle | explizit³ | nein | explizit³ | nein | nein | nein |
| participant.checkin | alle | im Scope | Standort | eigene Events | explizit³ | nein | nein |
| audit.view | alle | eigene Events | Standort | eigene Events | nein | nein | nein |
| administration.manage | ja | nein | nein | nein | nein | nein | nein |

¹ Physische Löschung unter Aufbewahrungsrichtlinie, kein allgemeines Löschen abgeschlossener Historie. ² Begründung Pflicht, harte Sperren ausgeschlossen. ³ Separate Rechtezuweisung; Rollenname allein genügt nicht. Administratorzugriff auf sensible Events ist protokolliert; eventuell getrennte Fachadministration ist eine offene Entscheidung.

### Serverseitige Zugriffskontrolle

Jeder Dienst prüft aktive Session, aktiven User, Permission und Scope; `event.view` erfordert zusätzlich Sichtbarkeitsprüfung. OWN bedeutet Event Owner, ASSIGNED nur das konkrete zugewiesene Objekt beziehungsweise den Verantwortungsbereich. LOCATION wird durch eine explizite Rolle am Standort begrenzt. Keine frei vom Client übernommene User-ID oder Scope-Angabe. Standortrollen dürfen auch bei Mehrstandortveranstaltungen nur Ressourcen ihres Standorts verändern.

Sichtbarkeit ALL_EMPLOYEES, LOCATIONS, UNITS, INVOLVED oder GROUPS wird serverseitig in Query-Prädikate übersetzt. Beteiligung umfasst Owner, Teilverantwortung, Aufgabe, Programmpunkt und EventInvolvement. Fehlende Sichtbarkeit liefert 404 ohne Titel/Metadaten. Suchindizes, Zähler, Historie, CSV, Kalender und Dokumentdownloads verwenden dieselbe Policy. Sprachprofile und Teilnehmerlisten erhalten Feldprojektionen nach eigenen Rechten. Bei Kalender- und Mailversand werden Empfänger vor Erstellung und Versand erneut geprüft; ein zusätzlich eingetragener Empfänger hebt Sichtbarkeit nicht automatisch auf.

OIDC Authorization Code Flow mit PKCE, State und Nonce; serverseitige Session, HttpOnly-/Secure-/SameSite-Cookies und Rotation. Token werden anhand Issuer, Audience, Signatur und Gültigkeit geprüft. Tenant wird fest begrenzt. Graph-Tokens bleiben serverseitig. Kein produktiver Demo-Login. Schreibende Requests benötigen Origin-/CSRF-Prüfung; Zod validiert vollständig auf dem Server. Parameterisierte Prisma-Abfragen, sichere Rich-Text-Verarbeitung, CSP und Export-Schutz vor CSV-Formelinjektion ergänzen Autorisierung. Rate Limits für Login, Exporte und Check-in.

## Microsoft-365- und Adapterarchitektur

| Port | Aufgabe | Erste Implementierung / spätere Adapter |
|---|---|---|
| IdentityProvider | geprüfte Identität mit Tenant und Subject | Entra OIDC; lokale Rollen bleiben verbindlich |
| MailProvider | idempotenter Kommunikationsauftrag, Zustellstatus | Graph `sendMail`; Entwicklungsadapter ohne externen Versand |
| CalendarProvider | create/update/cancel mit stabiler externer ID | Graph Outlook-Kalender; ICS-Export als getrennte Funktion |
| RoomAvailabilityProvider | fremde Belegung und Aktualitätsstatus | lokaler Adapter; später FM REST/Graph/Import |
| DocumentStorageProvider | upload/download/delete mit Scanstatus | privater Objektspeicher; später SharePoint |
| NotificationProvider | In-App-Benachrichtigung | Datenbank; Teams später |

Outbox: Fachänderung und Auftrag werden atomar gespeichert. Dedupe-Key enthält Event-ID, Änderungsversion, Empfänger und Operation. Worker beansprucht Nachricht exklusiv, prüft aktuelle Berechtigung, verarbeitet mit Backoff/Retry-After und Dead-Letter nach begrenzten Versuchen. Zustände PENDING/PROCESSING/SENT/FAILED; Erfolg wird erst nach Provider-Antwort markiert. „Outbox gespeichert“ bedeutet keine zugestellte E-Mail. `sendMail` garantiert keine Ende-zu-Ende-Zustellung; Betrieb erhält Fehler-/Retry-Ansicht.

Owner-, Verantwortungs- und Aufgabenzuweisungen erzeugen adressatengerechte Benachrichtigungen. Änderungen informieren zusätzliche berechtigte Empfänger; sensible interne Notizen gelangen nie automatisch in Einladungen. Outlook nutzt stabile externe IDs, ETags und monoton steigende Event-Versionen. Veraltete Updates werden verworfen. Datum/Ort/Absage aktualisieren bestehende Termine, statt neue Duplikate anzulegen. Absage annulliert aktive Buchungen atomar und erzeugt Kalender-Cancel-Aufträge. Versandoptionen werden ausdrücklich bestätigt.

**OFFENE ENTSCHEIDUNG:** Delegierte Graph-Rechte oder App-only, freigegebenes Organisatorpostfach, Entra-App-Registrierung, Tenant, Admin-Consent und Mailboxzugriffsbegrenzung. Empfehlung: separates technisches Postfach, geringstmöglicher Zugriff und Exchange Application RBAC. Keine echten E-Mails während Entwicklung; Live-Integration erst nach Freigabe und End-to-End-Test. Teams, SharePoint-Vollintegration und Online-Anmeldung bleiben spätere Phasen.

## Reservierungs- und Konfliktlogik

1. User-Rechte und Event-/Raumzugriff prüfen; validiertes Zeitintervall, Kapazität, aktive Hierarchie und Ausbilderzuordnung laden.
2. Belegungsintervall = `[Beginn − Aufbau, Ende + Abbau)`. Halb offene Intervalle erlauben unmittelbaren Anschluss ohne Puffer. Überschneidung: `a.start < b.end && b.start < a.end`. Alle Zeiten werden als Instants behandelt; Eingabe berücksichtigt Zeitzone und Sommerzeit.
3. Ausbilder und Räume in stabiler ID-Reihenfolge mit PostgreSQL-Transaktionslocks sperren. Event-Version für optimistische Konkurrenzprüfung kontrollieren; Serien und Mehrraumreservierungen atomar prüfen.
4. Aktive Buchungen (TENTATIVE und CONFIRMED), RoomBlock, EmployeeUnavailability und andere Ausbilderbuchungen prüfen. Event-Überschneidung wird bei gemeinsamen Ressourcen/Personen zum Konflikt; unabhängige parallele Events sind erlaubt. Workshop ist dieselbe Ressource wie sein Raum, niemals ein separater Buchungskanal.
5. Raumkapazität und Werkstatt-Maximum gegen tatsächliche Besuchsgruppe vergleichen. Sicherheitsregeln, Sperren, inaktive Räume oder fehlende Ausbilder sind sichtbar. Programmzeit muss innerhalb des Events liegen; Buchung kann durch Puffer darüber hinausreichen.
6. FM-Belegung über Provider mit Zeitpunkt und Herkunft prüfen. Unbekannte/veraltete externe Daten sind keine „frei“-Antwort. Keine lange externe HTTP-Anfrage unter DB-Lock; vorab abgefragte Evidenz wird auf zulässiges Alter geprüft. Für verbindliche externe Buchung ist ein Reservierungs-/Bestätigungsprotokoll erforderlich.
7. Konflikte strukturiert zurückgeben: Code, Ressource, Zeitraum, Schwere, öffentlich zulässige Beschreibung. Titel sensibler konkurrierender Events werden verborgen.
8. Ohne Konflikt atomar speichern, Audit und Outbox erzeugen. Übersteuerung nur mit `reservation.override`, Pflichtbegründung und je Konflikt gespeichertem Freigabedatensatz. Nur weiche Belegungskonflikte sind übersteuerbar; Sicherheitsblock, ungültige Zeit, unzulässiger Zugriff oder inaktive Ressource bleiben harte Fehler. Kapazitätsüberschreitung gilt zunächst als harter Fehler.

Status TENTATIVE reserviert bereits; abgelaufene Vormerkungen werden durch Worker freigegeben. CANCELLED/EXPIRED belegen nichts. Änderungen, Absagen und Serientermine benutzen denselben Dienst. Konfliktprüfung im Wizard ist vorläufig; beim finalen Speichern wird sie unter Lock wiederholt. Zwei gleichzeitige konfliktfreie Vorprüfungen dürfen nicht zwei verbindliche Buchungen erzeugen.

**OFFENE ENTSCHEIDUNG:** FM-Produkt, Datenhoheit, API, Freshness-Grenze, externe Schreibberechtigung und Verhalten bei FM-Ausfall. Empfehlung: unbekannte externe Belegung verhindert verbindliche Bestätigung; Entwurf bleibt speicherbar. Lokale Konfliktfreiheit darf bis dahin nicht als vollständige organisationsweite Verfügbarkeit bezeichnet werden.

## Internationale Delegationen und Sprachmatching

Eingabe: Herkunftsland, Hauptsprache, alternative Sprachen, gewünschte Gewerke, Teilnehmer-/Teilgruppengröße, Zeitfenster. Herkunftsland ersetzt keine Sprachangabe. Kandidaten kommen ausschließlich aus aktiven Werkstätten gewünschter Gewerke und aktiver Standort-/Gebäude-/Raumhierarchie.

Harte Filter: Sicherheits-/Raumsperre, Kapazität, belegte Werkstatt, fehlender oder zeitlich belegter Ausbilder. Sprachwertung je verfügbarer Ausbilder: A1=1, A2=2, B1=3, B2=4, C1=5, C2=6, Muttersprache=7. Für fachliche Führung gilt zunächst B2 als Mindestniveau. Hauptsprache wird vor Alternativsprache priorisiert; C1+ → „sehr gut geeignet“, B2 → „geeignet“, darunter/keine passende Sprache → „Übersetzung erforderlich“. Eine explizit bestätigte Dolmetschlösung kann die letzte Kategorie planbar machen, ohne falsche Sprachkenntnis zu suggerieren.

Ranking: gewünschtes Gewerk → erfüllte Verfügbarkeit/Kapazität → Hauptsprache → Sprachniveau → passende Besuchsdauer. Zeige Gründe, Kapazität, Sicherheitsanforderungen und Datenaktualität. Autorisierte Planer sehen Namen/Niveau; sonst nur „sprachlich passende Betreuung verfügbar“. Sprachkenntnisse werden nicht öffentlich exportiert. Vorschlag erzeugt noch keine Buchung. Finaler Speichervorgang prüft Raum und Ausbilder nochmals gemeinsam.

**OFFENE ENTSCHEIDUNG:** Mindestsprachniveau je Führung/Sicherheitsunterweisung, Verfügbarkeitsquelle der Ausbilder, Dolmetscherorganisation und Gruppenteilung. Zeitfenster-Splitting ist zunächst manuelle Planung; automatische Delegationsrouten später.

## Weitere Invarianten und Tests für die nächsten Phasen

Fortschritt = DONE / alle Aufgaben × 100, auf ganze Prozent gerundet; bei null Aufgaben „noch keine Aufgaben“, nicht 100 %. Kritische offene Aufgaben separat zählen. Status READY erfordert bestätigte Ressourcen und keine kritischen offenen Aufgaben; Übergangsdaten können weitere Bedingungen ergänzen.

Serien: RRULE mit IANA-Zeitzone, begrenzter Erzeugungshorizont, eigene Event-Instanz je Termin und stabilem Serien-/Occurrence-Key. Änderungen betreffen „diesen Termin“ oder „zukünftige Termine“; jede erzeugte Instanz wird individuell auf Konflikte geprüft. Jahreskopie übernimmt Struktur und überprüfbare Verantwortungen, aber keine Teilnehmer, Zusagen, QR-Tokens, aktiven Reservierungen oder externen Kalender-IDs. DRAFT und Review-Hinweis sind Pflicht.

Check-in-Token werden zufällig erzeugt, nur gehasht gespeichert und bei QR-Ausgabe ohne personenbezogene Inhalte codiert. Scanner braucht explizites Recht; Zusage, Veranstaltung und Token-Gültigkeit werden serverseitig geprüft. Wiederholter Check-in ist idempotent. Manuelle Anwesenheit ist auditierbar. Dokumente: private Speicherung, Dateigrößen-/Typgrenzen, Malware-Scan und autorisierter Download; Storage-Key niemals öffentliche URL.

Audit enthält Actor, UTC-Zeit, Aktion, Objekt, Event-Kontext und minimierte Delta-Felder. Fachänderung ohne Audit scheitert atomar. DB-Betriebsrolle für Audit verhindert UPDATE/DELETE durch Web/Worker. Sicherheits-/Exportzugriffe werden ebenfalls erfasst; keine Secrets, Token oder vollständigen Teilnehmerexporte im Log.

Geplante automatisierte Prüfungen: Permission/Scope/Sichtbarkeit einschließlich Suche und Export; echte parallele PostgreSQL-Buchungen; Puffer, Kapazitäten, Sperren und Ausbilder; Sprachranking; Fortschritt; Sommerzeit/Serien; Einladungstatus und idempotenter Check-in; Kalender create/update/cancel und Outbox-Retries; Audit-Atomarität. Diese Tests sind noch nicht implementiert oder ausgeführt.
