# Gesamtarchitektur und fachliches Modell

> Historischer Entwurfs-/Phasennachweis. Aktueller Implementierungsstand: [Phasen 3–6](phasen3-6.md).

Dieses Dokument hält den fachlichen Architekturentwurf aus Phase 1 fest. Den aktuellen Implementierungsstand einschließlich Migrationen und Prisma 7 beschreibt [Phase 2](phase2.md).

## 1. Architekturentscheidung

Ein modularer Monolith mit separatem Hintergrundworker bietet für die erwartete Organisationsanwendung kurze Transaktionen und überschaubaren Betrieb. Next.js bedient Browser und HTTP-Endpunkte. Fachliche Dienste kapseln Regeln und Transaktionen; React-Komponenten enthalten keine Autorisierungs- oder Reservierungslogik. PostgreSQL ist die verbindliche Datenquelle. Prisma bildet Relationen ab; sicherheitskritische PostgreSQL-Constraints werden durch versionierte SQL-Migrationen ergänzt.

```mermaid
flowchart TD
  Browser[React / Next.js UI] --> API[Server Actions / API Routes]
  Entra[Entra ID OIDC] --> Auth[Session und Autorisierung]
  API --> Auth
  API --> Events[Events]
  API --> Resources[Orte und Ressourcen]
  API --> Tasks[Aufgaben und Organisation]
  API --> Info[Information und Kommunikation]
  Events --> DB[(PostgreSQL)]
  Resources --> DB
  Tasks --> DB
  Info --> DB
  DB --> Worker[Transaktionale Outbox / Worker]
  Worker --> Graph[Graph Mail / Kalender]
  Resources --> FM[RoomAvailabilityProvider]
  Events --> Storage[DocumentStorageProvider]
```

UI und API rufen denselben autorisierten Anwendungsdienst auf. Transaktionen schreiben Fachänderung, Audit-Eintrag und gegebenenfalls Outbox-Nachricht gemeinsam. Worker arbeiten wiederholbar und mit begrenzten Retries; es erfolgt kein Graph-Aufruf innerhalb einer offenen Datenbanktransaktion.

## 2. Vier Domänenmodule

| Modul | Datenhoheit | Abhängigkeiten |
|---|---|---|
| Events | Event, Typ, Status, Beteiligte, Organisationen, Einladungen, Ablauf, Historie, Vorlagen, Serien, Dienstleister, Dokumentreferenzen | Ressourcenprüfungen und Aufgabenfortschritt über Dienste; Kommunikationsaufträge über Outbox |
| Orte & Ressourcen | Standort, Gebäude, Raum, Raumtyp, Werkstatt, Gewerk, Reservierungen und Sperren | Employee-Referenzen für Ausbilder; Event-ID als Buchungsbezug; externer FM-Adapter |
| Aufgaben & Organisation | Employee, Sprachen, Verantwortungsbereiche, EventResponsibility, EventTask | Event als fachlicher Kontext; Standorte und Gewerke als Referenzen |
| Information & Kommunikation | EventImpact, Notification, EmailRecipient, CalendarInvitation, Outbox | Autorisierte Event-Lesemodelle; Empfängerauflösung über Organisation; Graph-Adapter |

Identity, Administration und Audit sind Querschnittsdienste. Kein Modul liest fremde Tabellen für eigene Schreibentscheidungen ohne definierte Dienstgrenze. Ein gemeinsames relationales Schema erlaubt Transaktionen über diese Grenzen; Microservices sind zunächst unnötig.

Vorgesehene Struktur: `src/domains/{events,locations,rooms,workshops,employees,participants,tasks,notifications,reservations,organisations,audit,integrations,administration}`. Je Domäne: `schemas`, `service`, `repository`, `policies`, `components`; `src/app` enthält dünne Routen. Dokument- und Identitätsadapter liegen unter Integrationen.

## 3. ER-Modell

```mermaid
erDiagram
  User ||--o| Employee : identifiziert
  User ||--o{ UserRole : besitzt
  Role ||--o{ UserRole : zugewiesen
  Role ||--o{ RolePermission : besitzt
  Permission ||--o{ RolePermission : definiert
  Location ||--o{ Building : umfasst
  Building ||--o{ Room : umfasst
  RoomType ||--o{ Room : klassifiziert
  Room ||--o| Workshop : spezialisiert
  Trade ||--o{ Workshop : ordnet
  Workshop ||--o{ WorkshopEmployee : besetzt
  Employee ||--o{ WorkshopEmployee : unterrichtet
  Employee ||--o{ EmployeeLanguage : spricht
  Language ||--o{ EmployeeLanguage : bewertet
  Employee ||--o{ Event : verantwortet
  EventType ||--o{ Event : klassifiziert
  EventStatus ||--o{ Event : steuert
  Event ||--o{ EventResponsibility : verteilt
  Event ||--o{ EventTask : plant
  Event ||--o{ EventScheduleItem : ordnet
  Event ||--o{ EventImpact : informiert
  Event ||--o{ Reservation : bucht
  Room ||--o{ Reservation : belegt
  Room ||--o{ RoomBlock : sperrt
  Reservation ||--o{ ReservationInstructor : bindet
  Employee ||--o{ ReservationInstructor : betreut
  Organisation ||--o{ ExternalContact : hat
  Event ||--o{ EventOrganisation : besucht
  Organisation ||--o{ EventOrganisation : beteiligt
  Event ||--o{ EventParticipant : registriert
  Event ||--o{ EventParticipantGroup : gruppiert
  EventParticipant ||--o| EventInvitation : eingeladen
  EventParticipant ||--o| CheckIn : anwesend
  Event ||--o| EventLessonLearned : reflektiert
  Event ||--o{ EventDocument : dokumentiert
  Event ||--o{ EventVendor : beauftragt
  Vendor ||--o{ EventVendor : leistet
  EventSeries ||--o{ Event : erzeugt
  EventTemplate ||--o{ Event : initialisiert
  Event ||--o{ CalendarInvitation : synchronisiert
  Event ||--o{ EmailRecipient : informiert
  User ||--o{ AuditLog : bewirkt
```

Zusätzliche Join-Tabellen im Schema bilden Sichtbarkeit, Sprachen, Gewerke, Verantwortungen und Gruppen normalisiert ab. Eine Werkstatt besitzt genau einen Raum, dessen Gebäude den Standort bestimmt; Standort und Gebäude werden nicht redundant in der Werkstatt gespeichert. Raumkapazität und maximale Besucherzahl einer Werkstatt sind unterschiedliche Begrenzungen.

## 4. Datenmodellentscheidungen

- UUIDs als technische Schlüssel; administrierbare Kataloge besitzen stabile eindeutige Codes, Namen und Aktivflag. Deaktivierung verhindert neue Nutzung, erhält historische Referenzen.
- Event benötigt einen aktiven Employee als Owner; weitere Beteiligung entsteht aus Verantwortung, Aufgabe, Ablauf und expliziter Beteiligung. Eine Owner-Änderung ist eine auditierte Transaktion.
- Zeitpunkte als `timestamptz`, Anzeige anhand Event-Zeitzone (Vorgabe `Europe/Berlin`); ganztägige und mehrtägige Ereignisse bleiben echte Intervalle. Beträge ausschließlich Decimal und Währung, nur historische Ist-Kosten.
- Status, Typen, Gewerke, Raumtypen, Teilnehmer- und Auswirkungskategorien sind Daten. Statusübergänge und benötigte Rechte werden separat konfiguriert; „konfigurierbar“ bedeutet keine beliebige Umgehung von Invarianten.
- Sichtbarkeit ist ein Modus plus separate Standort-, Organisationseinheits- oder Gruppenzuordnungen. Mehrere Zielgruppen innerhalb eines Modus werden vereinigt; explizite Beteiligte haben zusätzlich Zugriff. Keine pauschale Rechteerweiterung durch bloße Event-Teilnahme.
- Aufbewahrung trennt Veranstaltungsmetadaten von personenbezogenen Teilnehmerdaten. Löschen/Pseudonymisieren erfolgt kontrolliert; Audit enthält Feldnamen und minimierte Änderungen statt unbeschränkter Personen-Snapshots.
- Einladungsstatus wird im Invitation-Datensatz geführt; Check-in ist unabhängig von einer Zusage. Gruppenstatistiken und Einzelteilnehmerzahl werden getrennt ausgewiesen, um Doppelzählung zu vermeiden.
- Templates speichern versionierte strukturierte Blaupausen als JSON, keine reservierenden Kopien. JSON ist hier ein Snapshot und enthält keine Teilnehmerdaten oder produktiven Dokumentdateien. Normale Fachdaten bleiben relational.

## 5. Datenbankregeln außerhalb des Prisma-Schemas

Der Schemaentwurf bildet noch keine SQL-Migrationen ab. Phase 2 ergänzt CHECK-Constraints für positive Kapazitäten, gültige Intervalle, Puffer ≥ 0, Gruppengröße ≥ 0, Kopier- und Sichtbarkeitsinvarianten sowie Fremdschlüssel-Konsistenz: Teilnehmergruppe, Schedule und Reservation müssen zum selben Event gehören. Eine Workshop-Zuordnung muss zum reservierten Raum gehören.

Für globale UserRole-Zuweisungen muss ein zusätzlicher partieller Unique-Index `(userId, roleId) WHERE locationId IS NULL` angelegt werden: PostgreSQL behandelt NULL im normalen Composite-Unique nicht als gleichen Wert. ALL/OWN/ASSIGNED gelten ohne Standortbindung, LOCATION benötigt sie. Hauptsprache pro Event erhält ebenfalls einen partiellen Unique-Index. Workshop- und EventLanguage-Einträge beschreiben angebotene beziehungsweise angefragte Sprachen, nicht automatisch Ausbilderqualifikationen.

Buchungen werden unter Ressourcen-Locks geprüft und gespeichert; alle Schreibwege einschließlich Imports verwenden denselben Dienst. Nicht übersteuerbare Zeit- und Referenzfehler werden nie durch Adminrechte aufgehoben. Falls Ausschlussconstraints eingesetzt werden, müssen erlaubte Übersteuerungen in einem expliziten Konfliktfreigabemodell berücksichtigt werden, nicht durch Entfernen des Constraints. Weitere Einzelheiten stehen in [regeln.md](regeln.md).
