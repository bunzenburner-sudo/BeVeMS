# Navigation, User Flows und Umsetzung

> Historischer Entwurfs-/Phasennachweis. Aktueller Implementierungsstand: [Phasen 3–6](phasen3-6.md).

Fachliche Roadmap aus Phase 1. Phase 2 ist inzwischen implementiert; der aktuelle Umfang und die noch ausstehenden Oberflächen stehen in [Phase 2](phase2.md) und der [README](../README.md).

## Seitenstruktur

| Bereich / Route | Inhalt | Nutzungsebene |
|---|---|---|
| `/` | Heute, diese Woche, prominente betriebliche Hinweise, für mich relevant | Informieren |
| `/me/tasks` | eigene Aufgaben und Verantwortungen | Mitarbeiten |
| `/dashboard` | kommende Events, Fortschritt, überfällige/kritische Aufgaben, Konflikte, unbestätigte Reservierungen | Organisieren |
| `/events`, `/calendar` | Events; Tag/Woche/Monat/Liste; Filter Standort, Gebäude, Typ, Struktur, Owner, Status | nach Recht |
| `/events/new` | Wizard | Organisieren |
| `/events/[id]` | Übersicht, Organisation, Aufgaben, Ablauf, Ressourcen, Gäste, Hinweise, Kommunikation, Dokumente, Nachbereitung, Audit | Tabs und Felder nach Recht |
| `/templates`, `/series` | Vorlagen und Serien | Organisieren |
| `/guests/organisations`, `/guests/contacts`, `/guests/participants` | Besucherorganisationen, frühere Besuche, Kontakte, Teilnehmer | gesonderte Rechte |
| `/locations`, `/buildings`, `/rooms`, `/workshops`, `/reservations` | Ressourcenhierarchie und Belegung | nach Recht |
| `/employees`, `/instructors` | Mitarbeiter, Ausbilder und geschützte Sprachprofile | nach Recht |
| `/history` | abgeschlossene Events, Lessons Learned, Jahreskopie | nach Sichtbarkeit |
| `/admin` | Typen, Statusübergänge, Gewerke, Sprachen, Kategorien, Bereiche, Rollen, Rechte, Gruppen, Integrationsstatus | Administration |

Normale Mitarbeiter sehen zuerst betriebliche Hinweise, keine Planungswerkzeuge. „Für mich relevant“ prüft sämtliche Beteiligungsarten. Aufgabenrecht erweitert nur die eigene Aufgabe. Impact-Zeitraum kann sich vom Event-Zeitraum unterscheiden (etwa Parkplatzsperrung vor Beginn); Standort-/Gruppenfilter berücksichtigen dies. Ein öffentlich sichtbarer Hinweis eines sensiblen Events wird nur über eine ausdrücklich freigegebene, anonymisierte Hinweiskopie veröffentlicht.

## Wichtige User Flows

### Mitarbeiter informiert sich

SSO → reduzierte Startseite → Standortfilter → heutige/kommende sichtbare Events und aktuelle Einschränkungen → Detailansicht ohne Teilnehmer-/Sprachdaten. Eigene Aufgaben sind direkt erreichbar; erledigte Aufgaben aktualisieren den serverseitig berechneten Fortschritt.

### Organisator erstellt eine Veranstaltung

1. Was: Titel, konfigurierter Typ, intern/extern/gemischt, Beschreibung, optionale Vorlage.
2. Wann: Beginn/Ende, Zeitzone, Mehrtägigkeit; Serie optional, konkrete Instanzen prüfen.
3. Wo: Standort → Gebäude → Räume/Werkstätten; Puffer und vorläufige Konfliktprüfung.
4. Wer kommt: Gruppen/Einzelzahl, Organisation und Wiederholungsbesuche, Kontakt, Land und Sprachen. Delegationen erhalten regelbasierte Vorschläge; geänderte Gruppengröße löst Ressourcenprüfung erneut aus.
5. Wer organisiert: Owner erforderlich, Bereiche und Teilverantwortung, Ausbilder und weitere Beteiligte.
6. Vorbereitung: Aufgaben manuell oder aus Vorlage, Frist, Person, kritische Priorität.
7. Auswirkungen: Kategorie/Freitext, Zeitraum, Standort und betroffene Gruppen.
8. Kommunikation: Sichtbarkeit, zulässige Zielgruppen, zusätzliche Empfänger und Outlook-Optionen.
9. Zusammenfassung: sämtliche Angaben, Konflikte, Auswirkungen und konkrete Kommunikationsmaßnahmen. Bestätigen validiert und autorisiert nochmals; Reservierung, Audit und Outbox entstehen atomar. Bei Konflikt bleibt der Entwurf erhalten; kein stiller Versand.

Entwurfszwischenspeicherung ab gültigem Owner und Grunddaten; fehlende Pflichtangaben sind zur Bestätigung sichtbar. Navigation und Fehlermeldungen sind tastaturbedienbar. Keine E-Mails allein durch unfertige Wizard-Zwischenschritte.

### Veranstaltung organisieren

Event öffnen → Verantwortungen/Aufgaben zuweisen → Aufgabe bearbeiten → Fortschritt und kritische Punkte sehen → Ablaufpunkte per Drag-and-drop oder zugänglichen Auf-/Ab-Schaltflächen sortieren → Ressourcen erneut prüfen → Statusübergang. Änderungen an Zeit/Ort machen Kommunikations- und Buchungsfolgen vor Bestätigung sichtbar.

### Teilnehmer und Check-in

Berechtigter Organisator erfasst Gruppe oder Einzelperson → Einladung → Zusage/Absage separat → bestätigte Einzelperson erhält optional QR-Token → autorisierter Scan oder manueller Check-in → Anwesenheit nachvollziehbar speichern. Export braucht eigenes Recht und wird auditiert. Online-Anmeldung, Warteliste und Einwilligungsformular folgen später.

### Historie und Wiederholung

Event abschließen → tatsächliche Teilnehmerzahl, Lessons Learned, Dienstleisterbewertung und optional Ist-Kosten erfassen → Historie bleibt nach Sichtbarkeit recherchierbar → Jahreskopie/Vorlage → neuer DRAFT ohne Zusagen oder Buchungen → vergangene Erkenntnisse anzeigen → Termine und Verantwortliche ausdrücklich prüfen.

### Administrator verwaltet Stammdaten

Stammdatum hinzufügen/bearbeiten/deaktivieren → neue Vorgänge verwenden nur aktive Werte → historische Referenzen bleiben lesbar. Rechteänderungen invalidieren betroffene Sessions beziehungsweise deren Permission-Cache. Änderung von Sicherheitsregeln oder Rollen wird auditiert; kein Selbstentzug des letzten Administrators.

## MVP-Abgrenzung und Phasen

Jetzt wird ausschließlich Phase 1 geliefert: Dokumentation und Schemaentwurf. Phase 2 implementiert Repository-/Toolstruktur, PostgreSQL-Migrationen inklusive Constraints, Identity/Policies, Seed-Daten und Navigation. Erst dann existiert ein ausführbares Grundgerüst.

Phase 3 als Kern-MVP: Mitarbeiterstartseite, Organisatordashboard, Kalender, Event-CRUD und Wizard, Stammdatenhierarchie, Werkstätten, Mitarbeiter/Sprachen, Verantwortungen, Aufgaben/Fortschritt, Ablauf, Auswirkungen, lokale Reservierungen und Konflikte, Delegationsmatching. Konfigurierbare Kataloge und Rechte sowie Audit sind Pflicht, keine spätere Ergänzung. Live-FM-Verfügbarkeit wird nur mit geklärtem Adapter angeboten; andernfalls deutliche lokale Verfügbarkeitsgrenze.

Phase 4: In-App-Notifications, transaktionale E-Mail-/Kalenderlogik und Graph-Anbindung nach Tenant-Freigabe. Phase 5: Einzel-/Gruppenteilnehmer, Organisationen/Kontakte, Einladungen, Exporte und QR-/manueller Check-in. Phase 6: Historie, Vorlagen, Serien, Jahreskopie, Lessons Learned, Dienstleister und Dokumente. Das Schema bereitet alle Phasen vor; Tabellenexistenz ist keine fertige Funktion.

Explizit später: Online-Anmeldung (dynamische Formulare, Datenschutz, Einwilligung, Limit, Warteliste und Bestätigung), Teams, vollständiges SharePoint, Displays, Türschilder, mehrsprachige UI, Mitarbeiter-App, KI-Ablaufplanung, automatische Routen, Sprachanalyse und Lessons-Learned-Analyse. Kostenplanung/Budgetsteuerung bleibt ausgeschlossen.

### Abnahmekriterien für das Kern-MVP

Mitarbeiter findet Tages-/Wochenereignisse und Einschränkungen unmittelbar; Organisator kann einen Event einschließlich Owner, Aufgaben, Ablauf und konfliktfreier Buchung dauerhaft speichern; zeitgleiche Buchungsversuche werden korrekt serialisiert; Rollen/Sichtbarkeit gelten für sämtliche API-Zugriffe; Sprachranking ist erklärbar und personenbezogene Daten sind geschützt; kritische Aufgaben verhindern unzulässigen READY-Übergang; wesentliche Änderungen sind auditiert. UI-Smoke-Tests, Policytests und PostgreSQL-Integrationstests sind Voraussetzung der MVP-Abnahme.

## Annahmen und offene Entscheidungen

| Thema | Festgelegte Annahme / Klärungsbedarf |
|---|---|
| Organisation | Zunächst ein HWK-Tenant, mehrere konfigurierbare Standorte; keine SaaS-Mandantenverwaltung |
| Zeit | Europe/Berlin als Default, Speicherung UTC; internationale Events können eigene IANA-Zeitzone erhalten |
| Owner | Mindestens ein Hauptverantwortlicher, zunächst genau einer; Vertretung über Responsibility |
| Sprache | B2 Mindestniveau für reguläre Führung, C1+ sehr gut; Sicherheitsunterweisung separat freigeben |
| Umfang | **OFFENE ENTSCHEIDUNG:** Nutzerzahl, Parallelität, Datenvolumen und Performance-SLO; zunächst paginierte Abfragen und normalisierte PostgreSQL-Daten |
| Infrastruktur | **OFFENE ENTSCHEIDUNG:** Hosting, Netzwerk, Domains, TLS, Betriebsverantwortung und Containerplattform |
| Auth | **OFFENE ENTSCHEIDUNG:** Entra-Tenant/App, Provisioning, Gastkonten, MFA/Conditional Access und Rollenzuweisungsprozess |
| Rollen | **OFFENE ENTSCHEIDUNG:** genaue Standort-/Bereichsscope-Regeln, sensible Administratorzugriffe und Exportberechtigungen |
| FM / ODAV | **OFFENE ENTSCHEIDUNG:** FM-Produkt und ODAV-Belegungszugriff; kein Ersatz des ODAV-Tagesgeschäfts |
| Reservierungen | **OFFENE ENTSCHEIDUNG:** Vormerkungsdauer, externe Bestätigung, zulässige Übersteuerungen und Freigabeprozess |
| Ausbilder | **OFFENE ENTSCHEIDUNG:** Verfügbarkeitsquelle, Pflegerechte, Sprachniveauvalidierung und Dolmetschoptionen |
| Datenschutz | **OFFENE ENTSCHEIDUNG:** Rechtsgrundlagen, Lösch-/Aufbewahrungsfristen je Datentyp, Betroffenenprozesse, DSFA-Bedarf und Betriebsrat |
| Kommunikation | **OFFENE ENTSCHEIDUNG:** Versandfreigabe, Kalenderorganisator, Graph-Rechtemodell und zulässige externe Empfänger |
| Dokumente | **OFFENE ENTSCHEIDUNG:** initialer Storage, Scan-Service, Größenlimits und SharePoint-Ziel |
| Historie | **OFFENE ENTSCHEIDUNG:** Archivdauer, Pseudonymisierung und Sichtbarkeit abgeschlossener Veranstaltungen |
| Betrieb | **OFFENE ENTSCHEIDUNG:** Backup-RPO/RTO, Monitoring, Alarmierung, Wiederherstellungs- und Incidentprozesse |
| Fachliche Daten | Demo-Standorte und Personen sind fiktiv; reale Stammdaten und Verantwortungsbereiche werden vor Produktivbetrieb importiert/freigegeben |

Keine offene Entscheidung blockiert das Architekturpaket; sie kann die jeweilige spätere produktive Integration oder Abnahme blockieren. Der Entwurf beansprucht keine Datenschutzfreigabe oder Produktionsreife.
