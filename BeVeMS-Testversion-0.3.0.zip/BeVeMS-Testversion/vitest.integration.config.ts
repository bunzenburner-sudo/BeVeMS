import { defineConfig, mergeConfig } from "vitest/config";
import base from "./vitest.config.ts";
if (!process.env.TEST_DATABASE_URL || new URL(process.env.TEST_DATABASE_URL).pathname !== "/bevems_phase2_test") throw new Error("Integration tests require a dedicated bevems_phase2_test database via TEST_DATABASE_URL.");
process.env.DATABASE_URL = process.env.TEST_DATABASE_URL;
const config = mergeConfig(base, defineConfig({ test: { testTimeout: 30_000, hookTimeout: 90_000, fileParallelism: false } }));
config.test!.include = ["tests/integration/**/*.test.ts"];
export default config;
