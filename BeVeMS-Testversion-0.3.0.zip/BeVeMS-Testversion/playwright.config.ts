import { defineConfig } from "@playwright/test";
import { existsSync } from "node:fs";
export default defineConfig({
  testDir: "tests/e2e", fullyParallel: false, workers: 1,
  use: { baseURL: "http://127.0.0.1:3000", browserName: "chromium", viewport: { width: 1365, height: 900 },
    launchOptions: { executablePath: process.env.CHROMIUM_EXECUTABLE_PATH ?? (existsSync("/usr/bin/chromium") ? "/usr/bin/chromium" : undefined) },
  },
  webServer: { command: "npm run dev", url: "http://127.0.0.1:3000/login", reuseExistingServer: true, timeout: 120_000 },
});
