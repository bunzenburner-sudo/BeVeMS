import { expect, test, type Page } from "@playwright/test";
import { mkdir } from "node:fs/promises";

test.beforeAll(async ({ request }) => {
  const response = await request.get("/api/auth/providers");
  const providers = await response.json();
  expect(providers.credentials, "Browser tests require the local development demo; stop any production server on port 3000.").toBeDefined();
});

async function login(page: Page, profile: string) {
  if (!process.env.DEMO_AUTH_PASSWORD) throw new Error("E2E tests require a local DEMO_AUTH_PASSWORD and seeded database.");
  await page.goto("/login");
  await page.getByLabel("Demo-Profil").selectOption(profile);
  await page.getByLabel("Lokales Demo-Passwort").fill(process.env.DEMO_AUTH_PASSWORD);
  await page.getByRole("button", { name: "Demo öffnen" }).click();
  await expect(page.getByRole("heading", { name: /Willkommen,/ })).toBeVisible();
}
test("anonymous users cannot read protected APIs or pages", async ({ page, request }) => {
  expect((await request.get("/api/health")).status()).toBe(200);
  expect((await request.get("/api/events")).status()).toBe(401);
  expect((await request.get("/api/employees")).status()).toBe(401);
  await page.goto("/administration"); await expect(page).toHaveURL(/\/login$/);
});
test("bad demo credentials fail without creating a session", async ({ page }) => {
  await page.goto("/login"); await page.getByLabel("Lokales Demo-Passwort").fill("invalid-password");
  await page.getByRole("button", { name: "Demo öffnen" }).click();
  await expect(page.getByRole("alert").filter({ hasText: "Anmeldung fehlgeschlagen" })).toContainText("Anmeldung fehlgeschlagen");
  expect((await page.request.get("/api/events")).status()).toBe(401);
});
test("credentials POST without CSRF token cannot create a session", async ({ request }) => {
  await request.post("/api/auth/callback/credentials", { form: { profile: "admin", password: process.env.DEMO_AUTH_PASSWORD!, callbackUrl: "/", json: "true" }, maxRedirects: 0 });
  expect((await request.get("/api/events")).status()).toBe(401);
});
test("employee sees seven events and cannot open administration or employee directory", async ({ page }) => {
  await login(page, "employee");
  const response = await page.request.get("/api/events"); const events = await response.json();
  expect(events).toHaveLength(7); expect(events.some((event: { title: string }) => event.title.includes("vertraulich"))).toBe(false);
  expect((await page.request.get("/api/employees")).status()).toBe(403);
  await page.goto("/events"); await expect(page.getByRole("heading", { name: "Veranstaltungen", exact: true })).toBeVisible();
  await page.goto("/administration"); await expect(page.getByRole("heading", { name: "Seite nicht verfügbar" })).toBeVisible();
});
test("administrator can navigate seeded events, locations and roles", async ({ page }) => {
  await login(page, "admin");
  await mkdir(".local/screenshots", { recursive: true });
  await page.screenshot({ path: ".local/screenshots/phase2-dashboard.png", fullPage: true });
  await page.getByRole("link", { name: "Orte & Ressourcen", exact: true }).click();
  await expect(page.getByRole("heading", { name: "Demo-Campus Rhein" })).toBeVisible();
  await expect(page.getByRole("heading", { name: "Elektrowerkstatt" })).toBeVisible();
  await page.getByRole("link", { name: "Administration", exact: true }).click();
  await expect(page.getByRole("heading", { name: "Rollen & Rechte" })).toBeVisible();
  await page.getByRole("link", { name: "Veranstaltungen", exact: true }).click();
  await expect(page.getByText("Politischer Austausch · vertraulich", { exact: true })).toBeVisible();
});
test("instructor only receives their own protected language profile", async ({ page }) => {
  await login(page, "instructor");
  const employees = await (await page.request.get("/api/employees")).json();
  expect(employees).toHaveLength(1); expect(employees[0].firstName).toBe("Lena");
  await page.getByRole("link", { name: "Mitarbeiter", exact: true }).click();
  await expect(page.getByText("Englisch · C1")).toBeVisible();
});
test("mobile navigation keeps content usable and sign-out available", async ({ page }) => {
  await page.setViewportSize({ width: 390, height: 844 }); await login(page, "employee");
  await expect(page.getByRole("button", { name: "Abmelden" }).last()).toBeVisible();
  expect(await page.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth)).toBe(true);
  await page.getByRole("button", { name: "Abmelden" }).last().click();
  await expect(page).toHaveURL(/\/login$/);
  expect((await page.request.get("/api/events")).status()).toBe(401);
});
