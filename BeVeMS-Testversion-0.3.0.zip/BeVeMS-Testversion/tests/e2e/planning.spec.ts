import { test, expect, type Page } from "@playwright/test";
async function login(page: Page, profile = "admin") {
  await page.goto("/login"); await page.getByLabel("Demo-Profil").selectOption(profile); await page.getByLabel("Lokales Demo-Passwort").fill(process.env.DEMO_AUTH_PASSWORD!); await page.getByRole("button", { name: "Demo öffnen" }).click(); await expect(page.getByRole("heading", { name: /Willkommen/ })).toBeVisible();
}
test("organizer creates an event through the wizard and updates a task", async ({ page }) => {
  await login(page, "organizer"); await page.goto("/events/new");
  await page.getByLabel("Titel", { exact: true }).fill(`Browser Planung ${Date.now()}`);
  await page.getByRole("button", { name: "Weiter", exact: true }).click();
  await page.getByLabel(/Beginn/).filter({ visible: true }).fill("2028-06-10T10:00"); await page.getByLabel(/Ende/).filter({ visible: true }).fill("2028-06-10T13:00");
  await page.getByRole("button", { name: "Weiter", exact: true }).click();
  await page.getByRole("button", { name: "Weiter", exact: true }).click();
  await page.getByLabel("Erwartete Teilnehmerzahl").fill("10"); await page.getByRole("button", { name: "Weiter", exact: true }).click();
  await page.getByRole("button", { name: "Weiter", exact: true }).click();
  await page.getByLabel("Erste Aufgabe (optional)").fill("Browser Technik vorbereiten"); await page.getByRole("button", { name: "Weiter", exact: true }).click();
  await page.getByLabel("Erster betrieblicher Hinweis (optional)").fill("Foyer für Gäste freihalten"); await page.getByRole("button", { name: "Weiter", exact: true }).click();
  await page.getByRole("button", { name: "Weiter", exact: true }).click();
  await expect(page.getByText("Browser Technik vorbereiten", { exact: true })).toBeVisible();
  await expect(page).toHaveURL(/\/events\/new$/);
  await expect(page.locator('fieldset[data-step="8"]')).toBeVisible();
  await page.getByRole("button", { name: "Entwurf anlegen", exact: true }).click();
  await expect(page).toHaveURL(/\/events\/[a-f0-9-]+$/);
  await expect(page.getByText("Foyer für Gäste freihalten", { exact: true })).toBeVisible();
  await page.getByRole("link", { name: "Planung & Ressourcen" }).click();
  await expect(page.getByRole("heading", { name: "Browser Technik vorbereiten" })).toBeVisible();
  const task = page.locator("article").filter({ has: page.getByRole("heading", { name: "Browser Technik vorbereiten" }) });
  await task.getByRole("combobox", { name: "Status", exact: true }).selectOption("DONE"); await task.getByRole("button", { name: "Aufgabe aktualisieren" }).click();
  await expect(page.getByText("100 % erledigt", { exact: true })).toBeVisible();
  await page.getByRole("link", { name: "Teilnehmer", exact: true }).click();
  const add = page.locator("section").filter({ has: page.getByRole("heading", { name: "Teilnehmer hinzufügen", exact: true }) });
  await add.getByLabel("Vorname", { exact: true }).fill("Browser"); await add.getByLabel("Nachname", { exact: true }).fill("Testgast");
  await add.getByRole("button", { name: "Speichern", exact: true }).click();
  const person = page.locator("article").filter({ has: page.getByRole("heading", { name: "Browser Testgast", exact: true }) });
  await expect(person).toBeVisible(); await person.getByRole("combobox", { name: "Einladungstatus", exact: true }).selectOption("ACCEPTED");
  await person.getByRole("button", { name: "Einladungstatus speichern" }).click();
  await person.getByRole("button", { name: "QR-Code neu ausgeben" }).click();
  await expect(person.getByAltText("QR-Code für den Check-in")).toBeVisible();
  expect(await person.getByAltText("QR-Code für den Check-in").getAttribute("src")).toMatch(/^blob:/);
  await page.getByRole("link", { name: "Dokumente", exact: true }).click();
  await page.getByLabel(/Dokument \(PDF/).setInputFiles({ name: "testablauf.txt", mimeType: "text/plain", buffer: Buffer.from("Fiktiver Testablauf") });
  await page.getByRole("button", { name: "Dokument hochladen", exact: true }).click();
  await expect(page.getByText("testablauf.txt · Sicherheitsprüfung ausstehend", { exact: true })).toBeVisible();
});
test("calendar renders day week month and list without revealing sensitive events", async ({ page }) => {
  await login(page, "employee");
  for (const view of ["day", "week", "month", "list"]) {
    await page.goto(`/calendar?date=2026-10-12&view=${view}`);
    await expect(page.getByRole("heading", { name: "Veranstaltungskalender" })).toBeVisible();
    await expect(page.getByText("Politischer Austausch · vertraulich", { exact: true })).toHaveCount(0);
  }
  await page.goto("/events/new"); await expect(page.getByRole("heading", { name: "Seite nicht verfügbar" })).toBeVisible();
});
test("new planning pages fit mobile screens", async ({ page }) => {
  await page.setViewportSize({ width: 390, height: 844 }); await login(page);
  for (const route of ["/events/new", "/tasks", "/notifications", "/organisations", "/workshops", "/administration"]) {
    await page.goto(route); await expect(page.locator("h1")).toBeVisible();
    expect(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth)).toBe(true);
  }
});
