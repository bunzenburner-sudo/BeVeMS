import { resetIntegrationData } from "./reset";
import { beforeAll, afterAll, describe, expect, it } from "vitest";
import { execFileSync } from "node:child_process";
import { db } from "../../src/lib/db";
import { demoId, seedDemo } from "../../prisma/seed";
import { loadActor } from "../../src/domains/identity/actor";
import { createEvent, updateEvent, changeStatus, planningDetail } from "../../src/domains/planning/events";
import { addTask, setTaskStatus, addImpact, addSchedule, reorderSchedule } from "../../src/domains/planning/work";
import { reserveRoom, cancelReservation } from "../../src/domains/reservations/service";
import { suggestWorkshops } from "../../src/domains/reservations/matching";
import { addParticipant, setInvitation, issueCheckInToken, checkIn, exportParticipants } from "../../src/domains/participants/service";
import { copyEvent, saveTemplate, instantiateTemplate, createSeries } from "../../src/domains/history/service";
import { manageRole } from "../../src/domains/administration/manage";
import type { Actor } from "../../src/domains/identity/policy";
let admin: Actor, employee: Actor, organizer: Actor;
const created: string[] = [];
const base = () => ({ title: "Integration – Planung", description: "", structure: "EXTERNAL", start: "2028-02-01T09:00:00Z", end: "2028-02-01T16:00:00Z", typeId: demoId("type-0"), ownerId: demoId("employee-organizer"), locationId: demoId("location-0"), participantCount: 10 });
async function make(overrides = {}) { const id = await createEvent(admin, { ...base(), ...overrides }); created.push(id); return id; }
beforeAll(async () => {
  execFileSync(process.execPath, ["tools/prisma-wasm.cjs", "deploy"], { env: { ...process.env, DATABASE_URL: process.env.TEST_DATABASE_URL, MIGRATION_DATABASE_URL: process.env.TEST_DATABASE_URL }, stdio: "pipe" });
  await resetIntegrationData();
  process.env.ALLOW_DEMO_SEED = "true"; process.env.DEMO_DATABASE_NAME = "bevems_phase2_test";
  await seedDemo(process.env.TEST_DATABASE_URL);
  admin = (await loadActor(demoId("user-admin")))!; organizer = (await loadActor(demoId("user-organizer")))!; employee = (await loadActor(demoId("user-employee")))!;
});
afterAll(async () => {
  await resetIntegrationData();
  await db.$disconnect();
});
describe("event planning mutations", () => {
  it("rejects creation without rights and invalid time ranges", async () => {
    await expect(createEvent(employee, base())).rejects.toMatchObject({ status: 403 });
    await expect(make({ end: "2028-02-01T08:00:00Z" })).rejects.toThrow("Zeitraum");
  });
  it("creates private drafts, initial planning, audit and outbox atomically", async () => {
    const id = await make({ initialTask: "Empfang planen", initialImpact: "Foyer eingeschränkt", initialRecipients: "planung@example.invalid" });
    const e = await db.event.findUniqueOrThrow({ where: { id }, include: { status: true } });
    expect(e.visibility).toBe("INVOLVED"); expect(e.status.code).toBe("DRAFT");
    expect(await db.eventTask.count({ where: { eventId: id } })).toBe(1);
    expect(await db.auditLog.count({ where: { eventId: id } })).toBe(1);
    expect(await db.outboxMessage.count({ where: { eventId: id } })).toBeGreaterThan(0);
    await expect(planningDetail(employee, id)).rejects.toMatchObject({ status: 404 });
  });
  it("rejects stale versions, invalid transitions and re-timing booked schedules", async () => {
    const id = await make();
    await expect(updateEvent(admin, id, base(), 1)).rejects.toThrow("inzwischen");
    await expect(changeStatus(admin, id, demoId("status-READY"))).rejects.toThrow("Statusübergang");
    await addSchedule(admin, id, { title: "Empfang", description: "", internalNotes: "", start: base().start, end: base().end, roomId: "", responsibleId: "" });
    const e = await db.event.findUniqueOrThrow({ where: { id } });
    await expect(updateEvent(admin, id, { ...base(), end: "2028-02-01T17:00:00Z" }, e.version)).rejects.toThrow("Ablaufpunkte");
    await expect(reorderSchedule(admin, id, [])).rejects.toThrow("inzwischen");
  });
  it("limits task contributors to their own tasks and computes progress", async () => {
    const id = await make({ visibility: "ALL_EMPLOYEES" });
    await addTask(admin, id, { title: "Meine Aufgabe", assigneeId: employee.employeeId, critical: true });
    await addTask(admin, id, { title: "Fremde Aufgabe", assigneeId: organizer.employeeId });
    const tasks = await db.eventTask.findMany({ where: { eventId: id } });
    const own = tasks.find((t) => t.assigneeId === employee.employeeId)!, other = tasks.find((t) => t.assigneeId !== employee.employeeId)!;
    await expect(setTaskStatus(employee, id, other.id, "DONE")).rejects.toMatchObject({ status: 403 });
    await setTaskStatus(employee, id, own.id, "DONE");
    expect((await planningDetail(admin, id)).progress).toBe(50);
    expect((await planningDetail(employee, id)).tasks).toHaveLength(1);
  });
  it("does not expose impact internal notes to ordinary staff", async () => {
    const id = await make({ visibility: "ALL_EMPLOYEES" });
    await addImpact(admin, id, { description: "Private security details", publicSummary: "Parkplatz gesperrt", categoryId: "", start: base().start, end: base().end });
    const result = await planningDetail(employee, id);
    expect(result.impacts[0].publicSummary).toBe("Parkplatz gesperrt"); expect(result.impacts[0]).not.toHaveProperty("description");
  });
});
describe("concurrent room and workshop reservations", () => {
  const booking = (roomId: string, overrides = {}) => ({ roomId, start: "2028-02-01T10:00:00Z", end: "2028-02-01T11:00:00Z", visitors: 5, setupMinutes: 15, teardownMinutes: 15, status: "TENTATIVE", ...overrides });
  it("allows exactly one of two simultaneous reservations and hides competitor details", async () => {
    const room = await db.room.findFirstOrThrow({ where: { workshop_room: null, building: { locationId: demoId("location-0") } } });
    const a = await make(), b = await make();
    const results = await Promise.allSettled([reserveRoom(admin, a, booking(room.id)), reserveRoom(admin, b, booking(room.id))]);
    expect(results.filter((r) => r.status === "fulfilled")).toHaveLength(1);
    const error = results.find((r) => r.status === "rejected") as PromiseRejectedResult; expect(error.reason.conflicts[0].code).toBe("ROOM_BUSY");
    expect(error.reason.message).not.toContain(a); expect(error.reason.message).not.toContain("Integration");
    for (const eventId of [a, b]) for (const r of await db.reservation.findMany({ where: { eventId } })) await cancelReservation(admin, eventId, r.id);
  });
  it("enforces capacity, hard blocks and explicit local-only confirmation", async () => {
    const room = await db.room.findFirstOrThrow({ where: { building: { locationId: demoId("location-0") }, workshop_room: null } }), id = await make();
    await expect(reserveRoom(admin, id, booking(room.id, { visitors: room.capacity + 1 }))).rejects.toThrow("Kapazität");
    await expect(reserveRoom(admin, id, booking(room.id, { status: "CONFIRMED" }))).rejects.toThrow("FM");
    const block = await db.roomBlock.create({ data: { roomId: room.id, start: new Date(base().start), end: new Date(base().end), reason: "Test", hard: true } });
    try { await expect(reserveRoom(admin, id, booking(room.id, { overrideReason: "Auch Admin darf keine Sicherheit umgehen" }))).rejects.toThrow("gesperrt"); }
    finally { await db.roomBlock.delete({ where: { id: block.id } }); }
  });
  it("requires workshop instructors and enforces instructor unavailability", async () => {
    const w = await db.workshop.findFirstOrThrow({ where: { room: { building: { locationId: demoId("location-0") } } }, include: { workshopEmployee_workshop: true } }), id = await make();
    await expect(reserveRoom(admin, id, booking(w.roomId))).rejects.toThrow("Ausbilder erforderlich");
    const employeeId = w.workshopEmployee_workshop[0].employeeId;
    const unavailable = await db.employeeUnavailability.create({ data: { employeeId, start: new Date(base().start), end: new Date(base().end), reasonCode: "TEST" } });
    try { await expect(reserveRoom(admin, id, booking(w.roomId, { instructorIds: [employeeId] }))).rejects.toThrow("nicht verfügbar"); }
    finally { await db.employeeUnavailability.delete({ where: { id: unavailable.id } }); }
  });
  it("requires explicit override rights and audits every soft conflict", async () => {
    const room = await db.room.findFirstOrThrow({ where: { workshop_room: null, building: { locationId: demoId("location-0") } } });
    const a = await make(), b = await make();
    const first = await reserveRoom(admin, a, booking(room.id));
    try {
      await expect(reserveRoom(organizer, b, booking(room.id, { overrideReason: "Genehmigte gemeinsam genutzte Veranstaltung" }))).rejects.toThrow();
      const second = await reserveRoom(admin, b, booking(room.id, { overrideReason: "Genehmigte gemeinsam genutzte Veranstaltung" }));
      expect(await db.reservationOverride.count({ where: { reservationId: second } })).toBe(1); await cancelReservation(admin, b, second);
    } finally { await cancelReservation(admin, a, first); }
  });
});
describe("participants, check-in and history", () => {
  it("guards exports, invalidates QR tokens and handles check-in idempotently", async () => {
    const now = new Date(), id = await make({ start: new Date(+now - 3600000).toISOString(), end: new Date(+now + 3600000).toISOString(), visibility: "ALL_EMPLOYEES" });
    await addParticipant(admin, id, { firstName: "=FORMEL", lastName: "Testperson", email: "test@example.invalid", function: "", categoryId: demoId("category-0"), organisationId: "" });
    const person = await db.eventParticipant.findFirstOrThrow({ where: { eventId: id } });
    await expect(issueCheckInToken(admin, id, person.id)).rejects.toThrow("bestätigte");
    await setInvitation(admin, id, person.id, "ACCEPTED");
    const token = await issueCheckInToken(admin, id, person.id);
    expect((await db.eventParticipant.findUniqueOrThrow({ where: { id: person.id } })).qrTokenHash).not.toBe(token);
    await changeStatus(admin, id, demoId("status-PLANNING"));
    const one = await checkIn(admin, id, { token }), two = await checkIn(admin, id, { token }); expect(one.id).toBe(two.id);
    await expect(exportParticipants(employee, id)).rejects.toMatchObject({ status: 403 });
    expect(await exportParticipants(admin, id)).toContain("'=FORMEL");
    await setInvitation(admin, id, person.id, "DECLINED"); await expect(checkIn(admin, id, { token })).rejects.toThrow("gültiger");
  });
  it("copies planning into private drafts without booking, people or tokens", async () => {
    const id = await make({ initialTask: "Copy task" });
    const copy = await copyEvent(admin, id, { title: "Jahreskopie", start: "2029-02-01T09:00:00Z" }); created.push(copy);
    const event = await db.event.findUniqueOrThrow({ where: { id: copy }, include: { status: true, eventTask_event: true, reservation_event: true, eventParticipant_event: true } });
    expect(event.status.code).toBe("DRAFT"); expect(event.reviewRequired).toBe(true); expect(event.visibility).toBe("INVOLVED"); expect(event.eventTask_event).toHaveLength(1); expect(event.reservation_event).toHaveLength(0); expect(event.eventParticipant_event).toHaveLength(0);
    const template = await saveTemplate(admin, id, "Testvorlage");
    const from = await instantiateTemplate(admin, template, "2030-02-01T09:00:00Z"); created.push(from); expect((await db.event.findUniqueOrThrow({ where: { id: from } })).templateId).toBe(template);
    await db.eventTemplate.update({ where: { id: template }, data: { active: false } });
  });
  it("builds series with stable Berlin wall time across DST", async () => {
    const id = await make({ start: "2028-03-20T09:00:00Z", end: "2028-03-20T10:00:00Z" });
    const first = await createSeries(admin, id, { title: "DST-Test", count: 3, frequency: "WEEKLY" });
    const event = await db.event.findUniqueOrThrow({ where: { id: first } });
    const rows = await db.event.findMany({ where: { seriesId: event.seriesId }, orderBy: { start: "asc" } }); created.push(...rows.map((r) => r.id));
    expect(rows).toHaveLength(3); expect(rows.map((e) => new Intl.DateTimeFormat("de-DE", { timeZone: "Europe/Berlin", hour: "2-digit", hourCycle: "h23" }).format(e.start))).toEqual(["10 Uhr", "10 Uhr", "10 Uhr"]);
  });
  it("prevents removal of the final administration role", async () => {
    const role = await db.role.findUniqueOrThrow({ where: { code: "ADMIN" } }).catch(() => db.role.findUniqueOrThrow({ where: { id: demoId("role-admin") } }));
    await expect(manageRole(admin, { id: role.id, code: role.code, name: role.name, active: "on" }, [])).rejects.toThrow("Administration");
  });
});

describe("transactional communication delivery with fake adapter", () => {
  it("separates mail and calendar retries and never resends a completed mail", async () => {
    const { processOutbox } = await import("../../src/domains/notifications/worker");
    const { updateCommunication } = await import("../../src/domains/notifications/service");
    const { GraphError } = await import("../../src/domains/integrations/graph");
    await db.outboxMessage.updateMany({ where: { state: "PENDING" }, data: { state: "FAILED", lastErrorCode: "TEST_ISOLATION" } });
    const id = await make(); await updateCommunication(admin, id, { recipients: "", calendar: true });
    let mails = 0, calendars = 0, throttle = true;
    const adapter = { async sendMail() { mails++; }, async syncCalendar() { calendars++; if (throttle) throw new GraphError("GRAPH_429", 1); return { externalId: "fake-remote-event" }; } };
    await processOutbox(adapter, "https://bevems.example.invalid", 30);
    const sentMails = mails; expect(sentMails).toBe(2); expect(calendars).toBe(1);
    throttle = false;
    await db.outboxMessage.updateMany({ where: { eventId: id, state: "PENDING" }, data: { nextAttemptAt: new Date(0) } });
    await processOutbox(adapter, "https://bevems.example.invalid", 30);
    expect(mails).toBe(sentMails); expect(calendars).toBe(2);
    expect((await db.calendarInvitation.findFirstOrThrow({ where: { eventId: id } })).externalId).toBe("fake-remote-event");
  });
  it("does not blindly retry uncertain external delivery outcomes", async () => {
    const { processOutbox } = await import("../../src/domains/notifications/worker");
    const id = await make(); let attempts = 0;
    const adapter = { async sendMail() { attempts++; throw new Error("connection reset after send"); }, async syncCalendar() { return { externalId: null }; } };
    await processOutbox(adapter, "https://bevems.example.invalid"); await processOutbox(adapter, "https://bevems.example.invalid");
    expect(attempts).toBe(1); expect((await db.outboxMessage.findFirstOrThrow({ where: { eventId: id } })).lastErrorCode).toBe("DELIVERY_OUTCOME_UNKNOWN");
  });
});

describe("private documents and templates", () => {
  it("quarantines unscanned documents, authorizes downloads and logs successful reads", async () => {
    const { uploadDocument, downloadDocument, rescanPendingDocuments } = await import("../../src/domains/documents/service");
    const files = new Map<string, Uint8Array>();
    const storage = { async put(key: string, data: Uint8Array) { files.set(key, data); }, async read(key: string) { const data = files.get(key); if (!data) throw new Error("missing"); return data; }, async remove(key: string) { files.delete(key); } };
    const id = await make({ visibility: "ALL_EMPLOYEES" });
    const documentId = await uploadDocument(admin, id, "ablauf.txt", new TextEncoder().encode("Begrüßung"), storage, { async scan() { return "PENDING"; } });
    await expect(downloadDocument(admin, id, documentId, storage)).rejects.toMatchObject({ status: 404 });
    await expect(downloadDocument(employee, id, documentId, storage)).rejects.toMatchObject({ status: 403 });
    await rescanPendingDocuments(storage, { async scan() { return "CLEAN"; } });
    expect(new TextDecoder().decode((await downloadDocument(admin, id, documentId, storage)).data)).toBe("Begrüßung");
    expect(await db.auditLog.count({ where: { eventId: id, action: "document.downloaded" } })).toBe(1);
    await expect(uploadDocument(admin, id, "../bad.txt", new TextEncoder().encode("Test"), storage)).rejects.toThrow("Dateiname");
    await expect(uploadDocument(admin, id, "bad.txt", new TextEncoder().encode("Test"), storage, { async scan() { return "INFECTED"; } })).rejects.toThrow("abgelehnt");
    expect(files.size).toBe(1);
  });
  it("does not expose private event templates to a different organizer", async () => {
    const id = await make(); const templateId = await saveTemplate(admin, id, "Privatvorlage");
    await expect(instantiateTemplate(organizer, templateId, "2029-01-01T10:00:00Z")).rejects.toThrow("Vorlage nicht gefunden");
  });
  it("does not expose participants in global search without separate rights", async () => {
    const { searchAll } = await import("../../src/domains/events/search");
    const id = await make({ visibility: "ALL_EMPLOYEES" });
    await addParticipant(admin, id, { firstName: "Geheimname", lastName: "Suchtest", email: "", function: "", categoryId: demoId("category-0"), organisationId: "" });
    expect((await searchAll(employee, "Geheimname")).participants).toEqual([]);
    expect((await searchAll(admin, "Geheimname")).participants).toHaveLength(1);
  });
});

describe("matching and retention", () => {
  it("uses actual language levels only with separate permission and rejects oversized workshop groups", async () => {
    const trades = await db.trade.findMany({ select: { id: true } });
    const input = { start: "2031-05-01T09:00:00Z", end: "2031-05-01T10:00:00Z", visitors: 5, languageId: demoId("language-en"), tradeIds: trades.map((t) => t.id) };
    const result = await suggestWorkshops(admin, input);
    expect(result.find((w) => w.name === "Elektrowerkstatt")?.candidates[0].recommendation).toBe("Sehr gut geeignet");
    const restricted = { ...admin, grants: admin.grants.filter((g) => g.permission !== "employee.view_languages") };
    expect((await suggestWorkshops(restricted, input)).every((w) => w.candidates.every((e) => e.level === null && e.score === 0))).toBe(true);
    expect((await suggestWorkshops(admin, { ...input, visitors: 30 })).every((w) => !w.available)).toBe(true);
  });
  it("keeps retention a dry-run until approved and deletes participant children atomically", async () => {
    const { expireParticipantData } = await import("../../src/domains/participants/retention");
    const id = await make();
    await addParticipant(admin, id, { firstName: "Frist", lastName: "Test", email: "", function: "", categoryId: demoId("category-0"), organisationId: "" });
    const person = await db.eventParticipant.findFirstOrThrow({ where: { eventId: id } });
    await db.eventParticipant.update({ where: { id: person.id }, data: { retentionUntil: new Date(0) } });
    await db.event.update({ where: { id }, data: { statusId: demoId("status-COMPLETED") } });
    const previous = process.env.PARTICIPANT_RETENTION_APPROVED;
    try {
      process.env.PARTICIPANT_RETENTION_APPROVED = "false";
      expect(await expireParticipantData()).toEqual({ candidates: 1, deleted: 0 });
      await expect(expireParticipantData(true)).rejects.toThrow("approved");
      process.env.PARTICIPANT_RETENTION_APPROVED = "true";
      expect(await expireParticipantData(true)).toEqual({ candidates: 1, deleted: 1 });
      expect(await db.eventInvitation.count({ where: { participantId: person.id } })).toBe(0);
      expect(await db.auditLog.count({ where: { eventId: id, action: "participant.retention_deleted" } })).toBe(1);
    } finally { if (previous === undefined) delete process.env.PARTICIPANT_RETENTION_APPROVED; else process.env.PARTICIPANT_RETENTION_APPROVED = previous; }
  });
});
