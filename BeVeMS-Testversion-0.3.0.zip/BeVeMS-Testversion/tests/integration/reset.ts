import { Client } from "pg";
// This helper is restricted to the explicitly dedicated integration database, never the development dataset.
export async function resetIntegrationData() {
  const url = process.env.TEST_DATABASE_URL;
  if (!url || new URL(url).pathname !== "/bevems_phase2_test") throw new Error("Refusing reset outside dedicated integration database");
  const client = new Client({ connectionString: url }); await client.connect();
  try {
    const result = await client.query<{ tablename: string }>("SELECT tablename FROM pg_tables WHERE schemaname = 'public' AND tablename <> '_prisma_migrations'");
    if (result.rows.length) await client.query(`TRUNCATE ${result.rows.map((r) => `"${r.tablename.replaceAll('"', '""')}"`).join(", ")} RESTART IDENTITY CASCADE`);
  } finally { await client.end(); }
}
