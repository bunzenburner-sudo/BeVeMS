import { resetIntegrationData } from "./reset";
import { beforeAll, afterAll, describe, expect, it, vi } from "vitest";
import { execFileSync } from "node:child_process";
import { randomUUID } from "node:crypto";
import { Client } from "pg";
import { db } from "../../src/lib/db";
import { demoId, seedDemo } from "../../prisma/seed";
import { loadActor } from "../../src/domains/identity/actor";
import { listEvents, eventDetail } from "../../src/domains/events/service";
import { listEmployees } from "../../src/domains/employees/service";
import { administrationOverview } from "../../src/domains/administration/service";
import { visibleEventsWhere } from "../../src/domains/events/policy";
import { resolveEntraIdentity } from "../../src/domains/identity/entra-user";

const owner = new Client({ connectionString: process.env.TEST_DATABASE_URL });
const actor = async (profile: string) => (await loadActor(demoId(`user-${profile}`)))!;
beforeAll(async () => {
  execFileSync(process.execPath, ["tools/prisma-wasm.cjs", "deploy"], { env: { ...process.env, DATABASE_URL: process.env.TEST_DATABASE_URL, MIGRATION_DATABASE_URL: process.env.TEST_DATABASE_URL }, stdio: "pipe" });
  await resetIntegrationData();
  process.env.ALLOW_DEMO_SEED = "true"; process.env.DEMO_DATABASE_NAME = "bevems_phase2_test";
  await seedDemo(process.env.TEST_DATABASE_URL);
  execFileSync(process.execPath, ["--import", "tsx", "tools/provision-runtime.ts"], { env: { ...process.env, MIGRATION_DATABASE_URL: process.env.TEST_DATABASE_URL }, stdio: "pipe" });
  await owner.connect();
});
afterAll(async () => { await owner.end(); await db.$disconnect(); });

async function rolledBack(operation: (client: Client) => Promise<void>) {
  await owner.query("BEGIN");
  try { await operation(owner); } finally { await owner.query("ROLLBACK"); }
}

describe("migrations and demo dataset", () => {
  it("applies migrations repeatably with no pending work", () => {
    const output = execFileSync(process.execPath, ["tools/prisma-wasm.cjs", "deploy"], { env: { ...process.env, DATABASE_URL: process.env.TEST_DATABASE_URL, MIGRATION_DATABASE_URL: process.env.TEST_DATABASE_URL }, encoding: "utf8" });
    expect(output).toContain("up to date");
  });
  it("seeds eight events and remains idempotent", async () => {
    const before = { events: await db.event.count(), users: await db.user.count(), tasks: await db.eventTask.count(), audit: await db.auditLog.count() };
    await seedDemo(process.env.TEST_DATABASE_URL);
    expect({ events: await db.event.count(), users: await db.user.count(), tasks: await db.eventTask.count(), audit: await db.auditLog.count() }).toEqual(before);
    expect(before.events).toBe(8); expect(before.users).toBe(5); expect(before.tasks).toBe(24);
    expect(await db.workshop.count()).toBe(3); expect(await db.eventType.count()).toBe(10);
  });
  it("prevents a production demo seed", async () => {
    vi.stubEnv("NODE_ENV", "production");
    try { await expect(seedDemo(process.env.TEST_DATABASE_URL)).rejects.toThrow("forbidden"); }
    finally { vi.unstubAllEnvs(); }
  });
});

describe("server-side permissions and visibility", () => {
  it("excludes the private event from employee lists and detail lookups", async () => {
    const employee = await actor("employee");
    expect(await listEvents(employee)).toHaveLength(7);
    await expect(eventDetail(employee, demoId("event-6"))).rejects.toMatchObject({ status: 404 });
    expect(await listEvents(employee, "vertraulich")).toEqual([]);
  });
  it("includes own sensitive events for the organizer", async () => { expect(await listEvents(await actor("organizer"))).toHaveLength(8); });
  it("allows explicit administrative sensitive-event access", async () => { expect(await listEvents(await actor("admin"))).toHaveLength(8); });
  it("keeps site scopes and visibility independent", async () => {
    const events = await listEvents(await actor("site")); expect(events).toHaveLength(6);
    expect(events.every((event) => event.eventLocation_event.some((location) => location.location.id === demoId("location-0")))).toBe(true);
  });
  it("rejects admin and employee-directory requests without the right", async () => {
    await expect(administrationOverview(await actor("employee"))).rejects.toMatchObject({ status: 403 });
    await expect(listEmployees(await actor("employee"))).rejects.toMatchObject({ status: 403 });
  });
  it("only returns the instructor's own language profile", async () => {
    const employees = await listEmployees(await actor("instructor"));
    expect(employees).toHaveLength(1); expect(employees[0].id).toBe(demoId("employee-instructor"));
    expect(employees[0].languages?.find((language) => language.language.name === "Englisch")?.level).toBe("C1");
  });
  it("omits languages when the separate permission is absent", async () => {
    const organizer = await actor("organizer"); organizer.grants = organizer.grants.filter((grant) => grant.permission !== "employee.view_languages");
    const employees = await listEmployees(organizer); expect(employees).toHaveLength(7);
    expect(employees.every((employee) => !("languages" in employee))).toBe(true);
  });
  it("does not grant access with empty role permissions", async () => {
    const employee = await actor("employee"); employee.grants = [];
    expect(await listEvents(employee)).toEqual([]);
  });
  it("reloads revoked roles and deactivated accounts", async () => {
    const userId = demoId("user-employee");
    await db.user.update({ where: { id: userId }, data: { active: false } });
    try { expect(await loadActor(userId)).toBeNull(); } finally { await db.user.update({ where: { id: userId }, data: { active: true } }); }
    const roleId = demoId("role-employee");
    await db.role.update({ where: { id: roleId }, data: { active: false } });
    try { expect((await loadActor(userId))?.grants).toHaveLength(0); } finally { await db.role.update({ where: { id: roleId }, data: { active: true } }); }
  });
  it("enforces location, unit, group and explicit participation audiences", async () => {
    const employee = await actor("employee");
    const eventId = demoId("event-5");
    for (const mode of ["LOCATIONS", "UNITS"] as const) {
      await db.$transaction(async (tx) => {
        await tx.event.update({ where: { id: eventId }, data: { visibility: mode } });
        expect(await tx.event.findFirst({ where: { AND: [{ id: eventId }, visibleEventsWhere(employee)] } })).toBeNull();
        if (mode === "LOCATIONS") await tx.eventVisibilityLocation.create({ data: { eventId, locationId: employee.locationId } });
        else await tx.eventVisibilityUnit.create({ data: { eventId, unitId: employee.unitId } });
        expect(await tx.event.findFirst({ where: { AND: [{ id: eventId }, visibleEventsWhere(employee)] } })).not.toBeNull();
        throw new Error("ROLLBACK_FIXTURE");
      }).catch((error) => { if (error.message !== "ROLLBACK_FIXTURE") throw error; });
    }
    // Transaction-local Prisma client checks real query predicates, with rollback afterwards.
    await db.$transaction(async (tx) => {
      await tx.event.update({ where: { id: eventId }, data: { visibility: "GROUPS" } });
      const group = await tx.userGroup.create({ data: { name: `test-${randomUUID()}` } });
      await tx.eventVisibilityGroup.create({ data: { eventId, groupId: group.id } });
      expect(await tx.event.findFirst({ where: { AND: [{ id: eventId }, visibleEventsWhere(employee)] } })).toBeNull();
      employee.groups = [group.id];
      expect(await tx.event.findFirst({ where: { AND: [{ id: eventId }, visibleEventsWhere(employee)] } })).not.toBeNull();
      throw new Error("ROLLBACK_FIXTURE");
    }).catch((error) => { if (error.message !== "ROLLBACK_FIXTURE") throw error; });
    await db.$transaction(async (tx) => {
      await tx.event.update({ where: { id: eventId }, data: { visibility: "INVOLVED" } });
      expect(await tx.event.findFirst({ where: { AND: [{ id: eventId }, visibleEventsWhere(employee)] } })).toBeNull();
      await tx.eventInvolvement.create({ data: { eventId, employeeId: employee.employeeId } });
      expect(await tx.event.findFirst({ where: { AND: [{ id: eventId }, visibleEventsWhere(employee)] } })).not.toBeNull();
      throw new Error("ROLLBACK_FIXTURE");
    }).catch((error) => { if (error.message !== "ROLLBACK_FIXTURE") throw error; });
  });
});

describe("PostgreSQL invariants", () => {
  it("rejects incomplete historical actual-cost values", async () => { await rolledBack(async (client) => { await expect(client.query('UPDATE "Event" SET "actualCost"=1, "currency"=NULL WHERE "id"=$1', [demoId("event-0")])).rejects.toMatchObject({ code: "23514" }); }); });
  it("rejects nonpositive room capacity", async () => { await rolledBack(async (client) => { await expect(client.query('UPDATE "Room" SET "capacity"=0 WHERE "id"=$1', [demoId("room-0")])).rejects.toMatchObject({ code: "23514" }); }); });
  it("rejects invalid event intervals", async () => { await rolledBack(async (client) => { await expect(client.query('UPDATE "Event" SET "end"="start" WHERE "id"=$1', [demoId("event-0")])).rejects.toMatchObject({ code: "23514" }); }); });
  it("rejects duplicate global roles with NULL site", async () => { await rolledBack(async (client) => { await expect(client.query('INSERT INTO "UserRole" ("id", "userId", "roleId") VALUES ($1,$2,$3)', [randomUUID(), demoId("user-employee"), demoId("role-employee")])).rejects.toMatchObject({ code: "23505" }); }); });
  it("rejects invalid schedule hierarchy", async () => {
    const event = await db.event.findUniqueOrThrow({ where: { id: demoId("event-0") } });
    await rolledBack(async (client) => { await expect(client.query('INSERT INTO "EventScheduleItem" ("id","eventId","title","start","end","sortOrder","roomId","buildingId","locationId") VALUES ($1,$2,$3,$4,$5,0,$6,$7,$8)', [randomUUID(), event.id, "Bad hierarchy", event.start, event.end, demoId("room-3"), demoId("building-0-0"), demoId("location-0")])).rejects.toMatchObject({ code: "23514" }); });
  });
  it("protects audit logs against owner mutation too", async () => { await rolledBack(async (client) => { await expect(client.query('DELETE FROM "AuditLog" WHERE "id"=$1', [demoId("audit-seed")])).rejects.toMatchObject({ code: "42501" }); }); });
  it("denies DDL, migration metadata and audit mutation to the runtime role", async () => {
    if (!process.env.TEST_APP_DATABASE_URL) throw new Error("TEST_APP_DATABASE_URL required.");
    const app = new Client({ connectionString: process.env.TEST_APP_DATABASE_URL }); await app.connect();
    try {
      expect((await app.query('SELECT count(*) FROM "Event"')).rows[0].count).toBe("8");
      await expect(app.query('SELECT * FROM "_prisma_migrations"')).rejects.toMatchObject({ code: "42501" });
      await expect(app.query('DELETE FROM "AuditLog"')).rejects.toMatchObject({ code: "42501" });
      await expect(app.query('CREATE TABLE unauthorized_table (id int)')).rejects.toMatchObject({ code: "42501" });
    } finally { await app.end(); }
  });
});

describe("Entra local identity mapping", () => {
  it("requires the tenant/object ID pair and an active explicit binding", async () => {
    const tid = randomUUID(), oid = randomUUID();
    expect(await resolveEntraIdentity({ tid, oid, email: "organizer@demo.invalid" }, tid)).toBeNull();
    const user = await db.user.create({ data: { tenantId: tid, subject: oid } });
    const employee = await db.employee.create({ data: { userId: user.id, firstName: "SSO", lastName: "Fixture", email: `${oid}@demo.invalid`, unitId: demoId("unit-Organisation"), locationId: demoId("location-0") } });
    try {
      expect((await resolveEntraIdentity({ tid, oid }, tid))?.id).toBe(user.id);
      expect(await resolveEntraIdentity({ tid: randomUUID(), oid }, tid)).toBeNull();
      await db.user.update({ where: { id: user.id }, data: { active: false } });
      expect(await resolveEntraIdentity({ tid, oid }, tid)).toBeNull();
    } finally { await db.employee.delete({ where: { id: employee.id } }); await db.user.delete({ where: { id: user.id } }); }
  });
});
