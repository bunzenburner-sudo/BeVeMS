import { afterAll, beforeAll, expect, it, vi } from "vitest";
import { execFileSync } from "node:child_process";
import { resetIntegrationData } from "./reset";
import { bootstrapInstallation } from "../../src/domains/administration/bootstrap";
import { db } from "../../src/lib/db";
import { loadActor } from "../../src/domains/identity/actor";
import { permitted } from "../../src/domains/identity/policy";
const input = { tenantId: "11111111-1111-4111-8111-111111111111", subject: "22222222-2222-4222-8222-222222222222", firstName: "Initial", lastName: "Testadmin", email: "bootstrap@example.invalid", locationName: "Teststandort", locationAddress: "Testadresse", unitName: "Testverwaltung" };
beforeAll(async () => { execFileSync(process.execPath, ["tools/prisma-wasm.cjs", "deploy"], { env: { ...process.env, MIGRATION_DATABASE_URL: process.env.TEST_DATABASE_URL }, stdio: "pipe" }); await resetIntegrationData(); });
afterAll(async () => { vi.unstubAllEnvs(); await resetIntegrationData(); await db.$disconnect(); });
it("requires explicit activation for first-time administrator provisioning", async () => { vi.stubEnv("ALLOW_INITIAL_BOOTSTRAP", "false"); await expect(bootstrapInstallation(input)).rejects.toThrow("enabled"); expect(await db.user.count()).toBe(0); });
it("provisions a real-account binding without demo events and refuses a second takeover", async () => {
  vi.stubEnv("ALLOW_INITIAL_BOOTSTRAP", "true"); const result = await bootstrapInstallation(input);
  const actor = await loadActor(result.userId); expect(actor).not.toBeNull(); expect(permitted(actor!, "administration.manage")).toBe(true);
  expect(await db.event.count()).toBe(0); expect(await db.eventType.count()).toBe(10); expect(await db.eventStatusTransition.count()).toBe(6);
  await expect(bootstrapInstallation({ ...input, subject: "33333333-3333-4333-8333-333333333333" })).rejects.toThrow("not empty"); expect(await db.user.count()).toBe(1);
});
