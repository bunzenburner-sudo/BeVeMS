// Only Vitest resolves server-only to this module. Next.js retains the real boundary.
export {};
