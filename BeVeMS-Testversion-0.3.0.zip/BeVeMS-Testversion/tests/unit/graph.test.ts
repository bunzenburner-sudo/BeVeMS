import { describe, expect, it, vi, afterEach } from "vitest";
import { MicrosoftGraphAdapter } from "../../src/domains/integrations/graph";
const env = { ENTRA_TENANT_ID: "11111111-1111-4111-8111-111111111111", GRAPH_CLIENT_ID: "22222222-2222-4222-8222-222222222222", GRAPH_CLIENT_SECRET: "test-secret-not-real-123456", GRAPH_SENDER: "test@example.invalid" };
afterEach(() => vi.unstubAllGlobals());
describe("Microsoft Graph adapter (mocked transport)", () => {
  it("uses client credentials and sends text mail from the configured mailbox", async () => {
    const fetcher = vi.fn().mockResolvedValueOnce(Response.json({ access_token: "test-token", expires_in: 3600 })).mockResolvedValueOnce(new Response(null, { status: 202 })); vi.stubGlobal("fetch", fetcher);
    await new MicrosoftGraphAdapter(env).sendMail("recipient@example.invalid", "Test", "Text only");
    expect(fetcher.mock.calls[0][0]).toContain("login.microsoftonline.com");
    expect(fetcher.mock.calls[1][0]).toBe("https://graph.microsoft.com/v1.0/users/test%40example.invalid/sendMail");
    expect(JSON.parse(fetcher.mock.calls[1][1].body).message.body.contentType).toBe("Text");
  });
  it("creates, updates and cancels calendar events with stable transaction IDs", async () => {
    const fetcher = vi.fn().mockResolvedValueOnce(Response.json({ access_token: "test-token", expires_in: 3600 })).mockResolvedValueOnce(Response.json({ id: "remote-id" })).mockResolvedValueOnce(Response.json({ id: "remote-id" })).mockResolvedValueOnce(new Response(null, { status: 202 })); vi.stubGlobal("fetch", fetcher);
    const adapter = new MicrosoftGraphAdapter(env), message = { eventId: "local", recipient: "recipient@example.invalid", subject: "Event", body: "Body", start: "2028-01-01T09:00:00.000Z", end: "2028-01-01T10:00:00.000Z", cancelled: false, externalId: null, transactionId: "stable-id" };
    expect(await adapter.syncCalendar(message)).toEqual({ externalId: "remote-id" });
    expect(JSON.parse(fetcher.mock.calls[1][1].body).transactionId).toBe("stable-id");
    await adapter.syncCalendar({ ...message, externalId: "remote-id" }); expect(fetcher.mock.calls[2][1].method).toBe("PATCH");
    await adapter.syncCalendar({ ...message, externalId: "remote-id", cancelled: true }); expect(fetcher.mock.calls[3][0]).toContain("events/remote-id/cancel");
  });
  it("honors throttling without revealing response bodies", async () => {
    const fetcher = vi.fn().mockResolvedValueOnce(Response.json({ access_token: "test-token", expires_in: 3600 })).mockResolvedValueOnce(new Response("private error", { status: 429, headers: { "retry-after": "120" } })); vi.stubGlobal("fetch", fetcher);
    await expect(new MicrosoftGraphAdapter(env).sendMail("a@example.invalid", "Subject", "Body")).rejects.toMatchObject({ code: "GRAPH_429", retryAfter: 120, message: "GRAPH_429" });
  });
});
