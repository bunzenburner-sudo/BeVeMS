import { describe, expect, it } from "vitest";
import { berlinInput, berlinToIso } from "../../src/lib/dates";
import { languageRecommendation } from "../../src/domains/reservations/matching";
describe("Berlin business dates", () => {
  it("converts wall times independently of process timezone", () => { expect(berlinToIso("2028-02-01T10:00")).toBe("2028-02-01T09:00:00.000Z"); expect(berlinToIso("2028-07-01T10:00")).toBe("2028-07-01T08:00:00.000Z"); });
  it("rejects nonexistent and ambiguous DST wall times", () => { expect(berlinToIso("2028-03-26T02:30")).toBe(""); expect(berlinToIso("2028-10-29T02:30")).toBe(""); });
  it("formats ISO instants in Berlin", () => { expect(berlinInput("2028-07-01T08:00Z")).toBe("2028-07-01T10:00"); });
});
it("requires B2 for a suitable language match", () => { expect(languageRecommendation(3)).toBe("Übersetzung erforderlich"); expect(languageRecommendation(4)).toBe("Geeignet"); expect(languageRecommendation(5)).toBe("Sehr gut geeignet"); });
