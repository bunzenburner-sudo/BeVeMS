import { afterEach, describe, expect, it, vi } from "vitest";
import { sameOriginRequest } from "../../src/lib/csrf";
import { boundedBody } from "../../src/lib/request-body";
afterEach(() => vi.unstubAllEnvs());
describe("same origin mutation routes", () => {
  it("compares the received Host even when Next normalizes its internal URL", () => { vi.stubEnv("NODE_ENV", "development"); vi.stubEnv("APP_BASE_URL", ""); expect(sameOriginRequest(new Request("http://localhost:3000/api", { headers: { host: "127.0.0.1:3000", origin: "http://127.0.0.1:3000" } }))).toBe(true); });
  it("rejects foreign or absent origins", () => { vi.stubEnv("APP_BASE_URL", ""); expect(sameOriginRequest(new Request("http://localhost/api", { headers: { host: "localhost", origin: "https://evil.example" } }))).toBe(false); expect(sameOriginRequest(new Request("http://localhost/api"))).toBe(false); });
  it("requires canonical HTTPS origins in production", () => { vi.stubEnv("NODE_ENV", "production"); vi.stubEnv("APP_BASE_URL", "https://bevems.example.invalid"); expect(sameOriginRequest(new Request("http://internal/api", { headers: { host: "internal", origin: "https://bevems.example.invalid" } }))).toBe(true); expect(sameOriginRequest(new Request("http://internal/api", { headers: { host: "internal", origin: "http://bevems.example.invalid" } }))).toBe(false); });
});
it("caps actual streamed bytes independently of Content-Length", async () => {
  const stream = new ReadableStream({ start(controller) { controller.enqueue(new Uint8Array(10)); controller.enqueue(new Uint8Array(10)); controller.close(); } });
  await expect(boundedBody(new Request("http://localhost", { method: "POST", body: stream, duplex: "half", headers: { "content-length": "1" } } as RequestInit), 15)).rejects.toThrow("too large");
});
