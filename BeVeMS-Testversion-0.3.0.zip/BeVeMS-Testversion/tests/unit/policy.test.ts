import { describe, expect, it, vi } from "vitest";
import { hasPermission, permitted, type Actor } from "../../src/domains/identity/policy";
import { identityConfig } from "../../src/domains/identity/config";
import { createEntraProvider } from "../../src/domains/identity/entra-provider";

const actor: Actor = { id: "user", employeeId: "employee", name: "Test", locationId: "site-a", unitId: "unit", groups: [], grants: [] };
describe("granular permission scopes", () => {
  it("denies missing grants", () => { expect(permitted(actor, "event.edit", { ownerId: "employee" })).toBe(false); });
  it("limits OWN to the exact owner", () => {
    const owner = { ...actor, grants: [{ permission: "event.edit", scope: "OWN" as const, locationId: null }] };
    expect(permitted(owner, "event.edit", { ownerId: "employee" })).toBe(true);
    expect(permitted(owner, "event.edit", { ownerId: "another" })).toBe(false);
  });
  it("limits ASSIGNED to the exact assignee", () => {
    const contributor = { ...actor, grants: [{ permission: "task.edit", scope: "ASSIGNED" as const, locationId: null }] };
    expect(permitted(contributor, "task.edit", { assignedEmployeeId: "employee" })).toBe(true);
    expect(permitted(contributor, "task.edit", { ownerId: "employee" })).toBe(false);
  });
  it("requires an explicit matching site binding", () => {
    const site = { ...actor, grants: [{ permission: "room.reserve", scope: "LOCATION" as const, locationId: "site-a" }] };
    expect(permitted(site, "room.reserve", { locationIds: ["site-a"] })).toBe(true);
    expect(permitted(site, "room.reserve", { locationIds: ["site-b"] })).toBe(false);
    expect(hasPermission({ ...site, grants: [{ ...site.grants[0], locationId: null }] }, "room.reserve")).toBe(false);
  });
});
describe("identity configuration", () => {
  it("maps OIDC identity without an unrelated Graph request or personal profile copy", async () => {
    const network = vi.spyOn(globalThis, "fetch").mockRejectedValue(new Error("Unexpected network request"));
    try {
      const provider = createEntraProvider("tenant-fixture", "client-fixture", "non-secret-fixture");
      const profile = provider.profile!;
      expect(await profile({ sub: "verified-subject" } as Parameters<typeof profile>[0], {})).toEqual({ id: "verified-subject" });
      expect(network).not.toHaveBeenCalled();
    } finally { network.mockRestore(); }
  });
  it("allows an unconfigured locked application", () => { expect(identityConfig({ NODE_ENV: "production" })).toEqual({ configured: false, demo: false }); });
  it("rejects partially configured Entra", () => { expect(() => identityConfig({ ENTRA_CLIENT_ID: "missing-rest" })).toThrow(); });
  it("forbids demo authentication in production", () => { expect(() => identityConfig({ NODE_ENV: "production", DEMO_AUTH_ENABLED: "true" })).toThrow(); });
  it("requires strong secrets for development demo", () => { expect(() => identityConfig({ NODE_ENV: "development", DEMO_AUTH_ENABLED: "true", DEMO_AUTH_PASSWORD: "weak" })).toThrow(); });
  it("enables demo only in development", () => { expect(identityConfig({ NODE_ENV: "development", DEMO_AUTH_ENABLED: "true", DEMO_AUTH_PASSWORD: "x".repeat(24), AUTH_SECRET: "x".repeat(48) }).demo).toBe(true); });
});
