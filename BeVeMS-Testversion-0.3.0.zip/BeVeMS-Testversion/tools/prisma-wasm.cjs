// Pinned official Prisma APIs. No native artifact/checksum downloads are needed.
// These internal APIs are deliberately version-locked and covered by integration tests.
const fs = require('node:fs/promises');
const path = require('node:path');
const { createHash } = require('node:crypto');
const { Pool } = require('pg');
const { PrismaPg } = require('@prisma/adapter-pg');
const { bindMigrationAwareSqlAdapterFactory } = require('@prisma/driver-adapter-utils');
const { getGenerators } = require('@prisma/internals');
const { defaultRegistry } = require('@prisma/client-generator-registry');
const schemaWasm = require('@prisma/prisma-schema-wasm');

async function main() {
  const command = process.argv[2];
  const schemaPath = path.resolve('prisma/schema.prisma');
  const schema = await fs.readFile(schemaPath, 'utf8');
  if (command === 'validate') {
    schemaWasm.validate(JSON.stringify({ prismaSchema: schema }));
    console.log('Prisma schema validated (official WASM engine).');
    return;
  }
  if (command === 'generate') {
    const generators = await getGenerators({ schemaPath, registry: defaultRegistry.toInternal(), cliCommand: 'prisma', skipDownload: true });
    try { for (const generator of generators) await generator.generate(); }
    finally { for (const generator of generators) generator.stop(); }
    console.log('Prisma client generated (official generator, WASM runtime).');
    return;
  }
  if (!['diff', 'deploy', 'resolve-rolled-back'].includes(command)) throw new Error('Use validate, generate, diff, deploy or resolve-rolled-back.');
  const connectionString = process.env.MIGRATION_DATABASE_URL ?? process.env.DATABASE_URL;
  if (!connectionString) throw new Error('DATABASE_URL or MIGRATION_DATABASE_URL is required.');
  const pool = new Pool({ connectionString });
  const factory = new PrismaPg(pool);
  const connect = factory.connect.bind(factory);
  factory.connect = async () => {
    const driver = await connect();
    // The stock adapter splits on semicolons and breaks dollar-quoted SQL functions.
    // Send the entire trusted migration as one PostgreSQL simple-protocol query.
    driver.executeScript = async (script) => { await pool.query(script); };
    return driver;
  };
  const adapter = bindMigrationAwareSqlAdapterFactory(factory);
  const runtime = await import('@prisma/schema-engine-wasm/schema_engine_bg');
  const bytes = await fs.readFile(path.join(path.dirname(require.resolve('@prisma/schema-engine-wasm')), 'schema_engine_bg.wasm'));
  const instance = new WebAssembly.Instance(new WebAssembly.Module(bytes), { './schema_engine_bg.js': runtime });
  runtime.__wbg_set_wasm(instance.exports);
  instance.exports.__wbindgen_start();
  const engine = await runtime.SchemaEngine.new({ datamodels: [['schema.prisma', schema]] }, () => {}, adapter);
  const filters = { externalTables: [], externalEnums: [] };
  try {
    if (command === 'resolve-rolled-back') {
      const name = process.argv[3];
      if (!name || !/^\d{14}_[a-z_]+$/.test(name)) throw new Error('Pass the exact failed migration directory name after verifying its transaction rolled back.');
      await engine.markMigrationRolledBack({ migrationName: name });
      console.log('Failed migration marked as rolled back:', name);
    } else if (command === 'diff') {
      const result = await engine.diff({ from: { tag: 'empty' }, to: { tag: 'schemaDatamodel', files: [{ path: 'schema.prisma', content: schema }] }, script: true, exitCode: false, filters });
      if (!result.stdout) throw new Error('Empty migration output.');
      process.stdout.write(result.stdout);
    } else {
      const baseDir = path.resolve('prisma/migrations');
      const directories = (await fs.readdir(baseDir, { withFileTypes: true })).filter((entry) => entry.isDirectory()).sort((a, b) => a.name.localeCompare(b.name));
      const migrationsList = {
        baseDir, lockfile: { path: 'migration_lock.toml', content: await fs.readFile(path.join(baseDir, 'migration_lock.toml'), 'utf8') }, shadowDbInitScript: '',
        migrationDirectories: await Promise.all(directories.map(async (entry) => ({ path: entry.name, migrationFile: { path: 'migration.sql', content: { tag: 'ok', value: await fs.readFile(path.join(baseDir, entry.name, 'migration.sql'), 'utf8') } } }))),
      };
      const table = await pool.query("SELECT to_regclass('public._prisma_migrations') AS name");
      if (table.rows[0].name) {
        const applied = await pool.query('SELECT migration_name, checksum FROM "_prisma_migrations" WHERE finished_at IS NOT NULL AND rolled_back_at IS NULL');
        for (const row of applied.rows) {
          const migration = migrationsList.migrationDirectories.find((directory) => directory.path === row.migration_name);
          if (!migration || createHash('sha256').update(migration.migrationFile.content.value).digest('hex') !== row.checksum) {
            throw new Error(`Applied migration missing or changed: ${row.migration_name}. Preserve existing migrations and add a new migration.`);
          }
        }
      }
      const result = await engine.applyMigrations({ migrationsList, filters });
      console.log('Applied migrations:', result.appliedMigrationNames.length ? result.appliedMigrationNames.join(', ') : 'none (up to date)');
    }
  } finally { engine.free(); await pool.end(); }
}
main().catch((error) => { console.error('Prisma WASM operation failed:', error.message); process.exitCode = 1; });
