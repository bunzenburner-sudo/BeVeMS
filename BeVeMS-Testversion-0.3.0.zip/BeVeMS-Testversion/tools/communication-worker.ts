// Run only as an explicit deployment operation, never as a side effect of setup or build.
import { MicrosoftGraphAdapter } from "../src/domains/integrations/graph";
import { processOutbox } from "../src/domains/notifications/worker";
import { db } from "../src/lib/db";
if (process.env.GRAPH_DELIVERY_ENABLED !== "true") throw new Error("External delivery is disabled. Configure and explicitly enable GRAPH_DELIVERY_ENABLED before running this worker.");
if (!process.env.APP_BASE_URL) throw new Error("APP_BASE_URL is required");
try { console.log(`Delivered ${await processOutbox(new MicrosoftGraphAdapter(), process.env.APP_BASE_URL)} messages.`); }
finally { await db.$disconnect(); }
