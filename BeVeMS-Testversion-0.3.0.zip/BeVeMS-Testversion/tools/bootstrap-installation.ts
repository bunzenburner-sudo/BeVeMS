import { bootstrapInstallation } from "../src/domains/administration/bootstrap";
import { db } from "../src/lib/db";
try {
  await bootstrapInstallation({ tenantId: process.env.ENTRA_TENANT_ID, subject: process.env.BOOTSTRAP_ADMIN_OBJECT_ID, firstName: process.env.BOOTSTRAP_ADMIN_FIRST_NAME, lastName: process.env.BOOTSTRAP_ADMIN_LAST_NAME, email: process.env.BOOTSTRAP_ADMIN_EMAIL, locationName: process.env.BOOTSTRAP_LOCATION_NAME, locationAddress: process.env.BOOTSTRAP_LOCATION_ADDRESS, unitName: process.env.BOOTSTRAP_UNIT_NAME });
  console.log("Initial installation provisioned. Disable ALLOW_INITIAL_BOOTSTRAP and sign in with the explicitly bound Entra account.");
} catch { console.error("Bootstrap refused or failed. Verify explicitly enabled configuration and that the installation is empty. No credentials were printed."); process.exitCode = 1; }
finally { await db.$disconnect(); }
