import { expireParticipantData } from "../src/domains/participants/retention";
import { db } from "../src/lib/db";
try { console.log(await expireParticipantData(process.argv.includes("--apply"))); } finally { await db.$disconnect(); }
