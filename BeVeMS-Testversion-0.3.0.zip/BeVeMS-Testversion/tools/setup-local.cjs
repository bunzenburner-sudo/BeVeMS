const fs = require('node:fs');
const crypto = require('node:crypto');
const { parseEnv } = require('node:util');
const { execFileSync } = require('node:child_process');
const { Client } = require('pg');

async function main() {
  if (process.env.NODE_ENV === 'production') throw new Error('Local demo setup is forbidden in production.');
  if (!fs.existsSync('.env')) {
    if (fs.existsSync('.env.setup')) throw new Error('Existing .env.setup preserved; configure the missing runtime .env manually.');
    const postgresPassword = crypto.randomBytes(32).toString('hex');
    const appPassword = crypto.randomBytes(32).toString('hex');
    fs.writeFileSync('.env', [
      `DATABASE_URL=postgresql://bevems_app:${appPassword}@127.0.0.1:5432/bevems`,
      'NEXTAUTH_URL=http://localhost:3000', `AUTH_SECRET=${crypto.randomBytes(48).toString('base64url')}`,
      'DEMO_AUTH_ENABLED=true', `DEMO_AUTH_PASSWORD=${crypto.randomBytes(32).toString('base64url')}`,
      '',
    ].join('\n'), { mode: 0o600, flag: 'wx' });
    fs.writeFileSync('.env.setup', [
      `POSTGRES_PASSWORD=${postgresPassword}`,
      `MIGRATION_DATABASE_URL=postgresql://bevems:${postgresPassword}@127.0.0.1:5432/bevems`,
      `RUNTIME_DATABASE_PASSWORD=${appPassword}`,
      'ALLOW_DEMO_SEED=true', 'DEMO_DATABASE_NAME=bevems',
      `TEST_DATABASE_URL=postgresql://bevems:${postgresPassword}@127.0.0.1:5432/bevems_phase2_test`,
      `TEST_APP_DATABASE_URL=postgresql://bevems_app:${appPassword}@127.0.0.1:5432/bevems_phase2_test`,
      '',
    ].join('\n'), { mode: 0o600, flag: 'wx' });
    console.log('Ignored local runtime and setup configuration created with random credentials. Values are not printed.');
  }
  if (!fs.existsSync('.env.setup')) throw new Error('Setup requires a separate .env.setup file. Existing runtime configuration preserved.');
  const values = parseEnv(fs.readFileSync('.env.setup', 'utf8'));
  const ownerUrl = new URL(values.MIGRATION_DATABASE_URL ?? '');
  if (ownerUrl.hostname !== '127.0.0.1' || ownerUrl.port !== '5432' || ownerUrl.pathname !== '/bevems' || values.DEMO_DATABASE_NAME !== 'bevems' || values.ALLOW_DEMO_SEED !== 'true') throw new Error('This setup only supports an explicitly enabled local bevems demo database. Existing configuration preserved.');
  if (!values.POSTGRES_PASSWORD || !values.RUNTIME_DATABASE_PASSWORD || !values.TEST_DATABASE_URL) throw new Error('Existing .env.setup requires POSTGRES_PASSWORD, RUNTIME_DATABASE_PASSWORD and TEST_DATABASE_URL. Existing values preserved.');
  const env = { ...process.env, ...values };
  const run = (cmd, args) => execFileSync(cmd, args, { env, stdio: 'inherit' });
  run('docker', ['compose', '--env-file', '.env.setup', 'up', '-d', '--wait', 'db']);
  run(process.execPath, ['tools/prisma-wasm.cjs', 'generate']);
  run(process.execPath, ['tools/prisma-wasm.cjs', 'deploy']);
  run(process.execPath, ['--import', 'tsx', 'prisma/seed.ts']);
  run(process.execPath, ['--import', 'tsx', 'tools/provision-runtime.ts']);
  const client = new Client({ connectionString: ownerUrl.toString() });
  await client.connect();
  try {
    if (!(await client.query("SELECT 1 FROM pg_database WHERE datname = 'bevems_phase2_test'")).rowCount) await client.query('CREATE DATABASE bevems_phase2_test');
  } finally { await client.end(); }
  console.log('Local demo setup complete. Start with npm run dev; use the demo password stored in .env.');
}
main().catch((error) => { console.error(error.message); process.exitCode = 1; });
