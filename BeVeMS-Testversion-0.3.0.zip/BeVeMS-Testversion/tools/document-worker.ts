import { rescanPendingDocuments } from "../src/domains/documents/service";
import { db } from "../src/lib/db";
if (!process.env.CLAMAV_HOST) throw new Error("CLAMAV_HOST must point to a trusted internal clamd service");
try { console.log(`Scanned ${await rescanPendingDocuments()} documents.`); } finally { await db.$disconnect(); }
