import { Client } from "pg";

async function main() {
  const owner = process.env.MIGRATION_DATABASE_URL;
  const password = process.env.RUNTIME_DATABASE_PASSWORD;
  if (!owner || !password || password.length < 24) throw new Error("MIGRATION_DATABASE_URL and a strong RUNTIME_DATABASE_PASSWORD are required.");
  const client = new Client({ connectionString: owner });
  await client.connect();
  try {
    await client.query("BEGIN");
    const role = await client.query<{ rolname: string; rolsuper: boolean; rolcreaterole: boolean; rolcreatedb: boolean }>("SELECT rolname, rolsuper, rolcreaterole, rolcreatedb FROM pg_roles WHERE rolname = 'bevems_app'");
    if (role.rows.some((row) => row.rolsuper || row.rolcreaterole || row.rolcreatedb)) throw new Error("Existing runtime role has elevated privileges; refusing to reuse it.");
    if (!role.rowCount) await client.query("CREATE ROLE bevems_app LOGIN NOSUPERUSER NOCREATEDB NOCREATEROLE NOINHERIT");
    const statement = await client.query<{ statement: string }>("SELECT format('ALTER ROLE bevems_app PASSWORD %L', $1::text) AS statement", [password]);
    await client.query(statement.rows[0].statement);
    await client.query('GRANT USAGE ON SCHEMA public TO bevems_app');
    await client.query('GRANT SELECT, INSERT, UPDATE, DELETE ON ALL TABLES IN SCHEMA public TO bevems_app');
    await client.query('REVOKE ALL ON TABLE "_prisma_migrations" FROM bevems_app');
    await client.query('REVOKE UPDATE, DELETE, TRUNCATE ON TABLE "AuditLog" FROM bevems_app');
    await client.query("COMMIT");
    console.log("Runtime database role provisioned; migration metadata and audit mutations protected.");
  } catch (error) { await client.query("ROLLBACK"); throw error; }
  finally { await client.end(); }
}
main().catch((error) => { console.error(error instanceof Error ? error.message : "Runtime provisioning failed"); process.exitCode = 1; });
