const fs = require('node:fs');
const path = require('node:path');
// Copy the exact installed runtime dependency closure, excluding optional peer CLIs and all build tools.
const output = path.resolve(process.argv[2] || '.local/worker-runtime');
const installed = new Set();
const project = process.cwd();
function findPackage(name, from) {
  let directory = from;
  for (;;) { const candidate = path.join(directory, 'node_modules', name); if (fs.existsSync(path.join(candidate, 'package.json'))) return candidate; const parent = path.dirname(directory); if (parent === directory) return null; directory = parent; }
}
function install(name, from, optional = false) {
  const source = findPackage(name, from);
  if (!source) { if (optional) return; throw new Error(`Missing worker dependency: ${name}`); }
  const meta = JSON.parse(fs.readFileSync(path.join(source, 'package.json'), 'utf8'));
  if (installed.has(source)) return;
  installed.add(source);
  const relative = path.relative(project, source);
  if (!relative.startsWith(`node_modules${path.sep}`)) throw new Error(`Dependency outside locked checkout: ${name}`);
  fs.cpSync(source, path.join(output, relative), { recursive: true, dereference: true, filter: (file) => path.basename(file) !== 'node_modules' });
  for (const dependency of Object.keys(meta.dependencies || {})) install(dependency, source);
  for (const dependency of Object.keys(meta.optionalDependencies || {})) install(dependency, source, true);
}
for (const name of ['@prisma/client', '@prisma/adapter-pg', 'pg', 'zod', 'tsx', 'server-only']) install(name, process.cwd());
console.log(`Worker runtime prepared: ${installed.size} packages; development and peer-only tools excluded.`);
