// Inventory and negative validation using the pinned official Prisma WASM schema engine.
const fs = require('node:fs');
const path = require('node:path');
const assert = require('node:assert/strict');

const modulePath = process.argv[2];
const wasm = modulePath ? require(path.resolve(modulePath)) : require('@prisma/prisma-schema-wasm');
const schemaPath = path.resolve(__dirname, '../prisma/schema.prisma');
const schema = fs.readFileSync(schemaPath, 'utf8');
wasm.validate(JSON.stringify({ prismaSchema: schema }));
const dmmf = JSON.parse(wasm.get_dmmf(JSON.stringify({ prismaSchema: schema })));
const names = new Set(dmmf.datamodel.models.map((model) => model.name));
const required = `User Role Permission Employee EmployeeLanguage Language Organisation
ExternalContact Event EventType EventStatus EventResponsibility EventParticipant
EventParticipantGroup EventInvitation EventScheduleItem EventTask EventImpact
EventLessonLearned EventDocument EventVendor EventSeries EventTemplate Location
Building Room RoomType Workshop Trade WorkshopEmployee Reservation RoomBlock
AuditLog Notification EmailRecipient CalendarInvitation CheckIn`.split(/\s+/);
for (const name of required) assert(names.has(name), `Missing entity: ${name}`);
// Ensure the validator actually rejects a broken relation target.
assert.throws(() => wasm.validate(JSON.stringify({
  prismaSchema: schema.replace('model Employee {', 'model MissingEmployee {'),
})));
console.log(`Schema validated; ${names.size} models; ${required.length} required entities present; negative validation passed.`);
