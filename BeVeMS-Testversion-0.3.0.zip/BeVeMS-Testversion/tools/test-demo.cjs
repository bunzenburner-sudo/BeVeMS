const fs = require('node:fs');
const path = require('node:path');
const os = require('node:os');
const { execFileSync } = require('node:child_process');
const { parseEnv } = require('node:util');
const root = path.resolve(__dirname, '..');
process.chdir(root);
const options = { cwd: root, stdio: 'inherit', env: { ...process.env, npm_config_cache: process.env.npm_config_cache || path.join(os.tmpdir(), 'bevems-npm-cache') } };
function npm(args) {
  // Every argument is a fixed application constant; no user input is placed in a shell command.
  if (process.platform === 'win32') execFileSync('cmd.exe', ['/d', '/s', '/c', `npm ${args.join(' ')}`], options);
  else execFileSync('npm', args, options);
}
function main() {
  if (Number(process.versions.node.split('.')[0]) !== 24) throw new Error('Bitte Node.js 24 LTS installieren und den Starter erneut oeffnen.');
  try { execFileSync('docker', ['info'], { ...options, stdio: 'ignore' }); }
  catch { throw new Error('Docker ist nicht bereit. Bitte Docker Desktop installieren/starten, bis es betriebsbereit ist.'); }
  console.log('\nBeVeMS-Testversion wird vorbereitet. Beim ersten Start werden Pakete und PostgreSQL heruntergeladen.\n');
  npm(['ci', '--no-audit', '--no-fund']);
  npm(['run', 'setup:local']);
  const env = parseEnv(fs.readFileSync('.env', 'utf8'));
  if (env.DEMO_AUTH_ENABLED !== 'true' || !env.DEMO_AUTH_PASSWORD) throw new Error('Keine lokale Demo-Anmeldung konfiguriert. Bestehende Konfiguration bleibt erhalten.');
  const access = [
    'BeVeMS - lokale Demo-Anmeldung', '',
    'Adresse auf diesem Rechner: http://localhost:3000',
    'Anmeldung: Demo-Profil Administrator oder Veranstaltungsmanagement waehlen.',
    `Lokales Demo-Passwort: ${env.DEMO_AUTH_PASSWORD}`, '',
    'Dieses Passwort wurde nur fuer deine lokale Testinstallation erzeugt.',
    'Die Datei nicht weitergeben oder in eine Versionsverwaltung aufnehmen.', '',
  ].join('\r\n');
  fs.writeFileSync('DEMO-ZUGANG.txt', access, { mode: 0o600 });
  if (process.platform !== 'win32') fs.chmodSync('DEMO-ZUGANG.txt', 0o600);
  console.log('\nSobald der Server bereit ist, http://localhost:3000 im Browser oeffnen.');
  console.log('Deine Anmeldedaten stehen in DEMO-ZUGANG.txt im entpackten Programmordner.');
  console.log('Dieses Fenster geoeffnet lassen. Zum Beenden Strg+C druecken.\n');
  npm(['run', 'dev']);
}
if (require.main === module) {
  try { main(); }
  catch (error) { console.error(`\nStart fehlgeschlagen: ${error.message}\nHilfe: HIER-STARTEN.txt im Programmordner.`); process.exitCode = 1; }
}
