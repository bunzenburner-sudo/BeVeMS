const fs = require('node:fs/promises');
const path = require('node:path');
async function main() {
  const root = '.next/standalone';
  // Next traces .env into standalone by default; release artifacts must contain no secrets.
  for (const name of await fs.readdir(root)) if (name === '.env' || name.startsWith('.env.')) await fs.rm(path.join(root, name));
  await fs.cp('.next/static', path.join(root, '.next/static'), { recursive: true });
  console.log('Standalone assets prepared; environment files excluded.');
}
main().catch((error) => { console.error(error.message); process.exitCode = 1; });
