import { parseArgs } from "node:util";
import { z } from "zod";
import { PrismaPg } from "@prisma/adapter-pg";
import { PrismaClient } from "../src/generated/prisma/client";

const { values } = parseArgs({ options: {
  tenant: { type: "string" }, subject: { type: "string" }, employee: { type: "string" },
  role: { type: "string", default: "employee" }, location: { type: "string" },
} });
const args = z.object({ tenant: z.uuid(), subject: z.uuid(), employee: z.uuid(), role: z.string().min(1).max(60), location: z.uuid().optional() }).parse(values);
const connectionString = process.env.MIGRATION_DATABASE_URL;
if (!connectionString) throw new Error("Provisioning requires a separate MIGRATION_DATABASE_URL; never use the web runtime credentials.");
const db = new PrismaClient({ adapter: new PrismaPg({ connectionString }) });

async function main() {
  if (args.tenant !== process.env.ENTRA_TENANT_ID) throw new Error("Tenant must match the configured Entra tenant.");
  await db.$transaction(async (tx) => {
    const employee = await tx.employee.findUniqueOrThrow({ where: { id: args.employee } });
    const role = await tx.role.findUniqueOrThrow({ where: { code: args.role }, include: { rolePermission_role: true } });
    if (!employee.active || !role.active) throw new Error("Employee and role must be active.");
    const locationScoped = role.rolePermission_role.some((grant) => grant.scope === "LOCATION");
    if (locationScoped !== !!args.location) throw new Error("Location-scoped roles require a location; other roles must be global.");
    if (args.location && !(await tx.location.findUniqueOrThrow({ where: { id: args.location } })).active) throw new Error("Location must be active.");
    const user = await tx.user.upsert({ where: { tenantId_subject: { tenantId: args.tenant, subject: args.subject } }, update: {}, create: { tenantId: args.tenant, subject: args.subject } });
    const existingEmployee = await tx.employee.findUnique({ where: { userId: user.id } });
    if (!user.active || (employee.userId && employee.userId !== user.id) || (existingEmployee && existingEmployee.id !== employee.id)) throw new Error("Identity is inactive or already bound. Existing bindings are never silently replaced.");
    await tx.employee.update({ where: { id: employee.id }, data: { userId: user.id } });
    const binding = await tx.userRole.findFirst({ where: { userId: user.id, roleId: role.id, locationId: args.location ?? null } });
    if (!binding) {
      await tx.userRole.create({ data: { userId: user.id, roleId: role.id, locationId: args.location } });
      await tx.auditLog.create({ data: { action: "IDENTITY_PROVISIONED", entityType: "User", entityId: user.id, changes: { source: "operator-cli", roleCode: role.code, locationId: args.location ?? null } } });
    }
  });
  console.log("Entra identity linked to the employee and role. Existing bindings preserved.");
}
main().catch((error) => { console.error(error instanceof Error ? error.message : "Provisioning failed"); process.exitCode = 1; }).finally(() => db.$disconnect());
