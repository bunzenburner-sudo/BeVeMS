const { execFileSync } = require('node:child_process');
try {
  // Build never enables the local credentials provider. Runtime config is checked again.
  execFileSync(process.execPath, ['node_modules/next/dist/bin/next', 'build'], {
    env: { ...process.env, DEMO_AUTH_ENABLED: 'false' }, stdio: 'inherit',
  });
  execFileSync(process.execPath, ['tools/prepare-standalone.cjs'], { stdio: 'inherit' });
} catch (error) { process.exitCode = error.status ?? 1; }
