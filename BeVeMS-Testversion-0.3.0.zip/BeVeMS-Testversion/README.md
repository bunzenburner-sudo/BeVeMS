# BeVeMS · HWK Veranstaltungs- & Besuchsmanagement

Zentrale Plattform für besondere Veranstaltungen und externe Besuche der Handwerkskammer Koblenz. Reguläre Lehrgänge, Unterricht, Weiterbildungen, tägliche Ausbildungsraumbelegung und normale interne Besprechungen bleiben in ODAV beziehungsweise bestehenden Systemen.

## Stand: nutzbarer Planungs- und Organisationsausbau

Die technische Grundlage aus Phase 2 ist um die Kernabläufe der Phasen 3–6 erweitert. Veranstaltungen lassen sich als private Entwürfe anlegen und bearbeiten; Kalender, Aufgaben, Fortschritt, Verantwortungsbereiche, Ablaufplan, betriebliche Hinweise und lokal konfliktgesicherte Raum-/Ausbilderbuchungen sind bedienbar. Teilnehmergruppen, Organisationen, Ansprechpartner, Einladungstatus, CSV-Listen und QR-/manueller Check-in ergänzen die Organisation. Historie, Kopien, Serienentwürfe, private Vorlagen, Dienstleister, Lessons Learned und Audit-Protokoll sind verfügbar.

Interne Benachrichtigungen entstehen sofort. Ein separater Worker unterstützt Graph-Mail und Outlook-Abgleich; der echte Versand bleibt ohne explizite Konfiguration deaktiviert. Dokumente liegen privat und werden nur nach erfolgreichem Malware-Scan zum Download freigegeben. Stammdaten und Rollenrechte besitzen Bearbeitungsoberflächen.

**Keine Behauptung einer Produktivfreigabe:** Entra/Graph sind noch nicht im echten HWK-Tenant geprüft. Die Belegungsprüfung kennt lokale Daten; ein externes FM-System ist nicht angeschlossen. Virenscanner, produktive Speicher-/Backupkonfiguration und fachliche Datenschutzfreigaben müssen der Betreiber einrichten. Detaillierter Umfang und bewusst vereinfachte Abläufe stehen in [Umsetzung Phasen 3–6](docs/phasen3-6.md).

## Dokumentation

- [Architektur, vier Fachmodule und ER-Modell](docs/architektur.md)
- [Rechtematrix, Integrationen und Fachregeln](docs/regeln.md)
- [Navigation, User Flows, MVP und offene Entscheidungen](docs/produkt.md)
- [Aktuelle Implementierung, Bedienabläufe und Betriebsgrenzen](docs/phasen3-6.md)
- [Historischer Phase-2-Nachweis](docs/phase2.md)
- [Prisma-Schema](prisma/schema.prisma) und [Migrationen](prisma/migrations)
- [Originalanforderungen](docs/anforderungen.md)

## Technik und Struktur

Node 24 (Pin: `.nvmrc`), Next.js 16.4.0, React 19.3.0, TypeScript 5.9.3, Prisma 7.10.0 mit PostgreSQL-Treiberadapter, PostgreSQL 17, NextAuth 4.24.15 und Zod 4.3.6. Paketversionen sind mit `package-lock.json` fixiert. Vitest prüft Policies/Integration; Playwright prüft den Browser. Semantische HTML-Komponenten und Lucide-Icons bilden die Basis-UI.

```text
src/app/                    Next.js-Seiten und dünne API-Routen
src/components/             Basisnavigation und UI-Komponenten
src/domains/identity/        Session, Entra-Zuordnung, Rollen und Scopes
src/domains/events/          Sichtbarkeit, Lesedienste und globale Suche
src/domains/planning/        Event-, Aufgaben-, Ablauf- und Auswirkungsdienste
src/domains/reservations/    Atomare Buchungen und Delegationsmatching
src/domains/participants/    Einladungsstatus, Check-in, Export und Löschung
src/domains/notifications/   Interne Hinweise, transaktionale Outbox und Worker
src/domains/history/         Kopien, Serien, Vorlagen und Nachbereitung
src/domains/documents/       Private Ablage und Malware-Scan
src/domains/integrations/    Graph-, FM- und Storage-Abstraktionen
src/domains/locations/       Ressourcen-Lesedienst
src/domains/employees/       geschützte Mitarbeiter-/Sprachprojektionen
src/domains/administration/  Rollen- und Stammdatenpflege
src/lib/                    Datenbank, HTTP-Fehler, Seitenzugriff
prisma/                     Schema, Migrationen und Demo-Seed
src/generated/prisma/       generierter Client (ignoriert)
tools/                      Setup, Provisioning und Build-Werkzeuge
tests/                      Unit-, PostgreSQL- und Browserprüfungen
```

## Lokale Installation

Voraussetzungen: Node 24.19.0, npm, Docker mit Compose v2. Datenbankport 5432 und Webport 3000 müssen frei sein. In einer Codex-Cloud-Aufgabe den vorhandenen Checkout verwenden; kein zusätzliches Git-Worktree ist erforderlich.

```sh
cd /workspace/BeVeMS
npm_config_cache=/tmp/bevems-npm-cache npm ci
npm run setup:local
npm run dev
```

Bei einem gewöhnlichen lokalen Checkout den tatsächlichen Repositorypfad verwenden. `setup:local` erzeugt beim ersten Aufruf zufällige Zugangsdaten, startet PostgreSQL mit einem persistenten Compose-Volume, generiert den Prisma-Client, wendet Migrationen an, initialisiert Demo-Daten und vergibt eingeschränkte Datenbankrechte. Der Befehl ist wiederholbar; vorhandene Konfigurationsdateien werden nicht überschrieben. Bei unvollständiger oder abweichender Konfiguration bricht er erklärend ab. Der Dev-Server bindet ausschließlich an Loopback.

Die lokale Anmeldung bietet fünf Demo-Profile: Administrator, Veranstaltungsmanagement, Mitarbeiter, Ausbilder und Standortverantwortlicher. Das automatisch erzeugte Demo-Passwort steht in der ignorierten **`.env`**. Keine Zugangsdaten gehören in Chat, Versionsverwaltung oder Build-Artefakte. Der Demo-Provider ist nur im Entwicklungsmodus aktiv; im Produktivmodus wird eine aktivierte Demo-Konfiguration ausdrücklich abgelehnt. Auch ein zuvor ausgestelltes Demo-Sessiontoken wird produktiv nicht akzeptiert.

## Umgebungsvariablen

Zwei getrennte Dateien verhindern, dass der Webprozess privilegierte Setup-Zugangsdaten lädt:

| Datei / Kontext | Variablen |
|---|---|
| `.env` / Webprozess | `DATABASE_URL` (eingeschränkter `bevems_app`-Benutzer), `NEXTAUTH_URL`, `AUTH_SECRET`, optional `ENTRA_TENANT_ID`, `ENTRA_CLIENT_ID`, `ENTRA_CLIENT_SECRET` |
| `.env` / lokale Demo | `DEMO_AUTH_ENABLED`, `DEMO_AUTH_PASSWORD` |
| `.env.setup` / Werkzeuge | `MIGRATION_DATABASE_URL`, `POSTGRES_PASSWORD`, `RUNTIME_DATABASE_PASSWORD`, `ALLOW_DEMO_SEED`, `DEMO_DATABASE_NAME`, `TEST_DATABASE_URL`, `TEST_APP_DATABASE_URL`, optional `DEMO_SEED_DATE` |

Beispiele: [.env.example](.env.example) und [.env.setup.example](.env.setup.example). Produktiv werden Werte getrennt über den Secret Store des Betreibers injiziert; `.env.setup` darf niemals in den Webcontainer gelangen. `AUTH_SECRET` benötigt mindestens 32 Zeichen, das lokale Demo-Passwort mindestens 20; das Setup erzeugt deutlich längere Zufallswerte. OIDC benötigt alle drei Entra-Werte gemeinsam. `NEXTAUTH_URL` muss bei produktiv konfigurierter Anmeldung HTTPS verwenden.

## Datenbank, Migrationen und Seed

```sh
npm run db:validate
npm run db:generate
npm run db:migrate
npm run db:seed
npm run db:provision-runtime
```

Der Standard-Migrationsweg benutzt die **offizielle Prisma-WASM-Schemaengine** desselben Versionscommits wie Client/Prisma. Er führt gespeicherte SQL-Dateien aus und verwendet die normale `_prisma_migrations`-Historie inklusive Prüfsummen. Bereits angewendete Dateien dürfen nicht verändert werden; neue Änderungen brauchen eine neue Migration. Kein produktives `db push` oder Reset.

Die Cloud-Netzwerkpolicy blockierte den nativen Engine-/Prüfsummendownload von `binaries.prisma.sh` mit HTTP 403. Der WASM-Weg funktioniert ohne diesen Download, mit npm-Integritätsprüfung und unveränderter TLS-Prüfung. Er verwendet exakt gepinnte interne Prisma-APIs und muss bei Prisma-Upgrades erneut getestet werden. Der PostgreSQL-Migrationsadapter sendet komplette SQL-Skripte, damit Dollar-Quotes in Funktionen erhalten bleiben. Alternativ steht `npm run db:migrate:native` zur Verfügung; dafür muss die native Engine erreichbar und verifiziert sein. Dieser alternative Weg wurde in der Cloud nicht validiert.

Das Schema besitzt 62 Modelle. SQL ergänzt positive Kapazitäten, gültige Intervalle und Puffer, zusammengesetzte Referenzen innerhalb desselben Events, eindeutige globale Rollenzuweisungen und Hauptsprachen sowie ein append-only Audit-Log. Der Buchungsdienst ergänzt Transaktionslocks für Räume und Ausbilder, Puffer-/Kapazitätsprüfung und dokumentierte Übersteuerungen weicher Konflikte. Neue Migrationen ergänzen privaten Vorlagenbesitz und getrennte Kalenderfreigabe.

Der Seed ist transaktional und wiederholbar, verwendet stabile Demo-IDs und überschreibt keine bestehenden Inhalte. Er benötigt `ALLOW_DEMO_SEED=true` und einen genau passenden `DEMO_DATABASE_NAME`; unter `NODE_ENV=production` ist er gesperrt. Er erzeugt 8 Veranstaltungen, 2 fiktive Standorte, 4 Gebäude, 6 Räume, 3 Werkstätten, 7 Mitarbeiter, 5 Demo-Benutzer, verschiedene Sprachprofile, 24 Aufgaben und konfigurierbare Standardkataloge. Namen und Adressen sind ausdrücklich fiktiv. Es werden keine E-Mails versendet. Erstinitialisierung datiert Veranstaltungen relativ zum aktuellen Datum; `DEMO_SEED_DATE` setzt einen reproduzierbaren Anker. Erneutes Seeding verschiebt vorhandene Termine nicht.

`bevems_app` erhält fachliche DML-Rechte, jedoch keine DDL-Rechte und keinen Zugriff auf Migrationsmetadaten; UPDATE/DELETE/TRUNCATE am Audit-Log sind entzogen. Ein Trigger schützt Audit-Zeilen zusätzlich. Nach neuen Migrationen die Runtime-Grants bei Bedarf erneut vergeben. Reale Rollen/Mitarbeiter brauchen einen gesonderten freizugebenden Initialisierungsprozess; der Demo-Seed ist kein Produktiv-Bootstrap.

## Authentifizierung und Rollen

Entra-Anmeldung verwendet Authorization Code Flow mit PKCE, State und Nonce über NextAuth. Identitäten werden anhand **Tenant-ID und Entra-Object-ID (`oid`)** zugeordnet, niemals anhand der E-Mail-Adresse. Nur aktive, vorher zugeordnete Benutzer mit aktivem Mitarbeiterprofil dürfen sich anmelden. Keine automatische Administratorvergabe und keine offene Selbstregistrierung.

Der Standard-Fotoabruf des Azure-Providers über Microsoft Graph ist bewusst ersetzt: Die Anmeldung benötigt keine Graph-Verbindung oder Foto-/Kalenderrechte. Namen und Berechtigungen stammen aus der lokalen Datenbank.

Sessioncookies sind HttpOnly und im HTTPS-Betrieb Secure. Die JWT-Session ist verschlüsselt und läuft nach acht Stunden ab. Rollen, Kontostatus und Gruppen werden bei jeder serverseitigen Anfrage erneut geladen. ALL, LOCATION, OWN und ASSIGNED sind getrennte Geltungsbereiche. Allgemeine Leserechte umgehen keine Event-Sichtbarkeit; administrative Einsicht in sensible Events benötigt ein eigenes Recht. Sprachprofile benötigen ebenfalls ein separates Recht. APIs geben ohne Session 401, ohne Fachrecht 403 und für unsichtbare Event-IDs 404 zurück. NextAuth schützt Login/Logout mit CSRF-Prüfungen; Next.js Server Actions prüfen Origin/Host und jede fachliche Mutation prüft zusätzlich Session, Objektsichtbarkeit, Recht und Eingaben. Upload- und QR-Routen besitzen explizite Same-Origin- und Größenprüfungen.

### Entra einrichten

1. Single-Tenant-App registrieren, gewünschte Mitarbeiter/Gruppen zuweisen und MFA/Conditional Access festlegen.
2. Web-Redirect-URI `<NEXTAUTH_URL>/api/auth/callback/azure-ad` registrieren. Zunächst nur OIDC-Scopes `openid profile email`, keine Graph-Mail-/Kalenderrechte.
3. Tenant-ID, Client-ID, Clientsecret und eigene Session-Signaturkonfiguration sicher injizieren; produktiv `DEMO_AUTH_ENABLED=false`.
4. Reale Mitarbeiter und genehmigte Rollen in PostgreSQL anlegen; danach ausdrücklich zuordnen:

```sh
npm run db:provision-user -- --tenant <tenant-uuid> --subject <entra-object-uuid> --employee <employee-uuid> --role employee
# Standortrolle zusätzlich mit --location <location-uuid>
```

Das Werkzeug erhält Tenant-Konfiguration aus `.env` und Operator-Zugangsdaten aus `.env.setup`, schreibt eine Auditspur und ersetzt keine vorhandenen Identitätsbindungen. Entra-App, reale Mitarbeiterdaten und erster produktiver Administrator bleiben Betreiberaufgaben. Eine echte HWK-Anmeldung ist erst danach prüfbar.

## Tests und Entwicklungsablauf

```sh
npm run test
npm run test:integration
npm run test:e2e
npm run typecheck
npm run build
```

Integrationstests verwenden ausschließlich `bevems_phase2_test`; andere Datenbanknamen werden abgelehnt. Das lokale Setup erstellt die Datenbank, Tests migrieren und seeden sie. Produktive Daten sind keine Testfixtures. Browsertests benötigen die lokale Demo; Playwright startet bei Bedarf den Dev-Server. Vorhandenes Chromium wird erkannt, alternativ `CHROMIUM_EXECUTABLE_PATH` setzen oder Playwright-Chromium installieren. Einen laufenden Produktionsserver vor Browsertests auf Port 3000 stoppen.

Policies, echte PostgreSQL-Regeln und Sichtbarkeitsabfragen, Seed-/Migrationswiederholbarkeit, eingeschränkte DB-Rechte, Entra-Zuordnungsregeln und Browserflows einschließlich CSRF, Abmelden und mobiler Ansicht wurden geprüft. Ein OIDC-Mappingtest ersetzt keinen echten Tenant-End-to-End-Test. Aktuelle Ergebnisse und Grenzen: [phasen3-6.md](docs/phasen3-6.md).

## Build, Docker und Betrieb

`npm run build` generiert den Prisma-Client und baut ein Standalone-Paket. Das Werkzeug schaltet Demo-Authentifizierung für den Build aus und entfernt `.env`-Dateien aus dem Artefakt. Statische Assets werden kopiert; Runtime-Konfiguration wird separat injiziert. `npm start` startet den Standalone-Server und liest keine Setup-Geheimnisse.

```sh
docker build -t bevems:latest .
```

In der Cloud wird der vorhandene HTTPS-Proxy mitsamt seiner bereitgestellten CA weitergegeben. Das CA-Bundle wird nur während der Installation als BuildKit-Secret gemountet, nicht im Image gespeichert:

```sh
proxy_build_host=$(python -c 'import os,urllib.parse; print(urllib.parse.urlsplit(os.environ["HTTPS_PROXY"]).hostname)')
proxy_build_ip=$(python -c 'import os,urllib.parse,socket; print(socket.gethostbyname(urllib.parse.urlsplit(os.environ["HTTPS_PROXY"]).hostname))')
DOCKER_CONFIG=/tmp/bevems-docker-config docker build \
  --add-host "$proxy_build_host:$proxy_build_ip" \
  --build-arg HTTPS_PROXY --build-arg HTTP_PROXY --build-arg NO_PROXY \
  --secret id=trusted_ca,src="$NODE_EXTRA_CA_CERTS" -t bevems:latest .
```

Diese Variante setzt das vom Betreiber bereitgestellte `NODE_EXTRA_CA_CERTS` voraus. `proxy_build_host` und `proxy_build_ip` müssen den bereits konfigurierten Proxy abbilden: Docker übernimmt dessen lokale Namensauflösung nicht automatisch. Die Proxy-URL oder Zugangsdaten nicht ausgeben. Niemals TLS-Verifikation deaktivieren oder unbekannte Zertifikate als vertrauenswürdig übernehmen.

Der Dockerfile baut mehrstufig und startet als unprivilegierter Benutzer. Datenbank und Migrationen bleiben separate Dienste/Jobs. Für einen lokalen Container-Smoke-Test ausschließlich Runtime-Werte aus einer gesonderten Datei übergeben; `DATABASE_URL` muss auf den DB-Dienst im gemeinsamen Netzwerk zeigen. Niemals `.env.setup` übergeben. Compose stellt zunächst nur PostgreSQL für Entwicklung bereit. `docker compose --env-file .env.setup down` stoppt den Dienst; ohne `-v` bleiben Daten erhalten.

Produktiv: HTTPS-Termination, private Datenbank, getrennte Migration-/Runtime-Identitäten, starke Secrets, Entra-Konfiguration, Logging/Monitoring und geprüfte Backups. Die Anwendung besitzt CSP mit Nonces, Frame-/MIME-Schutz und datensparsame Fehlerantworten. Graph ist als explizit aktivierbarer Adapter implementiert und lokal mit Fake-Transport geprüft. FM/SharePoint sind noch nicht angeschlossen. Paket-/Imageversionen regelmäßig aktualisieren und erneut prüfen. Ein Containerbuild ist keine produktive Freigabe.

Für eine leere produktive Installation ist `npm run installation:bootstrap` mit ausdrücklich konfigurierten realen Administrator- und Standortdaten vorgesehen; Anleitung: [Ersteinrichtung ohne Demo-Daten](docs/phasen3-6.md#ersteinrichtung-ohne-demo-daten). Der Demo-Seed darf produktiv nicht ausgeführt werden.

## Datenschutz und Backup-Konzept

Rechte und Objektsichtbarkeit begrenzen Datenzugriffe. Teilnehmer und Sprachen werden nicht allgemein veröffentlicht. Fehlerprotokolle enthalten keine Secrets oder vollständigen Datenobjekte. Teilnehmerexporte werden getrennt autorisiert und auditiert; CSV-Formeln werden neutralisiert. QR-Geheimnisse sind nur gehasht gespeichert. Teilnehmer lassen sich mit ausdrücklicher Bestätigung löschen. Der Aufbewahrungsjob ist standardmäßig ein Dry-Run und benötigt eine freigegebene Frist. Dokumente bleiben vor bestandenem Scan gesperrt.

Geplant sind verschlüsselte PostgreSQL-Backups mit WAL/PITR, separate Dokumentensicherungen und regelmäßige Restore-Tests. Schlüssel werden getrennt gesichert. Rücksicherungen müssen Löschaufträge erneut anwenden. **OFFENE ENTSCHEIDUNG:** RPO/RTO, Aufbewahrungsfristen, Rechtsgrundlagen, DSFA, Betriebsrat, Hosting, FM-Datenhoheit und Graph-Rechtemodell. Das lokale Compose-Volume ist keine Sicherung; Backup-/Aufbewahrungsprozesse sind noch nicht implementiert.
