import "server-only";
import type { Tx } from "@/domains/planning/shared";
// Queueing is atomic with the business change. A separately configured worker sends externally.
export async function queueEvent(tx: Tx, eventId: string, reason: string) {
  const event = await tx.event.update({ where: { id: eventId }, data: { version: { increment: 1 } }, include: { owner: true, eventResponsibility_event: { include: { employee: true } }, eventTask_event: { include: { assignee: true } }, emailRecipient_event: true } });
  const employees = [event.owner, ...event.eventResponsibility_event.map((r) => r.employee), ...event.eventTask_event.map((t) => t.assignee)].filter((e) => e.active);
  for (const userId of new Set(employees.map((e) => e.userId).filter((id): id is string => !!id))) {
    await tx.notification.create({ data: { userId, eventId, title: event.title, body: reason } });
  }
  for (const recipient of new Set([...employees.map((e) => e.email), ...event.emailRecipient_event.map((r) => r.email)])) {
    await tx.outboxMessage.create({ data: { eventId, kind: "EVENT_CHANGED", dedupeKey: `${eventId}:${event.version}:${recipient.toLowerCase()}`, payload: { recipient, version: event.version, reason } } });
  }
  for (const invitation of await tx.calendarInvitation.findMany({ where: { eventId } })) {
    await tx.outboxMessage.create({ data: { eventId, kind: "CALENDAR_SYNC", dedupeKey: `calendar:${eventId}:${event.version}:${invitation.recipientEmail.toLowerCase()}`, payload: { recipient: invitation.recipientEmail, version: event.version, reason } } });
  }
}
