import "server-only";
import { Client } from "pg";
import { z } from "zod";
import { db } from "@/lib/db";
import type { CommunicationAdapter } from "@/domains/integrations/graph";
import { GraphError } from "@/domains/integrations/graph";
import type { Prisma } from "@/generated/prisma/client";
// One worker globally serializes delivery. Locks live on the transaction's connection, never on a pooled session.
// SMTP/Graph mail has no universal exactly-once key: unknown outcomes require operator review, not blind retries.
async function deliverBatch(adapter: CommunicationAdapter, baseUrl: string, limit = 20) {
  const url = new URL(baseUrl); if (url.protocol !== "https:" && process.env.NODE_ENV === "production") throw new Error("HTTPS URL required");
  let processed = 0;
  for (let index = 0; index < Math.min(limit, 100); index++) {
    const claimed = await db.$transaction(async (tx) => {
      await tx.$queryRaw`SELECT pg_advisory_xact_lock(hashtextextended('outbox:claim', 0))::text`;
      // Interrupted processing is ambiguous and is never auto-resubmitted as a potentially duplicate mail.
      await tx.outboxMessage.updateMany({ where: { state: "PROCESSING", lockedUntil: { lt: new Date() } }, data: { state: "FAILED", lastErrorCode: "DELIVERY_OUTCOME_UNKNOWN" } });
      const row = await tx.outboxMessage.findFirst({ where: { state: "PENDING", nextAttemptAt: { lte: new Date() } }, orderBy: { createdAt: "asc" } });
      if (!row) return null;
      return tx.outboxMessage.update({ where: { id: row.id }, data: { state: "PROCESSING", attempts: { increment: 1 }, lockedUntil: new Date(Date.now() + 300000) } });
    });
    if (!claimed) break;
    try {
      const input = z.object({ recipient: z.email(), version: z.number().int(), reason: z.string() }).parse(claimed.payload);
      if (!claimed.eventId || !["EVENT_CHANGED", "CALENDAR_SYNC"].includes(claimed.kind)) throw new Error("UNSUPPORTED_MESSAGE");
      const event = await db.event.findUniqueOrThrow({ where: { id: claimed.eventId }, include: { status: true, owner: true, eventResponsibility_event: { include: { employee: true } }, eventTask_event: { include: { assignee: true } }, emailRecipient_event: true, eventLocation_event: { include: { location: true } } } });
      const validRecipients = new Set([event.owner.email, ...event.eventResponsibility_event.filter((r) => r.employee.active).map((r) => r.employee.email), ...event.eventTask_event.filter((t) => t.assignee.active).map((t) => t.assignee.email), ...event.emailRecipient_event.map((r) => r.email)].map((e) => e.toLowerCase()));
      if (claimed.kind === "EVENT_CHANGED" && (!validRecipients.has(input.recipient.toLowerCase()) || !event.owner.active)) {
        await db.outboxMessage.update({ where: { id: claimed.id }, data: { state: "FAILED", lastErrorCode: "RECIPIENT_REMOVED", lockedUntil: null } }); continue;
      }
      // Only current content is sent; no sensitive description or participant list leaves the app.
      const location = event.eventLocation_event.map((l) => l.location.name).join(", ");
      const body = `${input.reason}\n${event.start.toISOString()} – ${event.end.toISOString()}\n${location}\n${new URL(`/events/${event.id}`, url).href}\nIhre Beteiligung: Veranstaltungsorganisation`;
      if (claimed.kind === "EVENT_CHANGED") await adapter.sendMail(input.recipient, event.title, body);
      const invitation = await db.calendarInvitation.findUnique({ where: { eventId_recipientEmail: { eventId: event.id, recipientEmail: input.recipient } } });
      if (claimed.kind === "CALENDAR_SYNC" && invitation && invitation.syncedVersion < event.version) {
        const result = await adapter.syncCalendar({ eventId: event.id, recipient: input.recipient, subject: event.title, body, start: event.start.toISOString(), end: event.end.toISOString(), cancelled: event.status.code === "CANCELLED" || !invitation.enabled || !validRecipients.has(input.recipient.toLowerCase()), externalId: invitation.externalId, transactionId: `${invitation.id}:${event.version}` });
        await db.calendarInvitation.update({ where: { id: invitation.id }, data: { externalId: result.externalId, syncedVersion: event.version, state: "SENT" } });
      }
      await db.$transaction(async (tx) => {
        await tx.outboxMessage.update({ where: { id: claimed.id }, data: { state: "SENT", lockedUntil: null, lastErrorCode: null } });
        await tx.auditLog.create({ data: { eventId: event.id, action: "communication.delivered", entityType: "OutboxMessage", entityId: claimed.id, changes: { kind: claimed.kind } } });
      }); processed++;
    } catch (error) {
      const code = error instanceof GraphError ? error.code : "DELIVERY_OUTCOME_UNKNOWN";
      // Throttling rejection is safe to retry. Transport failures and mixed mail/calendar outcomes need review.
      const retry = code === "GRAPH_429" && claimed.attempts < 5;
      await db.outboxMessage.update({ where: { id: claimed.id }, data: { state: retry ? "PENDING" : "FAILED", lockedUntil: null, lastErrorCode: code, nextAttemptAt: new Date(Date.now() + (error instanceof GraphError ? error.retryAfter : 60) * 1000) } });
    }
  }
  return processed;
}

export async function processOutbox(adapter: CommunicationAdapter, baseUrl: string, limit = 20) {
  const lease = new Client({ connectionString: process.env.DATABASE_URL });
  await lease.connect();
  try {
    const lock = await lease.query<{ locked: boolean }>("SELECT pg_try_advisory_lock(hashtextextended('bevems:delivery-worker', 0)) AS locked");
    if (!lock.rows[0].locked) return 0;
    try { return await deliverBatch(adapter, baseUrl, limit); }
    finally { await lease.query("SELECT pg_advisory_unlock(hashtextextended('bevems:delivery-worker', 0))"); }
  } finally { await lease.end(); }
}
