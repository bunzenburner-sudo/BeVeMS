import "server-only";
import { z } from "zod";
import { db } from "@/lib/db";
import type { Actor } from "@/domains/identity/policy";
import { audit, eventMutation, uuid } from "@/domains/planning/shared";
import { visibleEventsWhere } from "@/domains/events/policy";
import { queueEvent } from "./queue";
export async function updateCommunication(actor: Actor, eventId: string, raw: unknown) {
  const data = z.object({ recipients: z.string().max(10000), calendar: z.boolean() }).parse(raw);
  const emails = [...new Set(data.recipients.split(/[;,\n]/).map((s) => s.trim().toLowerCase()).filter(Boolean))]; z.array(z.email().max(254)).max(100).parse(emails);
  return eventMutation(actor, eventId, "event.edit", async (tx) => {
    await tx.emailRecipient.deleteMany({ where: { eventId } }); await tx.emailRecipient.createMany({ data: emails.map((email) => ({ eventId, email })) });
    await tx.calendarInvitation.updateMany({ where: { eventId }, data: { enabled: false, state: "PENDING" } });
    if (data.calendar) {
      const event = await tx.event.findUniqueOrThrow({ where: { id: eventId }, include: { owner: true, eventResponsibility_event: { include: { employee: true } } } });
      const calendarEmails = new Set([...emails, event.owner.email, ...event.eventResponsibility_event.map((r) => r.employee.email)]);
      for (const recipientEmail of calendarEmails) await tx.calendarInvitation.upsert({ where: { eventId_recipientEmail: { eventId, recipientEmail } }, create: { eventId, recipientEmail }, update: { enabled: true, state: "PENDING" } });
    }
    await audit(tx, actor, eventId, "communication.updated", "Event", eventId, { recipientCount: emails.length, calendar: data.calendar }); await queueEvent(tx, eventId, "Kommunikation aktualisiert.");
  });
}
export async function notifications(actor: Actor) {
  return db.notification.findMany({ where: { userId: actor.id, OR: [{ eventId: null }, { event: visibleEventsWhere(actor) }] }, orderBy: { createdAt: "desc" }, take: 100 });
}
export async function markRead(actor: Actor, id: string) { uuid.parse(id); await db.notification.updateMany({ where: { id, userId: actor.id }, data: { readAt: new Date() } }); }
export async function retryDelivery(actor: Actor, id: string, confirmed: boolean) {
  const { requireRight, DomainError } = await import("@/domains/planning/shared");
  requireRight(actor, "administration.manage"); uuid.parse(id);
  return db.$transaction(async (tx) => {
    const message = await tx.outboxMessage.findUnique({ where: { id } });
    if (!message || message.state !== "FAILED") throw new DomainError("Nur fehlgeschlagene Aufträge können erneut eingeplant werden.");
    if (message.lastErrorCode === "DELIVERY_OUTCOME_UNKNOWN" && !confirmed) throw new DomainError("Unklarer Versandstatus: zuerst im Postfach prüfen und die mögliche Doppelzustellung ausdrücklich bestätigen.");
    await tx.outboxMessage.update({ where: { id }, data: { state: "PENDING", nextAttemptAt: new Date(), lockedUntil: null, attempts: 0, lastErrorCode: null } });
    await audit(tx, actor, message.eventId, "communication.retry_requested", "OutboxMessage", id);
  });
}
