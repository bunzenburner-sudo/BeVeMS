import "server-only";
import { z } from "zod";
import { db } from "@/lib/db";
import { visibleEventsWhere } from "@/domains/events/policy";
import type { Actor } from "@/domains/identity/policy";
import { audit, notes, requireRight, text, uuid } from "@/domains/planning/shared";
export async function manageOrganisation(actor: Actor, raw: unknown) {
  requireRight(actor, "event.create");
  const { id, ...data } = z.object({ id: z.union([uuid, z.literal("")]), name: text, type: text, country: notes, address: notes, website: z.union([z.url().refine((v) => ["https:", "http:"].includes(new URL(v).protocol)), z.literal("")]) }).parse(raw);
  return db.$transaction(async (tx) => { const o = id ? await tx.organisation.update({ where: { id }, data }) : await tx.organisation.create({ data }); await audit(tx, actor, null, "organisation.saved", "Organisation", o.id); });
}
export async function organisations(actor: Actor, search = "") {
  requireRight(actor, "participant.view");
  const q = z.string().max(120).parse(search);
  return db.organisation.findMany({ where: { active: true, name: { contains: q, mode: "insensitive" } }, include: { externalContact_organisation: true, eventOrganisation_organisation: { where: { event: visibleEventsWhere(actor) }, select: { event: { select: { id: true, title: true, start: true } } } } }, orderBy: { name: "asc" }, take: 100 });
}
export async function addContact(actor: Actor, raw: unknown) {
  requireRight(actor, "event.create");
  const input = z.object({ organisationId: uuid, firstName: text, lastName: text, email: z.union([z.email(), z.literal("")]), function: notes, phone: z.string().max(100) }).parse(raw);
  return db.$transaction(async (tx) => { const c = await tx.externalContact.create({ data: { ...input, email: input.email || null } }); await audit(tx, actor, null, "contact.created", "ExternalContact", c.id); });
}
