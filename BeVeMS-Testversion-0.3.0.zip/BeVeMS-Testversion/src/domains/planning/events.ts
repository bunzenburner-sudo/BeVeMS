import "server-only";
import { z } from "zod";
import { db } from "@/lib/db";
import { permitted, hasPermission, AccessError, type Actor } from "@/domains/identity/policy";
import { visibleEventsWhere } from "@/domains/events/policy";
import { audit, DomainError, eventMutation, instant, notes, requireRight, text, timeRange, uuid } from "./shared";
import { queueEvent } from "@/domains/notifications/queue";
export const eventInput = z.object({
  title: text, description: notes, typeId: uuid, structure: z.enum(["INTERNAL", "EXTERNAL", "MIXED"]),
  start: instant, end: instant, ownerId: uuid, locationId: uuid, participantCount: z.coerce.number().int().min(0).max(100000),
  country: z.string().trim().max(100).default(""), visibility: z.enum(["INVOLVED", "ALL_EMPLOYEES", "LOCATIONS", "UNITS", "GROUPS"]).default("INVOLVED"),
  audienceIds: z.array(uuid).max(100).default([]), languageId: z.union([uuid, z.literal("")]).default(""), tradeIds: z.array(uuid).max(50).default([]),
  initialTask: z.string().trim().max(300).default(""), initialImpact: z.string().trim().max(300).default(""), initialRecipients: z.string().max(10000).default(""),
});
async function checkReferences(input: z.infer<typeof eventInput>) {
  timeRange(input.start, input.end);
  const [owner, type, location] = await Promise.all([db.employee.findFirst({ where: { id: input.ownerId, active: true, location: { active: true }, unit: { active: true } } }), db.eventType.findFirst({ where: { id: input.typeId, active: true } }), db.location.findFirst({ where: { id: input.locationId, active: true } })]);
  if (!owner || !type || !location) throw new DomainError("Verantwortliche, Typ und Standort müssen aktiv sein.");
  if (input.languageId && !await db.language.count({ where: { id: input.languageId, active: true } })) throw new DomainError("Sprache ist nicht aktiv.");
  if (await db.trade.count({ where: { id: { in: input.tradeIds }, active: true } }) !== new Set(input.tradeIds).size) throw new DomainError("Gewerk ist nicht aktiv.");
  if (["UNITS", "GROUPS"].includes(input.visibility) && !input.audienceIds.length) throw new DomainError("Bitte die Zielgruppe auswählen.");
}
export async function planningOptions(actor: Actor) {
  if (!hasPermission(actor, "event.create") && !hasPermission(actor, "event.edit")) throw new AccessError(403);
  const [types, employees, locations, languages, trades, units, groups] = await Promise.all([
    db.eventType.findMany({ where: { active: true }, orderBy: { name: "asc" } }),
    db.employee.findMany({ where: { active: true }, select: { id: true, firstName: true, lastName: true, locationId: true }, orderBy: { lastName: "asc" } }),
    db.location.findMany({ where: { active: true }, orderBy: { name: "asc" } }), db.language.findMany({ where: { active: true } }), db.trade.findMany({ where: { active: true } }), db.organisationUnit.findMany({ where: { active: true } }), db.userGroup.findMany({ where: { active: true } }),
  ]);
  return { types, employees, locations, languages, trades, units, groups };
}
export async function createEvent(actor: Actor, raw: unknown) {
  const input = eventInput.parse(raw); requireRight(actor, "event.create", { ownerId: input.ownerId, locationIds: [input.locationId] });
  // A scoped creator cannot assign ownership away and thereby escape their own accessible scope.
  if (!permitted(actor, "event.edit", { ownerId: input.ownerId, locationIds: [input.locationId] })) throw new AccessError(403);
  await checkReferences(input);
  return db.$transaction(async (tx) => {
    const draft = await tx.eventStatus.findFirst({ where: { code: "DRAFT", active: true } });
    if (!draft) throw new DomainError("Status Entwurf ist nicht konfiguriert.");
    const { locationId, audienceIds, languageId, tradeIds, initialTask, initialImpact, initialRecipients, ...data } = input;
    const event = await tx.event.create({ data: { ...data, statusId: draft.id, eventLocation_event: { create: { locationId } },
      eventInvolvement_event: { create: { employeeId: actor.employeeId } },
      eventVisibilityLocation_event: input.visibility === "LOCATIONS" ? { create: { locationId } } : undefined,
      eventVisibilityUnit_event: input.visibility === "UNITS" ? { create: audienceIds.map((unitId) => ({ unitId })) } : undefined,
      eventVisibilityGroup_event: input.visibility === "GROUPS" ? { create: audienceIds.map((groupId) => ({ groupId })) } : undefined,
      eventLanguage_event: languageId ? { create: { languageId, primary: true } } : undefined,
      eventTrade_event: { create: [...new Set(tradeIds)].map((tradeId) => ({ tradeId })) },
    } });
    if (initialTask) await tx.eventTask.create({ data: { eventId: event.id, title: initialTask, assigneeId: input.ownerId } });
    if (initialImpact) await tx.eventImpact.create({ data: { eventId: event.id, description: initialImpact, publicSummary: initialImpact, start: input.start, end: input.end } });
    const emails = [...new Set(initialRecipients.split(/[;,\n]/).map((s) => s.trim().toLowerCase()).filter(Boolean))];
    z.array(z.email()).max(100).parse(emails); await tx.emailRecipient.createMany({ data: emails.map((email) => ({ eventId: event.id, email })) });
    await audit(tx, actor, event.id, "event.created", "Event", event.id, { title: event.title });
    await queueEvent(tx, event.id, "Veranstaltung angelegt; Verantwortlichkeiten bitte prüfen."); return event.id;
  });
}
export async function updateEvent(actor: Actor, id: string, raw: unknown, version: number) {
  const input = eventInput.parse(raw); await checkReferences(input);
  requireRight(actor, "event.edit", { ownerId: input.ownerId, locationIds: [input.locationId] });
  return eventMutation(actor, id, "event.edit", async (tx, event) => {
    if (event.version !== version) throw new DomainError("Die Veranstaltung wurde inzwischen geändert. Bitte neu laden.");
    if (["CANCELLED", "COMPLETED"].includes(event.status.code)) throw new DomainError("Abgeschlossene oder abgesagte Veranstaltungen können nicht umgeplant werden.");
    const changedTime = +event.start !== +input.start || +event.end !== +input.end;
    if (changedTime && (await tx.reservation.count({ where: { eventId: id, status: { in: ["TENTATIVE", "CONFIRMED"] } } }) || await tx.eventScheduleItem.count({ where: { eventId: id } }))) throw new DomainError("Vor einer Terminänderung aktive Reservierungen stornieren und Ablaufpunkte entfernen.");
    const { locationId, audienceIds, languageId, tradeIds, initialTask, initialImpact, initialRecipients, ...data } = input;
    if (await tx.reservation.count({ where: { eventId: id, status: { in: ["TENTATIVE", "CONFIRMED"] }, room: { building: { locationId: { not: locationId } } } } })) throw new DomainError("Der Standort passt nicht zu den aktiven Reservierungen.");
    await tx.event.update({ where: { id }, data });
    await tx.eventLocation.deleteMany({ where: { eventId: id } }); await tx.eventLocation.create({ data: { eventId: id, locationId } });
    await tx.eventVisibilityLocation.deleteMany({ where: { eventId: id } }); await tx.eventVisibilityUnit.deleteMany({ where: { eventId: id } }); await tx.eventVisibilityGroup.deleteMany({ where: { eventId: id } });
    if (input.visibility === "LOCATIONS") await tx.eventVisibilityLocation.create({ data: { eventId: id, locationId } });
    if (input.visibility === "UNITS") await tx.eventVisibilityUnit.createMany({ data: [...new Set(audienceIds)].map((unitId) => ({ eventId: id, unitId })) });
    if (input.visibility === "GROUPS") await tx.eventVisibilityGroup.createMany({ data: [...new Set(audienceIds)].map((groupId) => ({ eventId: id, groupId })) });
    await tx.eventLanguage.deleteMany({ where: { eventId: id } }); if (languageId) await tx.eventLanguage.create({ data: { eventId: id, languageId, primary: true } });
    await tx.eventTrade.deleteMany({ where: { eventId: id } }); await tx.eventTrade.createMany({ data: [...new Set(tradeIds)].map((tradeId) => ({ eventId: id, tradeId })) });
    await audit(tx, actor, id, "event.updated", "Event", id, { title: { from: event.title, to: input.title }, start: input.start.toISOString(), end: input.end.toISOString(), visibility: input.visibility });
    await queueEvent(tx, id, "Veranstaltungsdaten geändert.");
  });
}
export async function changeStatus(actor: Actor, id: string, targetId: string) {
  uuid.parse(targetId);
  return eventMutation(actor, id, undefined, async (tx, event) => {
    const target = await tx.eventStatus.findFirst({ where: { id: targetId, active: true } }); if (!target) throw new DomainError("Status nicht verfügbar.");
    if (["COMPLETED", "CANCELLED"].includes(event.status.code)) throw new DomainError("Dieser Vorgang ist bereits abgeschlossen.");
    if (target.code === "CANCELLED") requireRight(actor, "event.cancel", { ownerId: event.ownerId, locationIds: event.eventLocation_event.map((l) => l.locationId) });
    else {
      const transition = await tx.eventStatusTransition.findUnique({ where: { fromId_toId: { fromId: event.statusId, toId: targetId } }, include: { permission: true } });
      if (!transition) throw new DomainError("Dieser Statusübergang ist nicht erlaubt.");
      requireRight(actor, transition.permission.code, { ownerId: event.ownerId, locationIds: event.eventLocation_event.map((l) => l.locationId) });
    }
    if (["CONFIRMED", "READY"].includes(target.code) && !await tx.event.count({ where: { id, type: { active: true }, owner: { active: true, location: { active: true }, unit: { active: true } }, eventLocation_event: { every: { location: { active: true } } } } })) throw new DomainError("Veranstaltungstyp, verantwortliche Person oder Standort ist nicht aktiv.");
    if (["CONFIRMED", "READY"].includes(target.code) && event.reviewRequired) throw new DomainError("Kopie oder Vorlage muss vor der Bestätigung ausdrücklich geprüft werden.");
    if (target.code === "READY") {
      if (await tx.eventTask.count({ where: { eventId: id, critical: true, status: { not: "DONE" } } }) || await tx.reservation.count({ where: { eventId: id, status: "TENTATIVE", OR: [{ expiresAt: null }, { expiresAt: { gt: new Date() } }] } })) throw new DomainError("Kritische Aufgaben oder unbestätigte Reservierungen sind noch offen.");
      if (!await tx.reservation.count({ where: { eventId: id, status: "CONFIRMED" } })) throw new DomainError("Bitte die benötigten Ressourcen zuerst bestätigen.");
    }
    if (target.code === "CANCELLED") await tx.reservation.updateMany({ where: { eventId: id, status: { in: ["TENTATIVE", "CONFIRMED"] } }, data: { status: "CANCELLED" } });
    await tx.event.update({ where: { id }, data: { statusId: target.id } });
    await audit(tx, actor, id, "event.status", "Event", id, { from: event.status.code, to: target.code }); await queueEvent(tx, id, `Status geändert: ${target.name}`);
  });
}
export async function planningDetail(actor: Actor, id: string) {
  uuid.parse(id);
  const event = await db.event.findFirst({ where: { AND: [{ id }, visibleEventsWhere(actor)] }, include: { status: true, type: true, owner: { select: { firstName: true, lastName: true } }, eventLocation_event: { include: { location: true } }, eventLanguage_event: true, eventTrade_event: true, eventVisibilityGroup_event: true, eventVisibilityUnit_event: true } });
  if (!event) throw new AccessError(404);
  const context = { ownerId: event.ownerId, locationIds: event.eventLocation_event.map((l) => l.locationId) };
  const canEdit = permitted(actor, "event.edit", context);
  const [tasks, impacts, schedule, reservations, statuses] = await Promise.all([
    db.eventTask.findMany({ where: { eventId: id, ...(canEdit ? {} : { assigneeId: actor.employeeId }) }, include: { assignee: { select: { firstName: true, lastName: true } } }, orderBy: [{ status: "asc" }, { dueAt: "asc" }] }),
    db.eventImpact.findMany({ where: { eventId: id, OR: [{ impactAudience_impact: { none: {} } }, { impactAudience_impact: { some: { groupId: { in: actor.groups } } } }] }, select: { id: true, publicSummary: true, start: true, end: true, category: { select: { name: true } }, ...(canEdit ? { description: true } : {}) }, orderBy: { start: "asc" } }),
    db.eventScheduleItem.findMany({ where: { eventId: id }, select: { id: true, title: true, description: true, start: true, end: true, sortOrder: true, room: { select: { name: true } }, responsible: { select: { firstName: true, lastName: true } }, ...(canEdit ? { internalNotes: true } : {}) }, orderBy: { sortOrder: "asc" } }),
    canEdit || permitted(actor, "room.reserve", context) ? db.reservation.findMany({ where: { eventId: id }, include: { room: { select: { name: true } } }, orderBy: { start: "asc" } }) : [],
    db.eventStatus.findMany({ where: { active: true } }),
  ]);
  const counts = await db.eventTask.groupBy({ by: ["status"], where: { eventId: id }, _count: true });
  const total = counts.reduce((n, r) => n + r._count, 0), done = counts.find((r) => r.status === "DONE")?._count ?? 0;
  return { event, context, canEdit, tasks, impacts, schedule, reservations, statuses, progress: total ? Math.round(done / total * 100) : null };
}
export async function acknowledgeReview(actor: Actor, id: string, confirmed: boolean) {
  if (!confirmed) throw new DomainError("Bitte Termine, Personen und Ressourcen ausdrücklich prüfen und bestätigen.");
  return eventMutation(actor, id, "event.edit", async (tx) => {
    await tx.event.update({ where: { id }, data: { reviewRequired: false } });
    await audit(tx, actor, id, "event.reviewed", "Event", id);
  });
}
