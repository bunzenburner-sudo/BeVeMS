import "server-only";
import { z } from "zod";
import { audit, DomainError, eventMutation, instant, notes, requireRight, text, timeRange, uuid } from "./shared";
import type { Actor } from "@/domains/identity/policy";
import { queueEvent } from "@/domains/notifications/queue";
function assertOpen(event: { status: { code: string } }) { if (["COMPLETED", "CANCELLED"].includes(event.status.code)) throw new DomainError("Die Planung dieser Veranstaltung ist abgeschlossen."); }
export async function addTask(actor: Actor, eventId: string, raw: unknown) {
  const input = z.object({ title: text, description: notes, assigneeId: uuid, dueAt: z.union([instant, z.literal("")]).optional(), critical: z.boolean().default(false) }).parse(raw);
  return eventMutation(actor, eventId, "event.edit", async (tx, event) => {
    assertOpen(event);
    if (!await tx.employee.count({ where: { id: input.assigneeId, active: true } })) throw new DomainError("Verantwortliche Person ist nicht aktiv.");
    if (input.critical && event.status.code === "READY") throw new DomainError("Neue kritische Aufgaben dürfen im Status Bereit nicht ungeklärt angelegt werden.");
    const task = await tx.eventTask.create({ data: { ...input, dueAt: input.dueAt || null, eventId } });
    await audit(tx, actor, eventId, "task.created", "EventTask", task.id, { title: input.title, assigneeId: input.assigneeId }); await queueEvent(tx, eventId, "Eine Aufgabe wurde zugewiesen.");
  });
}
export async function setTaskStatus(actor: Actor, eventId: string, taskId: string, status: string) {
  uuid.parse(taskId); const target = z.enum(["OPEN", "IN_PROGRESS", "DONE"]).parse(status);
  return eventMutation(actor, eventId, undefined, async (tx, event) => {
    assertOpen(event);
    const task = await tx.eventTask.findFirst({ where: { id: taskId, eventId } }); if (!task) throw new DomainError("Aufgabe nicht gefunden.");
    requireRight(actor, "task.edit", { ownerId: event.ownerId, assignedEmployeeId: task.assigneeId, locationIds: event.eventLocation_event.map((l) => l.locationId) });
    if (task.critical && target !== "DONE" && event.status.code === "READY") throw new DomainError("Kritische Aufgaben dürfen im Status Bereit nicht wieder geöffnet werden.");
    await tx.eventTask.update({ where: { id: taskId }, data: { status: target } });
    await audit(tx, actor, eventId, "task.status", "EventTask", taskId, { from: task.status, to: target }); await queueEvent(tx, eventId, "Aufgabenstatus geändert.");
  });
}
export async function addImpact(actor: Actor, eventId: string, raw: unknown) {
  const input = z.object({ description: notes.pipe(z.string().min(1)), publicSummary: text, categoryId: z.union([uuid, z.literal("")]), start: instant, end: instant, groupIds: z.array(uuid).max(100).default([]) }).parse(raw);
  timeRange(input.start, input.end);
  return eventMutation(actor, eventId, "event.edit", async (tx, event) => {
    assertOpen(event);
    const { groupIds, categoryId, ...data } = input;
    const impact = await tx.eventImpact.create({ data: { ...data, eventId, categoryId: categoryId || null, impactAudience_impact: { create: [...new Set(groupIds)].map((groupId) => ({ groupId })) } } });
    await audit(tx, actor, eventId, "impact.created", "EventImpact", impact.id); await queueEvent(tx, eventId, "Betrieblicher Hinweis ergänzt.");
  });
}
export async function addResponsibility(actor: Actor, eventId: string, employeeId: string, areaId: string) {
  uuid.parse(employeeId); uuid.parse(areaId);
  return eventMutation(actor, eventId, "event.edit", async (tx, event) => {
    assertOpen(event);
    if (!await tx.employee.count({ where: { id: employeeId, active: true } }) || !await tx.responsibilityArea.count({ where: { id: areaId, active: true } })) throw new DomainError("Person oder Bereich ist nicht aktiv.");
    const r = await tx.eventResponsibility.upsert({ where: { eventId_employeeId_areaId: { eventId, employeeId, areaId } }, create: { eventId, employeeId, areaId }, update: {} });
    await audit(tx, actor, eventId, "responsibility.assigned", "EventResponsibility", r.id, { employeeId, areaId }); await queueEvent(tx, eventId, "Teilverantwortung zugewiesen.");
  });
}
export async function addSchedule(actor: Actor, eventId: string, raw: unknown) {
  const input = z.object({ title: text, description: notes, internalNotes: notes, start: instant, end: instant, responsibleId: z.union([uuid, z.literal("")]), roomId: z.union([uuid, z.literal("")]) }).parse(raw);
  timeRange(input.start, input.end);
  return eventMutation(actor, eventId, "event.edit", async (tx, event) => {
    assertOpen(event);
    if (input.start < event.start || input.end > event.end) throw new DomainError("Ablaufpunkt muss innerhalb der Veranstaltung liegen.");
    const room = input.roomId ? await tx.room.findFirst({ where: { id: input.roomId, active: true }, include: { building: true, workshop_room: true } }) : null;
    if (input.roomId && (!room || !event.eventLocation_event.some((l) => l.locationId === room.building.locationId))) throw new DomainError("Raum gehört nicht zum Veranstaltungsstandort.");
    const { roomId, responsibleId, ...data } = input;
    const item = await tx.eventScheduleItem.create({ data: { ...data, eventId, sortOrder: await tx.eventScheduleItem.count({ where: { eventId } }), roomId: roomId || null, responsibleId: responsibleId || null, buildingId: room?.buildingId, locationId: room?.building.locationId, workshopId: room?.workshop_room?.id } });
    await audit(tx, actor, eventId, "schedule.created", "EventScheduleItem", item.id); await queueEvent(tx, eventId, "Ablaufplan ergänzt.");
  });
}
export async function reorderSchedule(actor: Actor, eventId: string, ids: string[]) {
  z.array(uuid).max(500).parse(ids);
  return eventMutation(actor, eventId, "event.edit", async (tx, event) => {
    assertOpen(event);
    const existing = await tx.eventScheduleItem.findMany({ where: { eventId }, select: { id: true } });
    if (new Set(ids).size !== ids.length || existing.length !== ids.length || existing.some((e) => !ids.includes(e.id))) throw new DomainError("Ablauf wurde inzwischen geändert. Bitte neu laden.");
    for (const [sortOrder, id] of ids.entries()) await tx.eventScheduleItem.update({ where: { id }, data: { sortOrder } });
    await audit(tx, actor, eventId, "schedule.reordered", "Event", eventId, { ids }); await queueEvent(tx, eventId, "Reihenfolge des Ablaufs geändert.");
  });
}
export async function removePlanningItem(actor: Actor, eventId: string, kind: string, id: string) {
  uuid.parse(id);
  return eventMutation(actor, eventId, "event.edit", async (tx, event) => {
    assertOpen(event);
    let count = 0;
    if (kind === "task") count = (await tx.eventTask.deleteMany({ where: { id, eventId } })).count;
    else if (kind === "impact") { await tx.impactAudience.deleteMany({ where: { impactId: id, impact: { eventId } } }); count = (await tx.eventImpact.deleteMany({ where: { id, eventId } })).count; }
    else if (kind === "schedule") count = (await tx.eventScheduleItem.deleteMany({ where: { id, eventId } })).count;
    else throw new DomainError("Unbekanntes Element.");
    if (count !== 1) throw new DomainError("Element nicht gefunden.");
    await audit(tx, actor, eventId, `${kind}.removed`, kind, id); await queueEvent(tx, eventId, "Planung aktualisiert.");
  });
}
