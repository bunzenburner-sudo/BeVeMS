import "server-only";
import { db } from "@/lib/db";
import { involvementWhere, visibleEventsWhere } from "@/domains/events/policy";
import { permitted, type Actor } from "@/domains/identity/policy";
import { berlinInput, berlinToIso } from "@/lib/dates";
export async function dashboard(actor: Actor) {
  const day = berlinInput(new Date()).slice(0, 10), start = new Date(berlinToIso(`${day}T00:00`)), end = new Date(+start + 8 * 86400000);
  const visible = visibleEventsWhere(actor);
  const [impacts, relevant, tasks, organizing] = await Promise.all([
    db.eventImpact.findMany({ where: { start: { lt: end }, end: { gt: start }, event: { AND: [visible], status: { code: { not: "CANCELLED" } } }, OR: [{ impactAudience_impact: { none: {} } }, { impactAudience_impact: { some: { groupId: { in: actor.groups } } } }] }, select: { id: true, publicSummary: true, start: true, end: true, category: { select: { name: true } }, event: { select: { id: true, title: true } } }, orderBy: { start: "asc" }, take: 30 }),
    db.event.findMany({ where: { AND: [visible, involvementWhere(actor)], end: { gte: new Date() }, status: { code: { not: "CANCELLED" } } }, select: { id: true, title: true }, orderBy: { start: "asc" }, take: 10 }),
    db.eventTask.findMany({ where: { assigneeId: actor.employeeId, status: { not: "DONE" }, event: visible }, select: { id: true, title: true, dueAt: true, critical: true, eventId: true }, orderBy: { dueAt: "asc" }, take: 30 }),
    db.event.findMany({ where: { AND: [visible], end: { gte: new Date() }, status: { code: { notIn: ["CANCELLED", "COMPLETED"] } } }, select: { id: true, title: true, ownerId: true, eventLocation_event: true, eventTask_event: { select: { status: true, dueAt: true, critical: true } }, reservation_event: { where: { status: "TENTATIVE", expiresAt: { gt: new Date() } }, select: { id: true } } }, take: 100 }),
  ]);
  return { day, impacts, relevant, tasks, organizing: organizing.filter((e) => permitted(actor, "event.edit", { ownerId: e.ownerId, locationIds: e.eventLocation_event.map((l) => l.locationId) })) };
}
