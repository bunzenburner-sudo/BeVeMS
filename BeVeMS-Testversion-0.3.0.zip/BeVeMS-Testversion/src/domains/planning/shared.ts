import "server-only";
import { z } from "zod";
import type { Prisma } from "@/generated/prisma/client";
import { db } from "@/lib/db";
import { AccessError, permitted, type Actor } from "@/domains/identity/policy";
import { visibleEventsWhere } from "@/domains/events/policy";
export type Tx = Prisma.TransactionClient;
export class DomainError extends Error {}
export const uuid = z.uuid();
export const text = z.string().trim().min(1).max(300);
export const notes = z.string().trim().max(5000).default("");
export const instant = z.iso.datetime({ offset: true }).transform((v) => new Date(v));
export function requireRight(actor: Actor, permission: string, context = {}) {
  if (!permitted(actor, permission, context)) throw new AccessError(403);
}
export async function lockedEvent(tx: Tx, actor: Actor, id: string, permission?: string) {
  uuid.parse(id);
  await tx.$queryRaw`SELECT id FROM "Event" WHERE id = ${id}::uuid FOR UPDATE`;
  const event = await tx.event.findFirst({ where: { AND: [{ id }, visibleEventsWhere(actor)] }, include: { status: true, eventLocation_event: true } });
  if (!event) throw new AccessError(404);
  if (permission) requireRight(actor, permission, { ownerId: event.ownerId, locationIds: event.eventLocation_event.map((l) => l.locationId) });
  return event;
}
export async function audit(tx: Tx, actor: Actor, eventId: string | null, action: string, entityType: string, entityId: string, changes: Prisma.InputJsonValue = {}) {
  await tx.auditLog.create({ data: { actorId: actor.id, eventId, action, entityType, entityId, changes } });
}
export async function eventMutation<T>(actor: Actor, id: string, permission: string | undefined, fn: (tx: Tx, event: Awaited<ReturnType<typeof lockedEvent>>) => Promise<T>) {
  return db.$transaction(async (tx) => fn(tx, await lockedEvent(tx, actor, id, permission)), { timeout: 15000 });
}
export function timeRange(start: Date, end: Date) {
  if (end <= start || end.getTime() - start.getTime() > 366 * 86400000) throw new DomainError("Bitte einen gültigen Zeitraum von höchstens einem Jahr wählen.");
}
