import "server-only";
import { z } from "zod";
import { db } from "@/lib/db";
import { visibleEventsWhere } from "@/domains/events/policy";
import type { Actor } from "@/domains/identity/policy";
import { audit, DomainError, eventMutation, instant, notes, requireRight, text, uuid, type Tx } from "@/domains/planning/shared";
export async function saveLessons(actor: Actor, eventId: string, raw: unknown) {
  const data = z.object({ wentWell: notes, wentBadly: notes, nextTime: notes, incidents: notes, improvements: notes, actualParticipants: z.coerce.number().int().min(0).max(100000), actualCost: z.union([z.literal(""), z.coerce.number().min(0).max(9999999999)]), currency: z.enum(["EUR"]).default("EUR") }).parse(raw);
  return eventMutation(actor, eventId, "event.edit", async (tx, event) => {
    if (event.status.code !== "COMPLETED") throw new DomainError("Nachbereitung ist erst nach Abschluss möglich.");
    const { actualCost, currency, ...lessons } = data;
    await tx.eventLessonLearned.upsert({ where: { eventId }, create: { eventId, ...lessons }, update: lessons });
    await tx.event.update({ where: { id: eventId }, data: { actualCost: actualCost === "" ? null : actualCost, currency: actualCost === "" ? null : currency } });
    await audit(tx, actor, eventId, "lessons.updated", "Event", eventId);
  });
}
async function clone(tx: Tx, actor: Actor, sourceId: string, start: Date, title: string, seriesId?: string) {
  const source = await tx.event.findUniqueOrThrow({ where: { id: sourceId }, include: { eventLocation_event: true, eventTask_event: true, eventResponsibility_event: true, eventScheduleItem_event: true } });
  for (const l of source.eventLocation_event) requireRight(actor, "event.create", { ownerId: actor.employeeId, locationIds: [l.locationId] });
  const draft = await tx.eventStatus.findUniqueOrThrow({ where: { code: "DRAFT" } });
  const delta = +start - +source.start;
  const target = await tx.event.create({ data: { title, description: source.description, structure: source.structure, typeId: source.typeId, start, end: new Date(+source.end + delta), timeZone: source.timeZone, ownerId: actor.employeeId, statusId: draft.id, previousId: sourceId, visibility: "INVOLVED", reviewRequired: true, seriesId, occurrenceKey: seriesId ? start.toISOString() : null,
    eventLocation_event: { create: source.eventLocation_event.map((l) => ({ locationId: l.locationId })) },
    eventTask_event: { create: source.eventTask_event.map((t) => ({ title: t.title, description: t.description, assigneeId: t.assigneeId, areaId: t.areaId, dueAt: t.dueAt ? new Date(+t.dueAt + delta) : null, critical: t.critical, priority: t.priority })) },
    eventResponsibility_event: { create: source.eventResponsibility_event.map((r) => ({ employeeId: r.employeeId, areaId: r.areaId })) },
  } });
  for (const s of source.eventScheduleItem_event) await tx.eventScheduleItem.create({ data: { eventId: target.id, title: s.title, description: s.description, start: new Date(+s.start + delta), end: new Date(+s.end + delta), sortOrder: s.sortOrder, roomId: s.roomId, workshopId: s.workshopId, buildingId: s.buildingId, locationId: s.locationId, responsibleId: s.responsibleId } });
  await audit(tx, actor, target.id, "event.copied", "Event", target.id, { sourceId, reviewRequired: true }); return target.id;
}
export async function copyEvent(actor: Actor, eventId: string, raw: unknown) {
  const input = z.object({ title: text, start: instant }).parse(raw);
  return eventMutation(actor, eventId, "event.edit", async (tx) => clone(tx, actor, eventId, input.start, input.title));
}
export async function createSeries(actor: Actor, eventId: string, raw: unknown) {
  const input = z.object({ title: text, count: z.coerce.number().int().min(2).max(52), frequency: z.enum(["DAILY", "WEEKLY", "MONTHLY"]) }).parse(raw);
  const { RRule } = await import("rrule").then((m) => m.default ?? m);
  return eventMutation(actor, eventId, "event.edit", async (tx, event) => {
    // RRule expects a UTC-encoded wall time when a TZID is supplied. It handles DST per occurrence.
    const parts = Object.fromEntries(new Intl.DateTimeFormat("en-CA", { timeZone: event.timeZone, year: "numeric", month: "2-digit", day: "2-digit", hour: "2-digit", minute: "2-digit", second: "2-digit", hourCycle: "h23" }).formatToParts(event.start).map((p) => [p.type, p.value]));
    const dtstart = new Date(Date.UTC(+parts.year, +parts.month - 1, +parts.day, +parts.hour, +parts.minute, +parts.second));
    const rule = new RRule({ freq: RRule[input.frequency], count: input.count, dtstart, tzid: event.timeZone });
    const dates = rule.all();
    const series = await tx.eventSeries.create({ data: { title: input.title, rrule: rule.toString(), timeZone: event.timeZone } });
    const ids = [];
    for (const [i, date] of dates.entries()) ids.push(await clone(tx, actor, eventId, date, `${input.title} · ${i + 1}`, series.id));
    return ids[0];
  });
}
const blueprintSchema = z.object({ title: text, description: notes, typeId: uuid, structure: z.enum(["INTERNAL", "EXTERNAL", "MIXED"]), durationMinutes: z.number().int().positive().max(525600), locationIds: z.array(uuid).min(1), tasks: z.array(z.object({ title: text, description: notes, critical: z.boolean() })).max(500), schedule: z.array(z.object({ title: text, offset: z.number(), duration: z.number().positive(), sortOrder: z.number().int() })).max(500) });
export async function saveTemplate(actor: Actor, eventId: string, name: string) {
  text.parse(name); return eventMutation(actor, eventId, "event.edit", async (tx, event) => {
    const tasks = await tx.eventTask.findMany({ where: { eventId } }), schedule = await tx.eventScheduleItem.findMany({ where: { eventId } });
    const blueprint = blueprintSchema.parse({ title: event.title, description: event.description ?? "", typeId: event.typeId, structure: event.structure, durationMinutes: (+event.end - +event.start) / 60000, locationIds: event.eventLocation_event.map((l) => l.locationId), tasks: tasks.map((t) => ({ title: t.title, description: t.description ?? "", critical: t.critical })), schedule: schedule.map((s) => ({ title: s.title, offset: (+s.start - +event.start) / 60000, duration: (+s.end - +s.start) / 60000, sortOrder: s.sortOrder })) });
    // Templates contain no participant data, recipients, tokens, reservations or internal notes.
    const template = await tx.eventTemplate.create({ data: { name, blueprint, ownerId: actor.employeeId } }); await audit(tx, actor, eventId, "template.created", "EventTemplate", template.id); return template.id;
  });
}
export async function instantiateTemplate(actor: Actor, templateId: string, startValue: string) {
  uuid.parse(templateId); const start = instant.parse(startValue);
  return db.$transaction(async (tx) => {
    const template = await tx.eventTemplate.findFirst({ where: { id: templateId, active: true, ...(actor.grants.some((g) => g.permission === "administration.manage" && g.scope === "ALL") ? {} : { OR: [{ ownerId: actor.employeeId }, { shared: true }] }) } }); if (!template) throw new DomainError("Vorlage nicht gefunden.");
    // Templates are organization-wide planning data; access requires global creation rights.
    requireRight(actor, "event.create");
    const b = blueprintSchema.parse(template.blueprint), draft = await tx.eventStatus.findUniqueOrThrow({ where: { code: "DRAFT" } });
    const event = await tx.event.create({ data: { title: b.title, description: b.description, typeId: b.typeId, structure: b.structure, start, end: new Date(+start + b.durationMinutes * 60000), ownerId: actor.employeeId, statusId: draft.id, templateId, reviewRequired: true, visibility: "INVOLVED", eventLocation_event: { create: b.locationIds.map((locationId) => ({ locationId })) }, eventTask_event: { create: b.tasks.map((t) => ({ ...t, assigneeId: actor.employeeId })) }, eventScheduleItem_event: { create: b.schedule.map((s) => ({ title: s.title, start: new Date(+start + s.offset * 60000), end: new Date(+start + (s.offset + s.duration) * 60000), sortOrder: s.sortOrder })) } } });
    await audit(tx, actor, event.id, "event.from_template", "Event", event.id, { templateId }); return event.id;
  });
}
export async function historyDetail(actor: Actor, eventId: string) {
  return eventMutation(actor, eventId, "audit.view", async (tx) => ({
    audit: await tx.auditLog.findMany({ where: { eventId }, select: { id: true, action: true, entityType: true, occurredAt: true, actor: { select: { employee_user: { select: { firstName: true, lastName: true } } } }, changes: true }, orderBy: { occurredAt: "desc" }, take: 100 }),
    lessons: await tx.eventLessonLearned.findUnique({ where: { eventId } }),
    vendors: await tx.eventVendor.findMany({ where: { eventId }, include: { vendor: true } }),
  }));
}
export async function addVendor(actor: Actor, eventId: string, raw: unknown) {
  const input = z.object({ company: text, contactName: notes, email: z.union([z.email(), z.literal("")]), service: text, reuse: z.enum(["YES", "NO", "UNDECIDED"]) }).parse(raw);
  return eventMutation(actor, eventId, "event.edit", async (tx) => {
    const { service, reuse, ...data } = input;
    const vendor = await tx.vendor.create({ data: { ...data, email: data.email || null } });
    await tx.eventVendor.create({ data: { eventId, vendorId: vendor.id, service, reuse } }); await audit(tx, actor, eventId, "vendor.added", "Vendor", vendor.id);
  });
}
