// External FM availability must never be inferred from a successful local check.
export type Availability = { state: "AVAILABLE" | "BUSY" | "UNKNOWN"; source: string; checkedAt: Date };
export interface RoomAvailabilityProvider { check(roomId: string, start: Date, end: Date): Promise<Availability>; }
export class UnconfiguredRoomProvider implements RoomAvailabilityProvider {
  async check(): Promise<Availability> { return { state: "UNKNOWN", source: "FM-System nicht angebunden", checkedAt: new Date() }; }
}
export const roomAvailability: RoomAvailabilityProvider = new UnconfiguredRoomProvider();
