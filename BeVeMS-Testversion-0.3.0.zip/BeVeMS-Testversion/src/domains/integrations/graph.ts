import { z } from "zod";
export type CalendarMessage = { eventId: string; recipient: string; subject: string; body: string; start: string; end: string; cancelled: boolean; externalId: string | null; transactionId: string };
export interface CommunicationAdapter {
  sendMail(to: string, subject: string, body: string): Promise<void>;
  syncCalendar(message: CalendarMessage): Promise<{ externalId: string | null }>;
}
export class GraphError extends Error { constructor(public code: string, public retryAfter = 60) { super(code); } }
export class MicrosoftGraphAdapter implements CommunicationAdapter {
  private accessToken?: { value: string; expires: number };
  private tenant: string; private client: string; private secret: string; private mailbox: string;
  constructor(env: Record<string, string | undefined> = process.env) {
    const config = z.object({ ENTRA_TENANT_ID: z.uuid(), GRAPH_CLIENT_ID: z.uuid(), GRAPH_CLIENT_SECRET: z.string().min(16), GRAPH_SENDER: z.email() }).parse(env);
    this.tenant = config.ENTRA_TENANT_ID; this.client = config.GRAPH_CLIENT_ID; this.secret = config.GRAPH_CLIENT_SECRET; this.mailbox = config.GRAPH_SENDER;
  }
  private async token() {
    if (this.accessToken && this.accessToken.expires > Date.now() + 60000) return this.accessToken.value;
    const response = await fetch(`https://login.microsoftonline.com/${this.tenant}/oauth2/v2.0/token`, { method: "POST", headers: { "Content-Type": "application/x-www-form-urlencoded" }, body: new URLSearchParams({ client_id: this.client, client_secret: this.secret, grant_type: "client_credentials", scope: "https://graph.microsoft.com/.default" }), signal: AbortSignal.timeout(20000) });
    if (!response.ok) throw new GraphError(`TOKEN_${response.status}`);
    const token = z.object({ access_token: z.string(), expires_in: z.number() }).parse(await response.json()); this.accessToken = { value: token.access_token, expires: Date.now() + token.expires_in * 1000 }; return token.access_token;
  }
  private async call(path: string, method: string, body?: unknown) {
    const token = await this.token();
    const r = await fetch(`https://graph.microsoft.com/v1.0/users/${encodeURIComponent(this.mailbox)}/${path}`, { method, headers: { Authorization: `Bearer ${token}`, "Content-Type": "application/json" }, body: body === undefined ? undefined : JSON.stringify(body), signal: AbortSignal.timeout(20000) });
    if (!r.ok) { const delay = Number(r.headers.get("retry-after")); throw new GraphError(`GRAPH_${r.status}`, Number.isFinite(delay) && delay > 0 ? Math.min(delay, 86400) : 60); }
    return r.status === 204 || r.status === 202 ? null : r.json();
  }
  async sendMail(to: string, subject: string, body: string) {
    await this.call("sendMail", "POST", { message: { subject, body: { contentType: "Text", content: body }, toRecipients: [{ emailAddress: { address: to } }] }, saveToSentItems: true });
  }
  async syncCalendar(m: CalendarMessage) {
    if (m.cancelled) {
      if (m.externalId) await this.call(`events/${encodeURIComponent(m.externalId)}/cancel`, "POST", { comment: "Veranstaltung abgesagt." });
      return { externalId: null };
    }
    const payload = { subject: m.subject, body: { contentType: "Text", content: m.body }, start: { dateTime: m.start.replace(/Z$/, ""), timeZone: "UTC" }, end: { dateTime: m.end.replace(/Z$/, ""), timeZone: "UTC" }, attendees: [{ emailAddress: { address: m.recipient }, type: "required" }], ...(m.externalId ? {} : { transactionId: m.transactionId }) };
    const result = await this.call(m.externalId ? `events/${encodeURIComponent(m.externalId)}` : "events", m.externalId ? "PATCH" : "POST", payload);
    return { externalId: z.object({ id: z.string() }).parse(result).id };
  }
}
