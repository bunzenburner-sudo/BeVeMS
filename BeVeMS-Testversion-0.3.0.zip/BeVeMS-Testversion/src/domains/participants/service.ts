import "server-only";
import { createHash, randomBytes } from "node:crypto";
import { z } from "zod";
import { db } from "@/lib/db";
import type { Actor } from "@/domains/identity/policy";
import { audit, DomainError, eventMutation, notes, requireRight, text, uuid } from "@/domains/planning/shared";
export async function participantList(actor: Actor, eventId: string) {
  return eventMutation(actor, eventId, "participant.view", async (tx) => tx.eventParticipant.findMany({ where: { eventId }, include: { category: true, organisation: true, eventInvitation_participant: true, checkIn_participant: { select: { checkedAt: true } } }, orderBy: [{ lastName: "asc" }, { firstName: "asc" }] }));
}
export async function addParticipant(actor: Actor, eventId: string, raw: unknown) {
  const input = z.object({ firstName: text, lastName: text, email: z.union([z.email().max(254), z.literal("")]), function: notes, categoryId: uuid, organisationId: z.union([uuid, z.literal("")]) }).parse(raw);
  return eventMutation(actor, eventId, "event.edit", async (tx, event) => {
    requireRight(actor, "participant.view", { ownerId: event.ownerId, locationIds: event.eventLocation_event.map((l) => l.locationId) });
    if (["COMPLETED", "CANCELLED"].includes(event.status.code)) throw new DomainError("Teilnehmerliste ist abgeschlossen.");
    if (!await tx.participantCategory.count({ where: { id: input.categoryId, active: true } })) throw new DomainError("Kategorie ist nicht aktiv.");
    const participant = await tx.eventParticipant.create({ data: { ...input, email: input.email || null, organisationId: input.organisationId || null, eventId, retentionUntil: new Date(+event.end + z.coerce.number().int().min(1).max(3650).parse(process.env.PARTICIPANT_RETENTION_DAYS ?? 180) * 86400000), eventInvitation_participant: { create: {} } } });
    await audit(tx, actor, eventId, "participant.created", "EventParticipant", participant.id);
  });
}
export async function setInvitation(actor: Actor, eventId: string, participantId: string, status: string) {
  uuid.parse(participantId); const target = z.enum(["NOT_INVITED", "INVITED", "ACCEPTED", "DECLINED", "NO_RESPONSE"]).parse(status);
  return eventMutation(actor, eventId, "event.edit", async (tx, event) => {
    requireRight(actor, "participant.view", { ownerId: event.ownerId, locationIds: event.eventLocation_event.map((l) => l.locationId) });
    const p = await tx.eventParticipant.findFirst({ where: { id: participantId, eventId } }); if (!p) throw new DomainError("Teilnehmer nicht gefunden.");
    await tx.eventInvitation.upsert({ where: { participantId }, create: { participantId, status: target }, update: { status: target, sentAt: target === "INVITED" ? new Date() : undefined, respondedAt: ["ACCEPTED", "DECLINED"].includes(target) ? new Date() : null } });
    if (target !== "ACCEPTED") await tx.eventParticipant.update({ where: { id: participantId }, data: { qrTokenHash: null } });
    await audit(tx, actor, eventId, "invitation.status", "EventParticipant", participantId, { to: target });
  });
}
export async function issueCheckInToken(actor: Actor, eventId: string, participantId: string) {
  uuid.parse(participantId);
  return eventMutation(actor, eventId, "participant.checkin", async (tx, event) => {
    const p = await tx.eventParticipant.findFirst({ where: { id: participantId, eventId }, include: { eventInvitation_participant: true } });
    if (!p || p.eventInvitation_participant?.status !== "ACCEPTED" || p.registrationStatus !== "REGISTERED" || ["CANCELLED", "COMPLETED"].includes(event.status.code)) throw new DomainError("QR-Code kann nur für bestätigte Teilnehmer einer aktiven Veranstaltung ausgegeben werden.");
    const token = randomBytes(32).toString("base64url");
    await tx.eventParticipant.update({ where: { id: participantId }, data: { qrTokenHash: createHash("sha256").update(token).digest("hex") } });
    await audit(tx, actor, eventId, "checkin.token_issued", "EventParticipant", participantId); return token;
  });
}
export async function checkIn(actor: Actor, eventId: string, raw: unknown) {
  const input = z.object({ participantId: z.union([uuid, z.literal("")]).default(""), token: z.string().max(100).default("") }).parse(raw);
  return eventMutation(actor, eventId, "participant.checkin", async (tx, event) => {
    if (["CANCELLED", "COMPLETED", "DRAFT"].includes(event.status.code) || Date.now() < +event.start - 86400000 || Date.now() > +event.end + 86400000) throw new DomainError("Check-in ist nur im Zeitraum vom Vortag bis zum Folgetag möglich.");
    const p = await tx.eventParticipant.findFirst({ where: { eventId, ...(input.token ? { qrTokenHash: createHash("sha256").update(input.token).digest("hex") } : { id: input.participantId || "00000000-0000-0000-0000-000000000000" }) }, include: { eventInvitation_participant: true } });
    if (!p || p.registrationStatus !== "REGISTERED" || p.eventInvitation_participant?.status !== "ACCEPTED") throw new DomainError("Kein gültiger bestätigter Teilnehmer gefunden.");
    const existing = await tx.checkIn.findUnique({ where: { participantId: p.id } }); if (existing) return existing;
    const entry = await tx.checkIn.create({ data: { participantId: p.id, actorId: actor.id, method: input.token ? "QR" : "MANUAL" } });
    await audit(tx, actor, eventId, "participant.checked_in", "EventParticipant", p.id, { method: entry.method }); return entry;
  });
}
const safeCsv = (v: string) => `"${(/^[\s]*[=+\-@]/.test(v) ? "'" : "") + v.replaceAll('"', '""')}"`;
export async function exportParticipants(actor: Actor, eventId: string) {
  return eventMutation(actor, eventId, "participant.export", async (tx, event) => {
    requireRight(actor, "participant.view", { ownerId: event.ownerId, locationIds: event.eventLocation_event.map((l) => l.locationId) });
    const rows = await tx.eventParticipant.findMany({ where: { eventId }, include: { eventInvitation_participant: true, checkIn_participant: true }, orderBy: { lastName: "asc" } });
    await audit(tx, actor, eventId, "participant.exported", "Event", eventId, { count: rows.length });
    return "\ufeff" + [["Vorname", "Nachname", "E-Mail", "Einladung", "Anwesend"], ...rows.map((p) => [p.firstName, p.lastName, p.email ?? "", p.eventInvitation_participant?.status ?? "NOT_INVITED", p.checkIn_participant ? "Ja" : "Nein"])].map((row) => row.map(safeCsv).join(";")).join("\r\n");
  });
}
export async function linkOrganisation(actor: Actor, eventId: string, raw: unknown) {
  const input = z.object({ organisationId: uuid, contactId: z.union([uuid, z.literal("")]) }).parse(raw);
  return eventMutation(actor, eventId, "event.edit", async (tx, event) => {
    requireRight(actor, "participant.view", { ownerId: event.ownerId, locationIds: event.eventLocation_event.map((l) => l.locationId) });
    const link = await tx.eventOrganisation.upsert({ where: { eventId_organisationId: { eventId, organisationId: input.organisationId } }, create: { eventId, organisationId: input.organisationId, contactId: input.contactId || null }, update: { contactId: input.contactId || null } });
    await audit(tx, actor, eventId, "organisation.linked", "EventOrganisation", link.id);
  });
}
export async function addParticipantGroup(actor: Actor, eventId: string, raw: unknown) {
  const input = z.object({ name: text, count: z.coerce.number().int().min(1).max(100000), description: notes, categoryId: uuid, organisationId: z.union([uuid, z.literal("")]) }).parse(raw);
  return eventMutation(actor, eventId, "event.edit", async (tx, event) => {
    requireRight(actor, "participant.view", { ownerId: event.ownerId, locationIds: event.eventLocation_event.map((l) => l.locationId) });
    const group = await tx.eventParticipantGroup.create({ data: { ...input, organisationId: input.organisationId || null, eventId } });
    await audit(tx, actor, eventId, "participant_group.created", "EventParticipantGroup", group.id);
  });
}
export async function removeParticipant(actor: Actor, eventId: string, participantId: string, confirmed: boolean) {
  uuid.parse(participantId); if (!confirmed) throw new DomainError("Bitte die Löschung ausdrücklich bestätigen.");
  return eventMutation(actor, eventId, "event.edit", async (tx, event) => {
    requireRight(actor, "participant.view", { ownerId: event.ownerId, locationIds: event.eventLocation_event.map((l) => l.locationId) });
    const p = await tx.eventParticipant.findFirst({ where: { id: participantId, eventId } }); if (!p) throw new DomainError("Teilnehmer nicht gefunden.");
    await tx.checkIn.deleteMany({ where: { participantId } }); await tx.eventInvitation.deleteMany({ where: { participantId } }); await tx.eventParticipant.delete({ where: { id: participantId } });
    await audit(tx, actor, eventId, "participant.deleted", "EventParticipant", participantId);
  });
}
