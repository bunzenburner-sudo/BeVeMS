import "server-only";
import { db } from "@/lib/db";
export async function expireParticipantData(apply = false) {
  const due = await db.eventParticipant.findMany({ where: { retentionUntil: { lte: new Date() }, event: { status: { code: { in: ["COMPLETED", "CANCELLED"] } } } }, select: { id: true, eventId: true }, take: 500 });
  if (!apply) return { candidates: due.length, deleted: 0 };
  if (process.env.PARTICIPANT_RETENTION_APPROVED !== "true") throw new Error("Retention policy must be approved and explicitly enabled before applying deletions.");
  let deleted = 0;
  for (const row of due) await db.$transaction(async (tx) => {
    await tx.$queryRaw`SELECT id FROM "Event" WHERE id = ${row.eventId}::uuid FOR UPDATE`;
    // Recheck eligibility under the same event lock used by participant mutations.
    const eligible = await tx.eventParticipant.count({ where: { id: row.id, retentionUntil: { lte: new Date() }, event: { status: { code: { in: ["COMPLETED", "CANCELLED"] } } } } }); if (!eligible) return;
    await tx.checkIn.deleteMany({ where: { participantId: row.id } }); await tx.eventInvitation.deleteMany({ where: { participantId: row.id } }); await tx.eventParticipant.delete({ where: { id: row.id } });
    await tx.auditLog.create({ data: { eventId: row.eventId, action: "participant.retention_deleted", entityType: "EventParticipant", entityId: row.id, changes: {} } }); deleted++;
  });
  return { candidates: due.length, deleted };
}
