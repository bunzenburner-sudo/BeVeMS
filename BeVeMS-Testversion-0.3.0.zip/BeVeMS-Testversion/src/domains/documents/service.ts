import "server-only";
import { randomUUID } from "node:crypto";
import { db } from "@/lib/db";
import type { Actor } from "@/domains/identity/policy";
import { permitted, AccessError } from "@/domains/identity/policy";
import { audit, DomainError, eventMutation, uuid } from "@/domains/planning/shared";
import { PrivateFileStorage, ClamAvScanner, type DocumentStorage, type MalwareScanner } from "./storage";
const store = new PrivateFileStorage(), scanner = new ClamAvScanner();
export const maxDocumentSize = 10 * 1024 * 1024;
export function documentMime(data: Uint8Array) {
  const b = Buffer.from(data);
  if (b.subarray(0, 5).toString() === "%PDF-") return "application/pdf";
  if (b.subarray(0, 8).equals(Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]))) return "image/png";
  if (b[0] === 255 && b[1] === 216 && b[2] === 255) return "image/jpeg";
  try { const text = new TextDecoder("utf-8", { fatal: true }).decode(data); if (!/[\x00-\x08\x0b\x0c\x0e-\x1f]/.test(text)) return "text/plain"; } catch {}
  throw new DomainError("Erlaubt sind PDF, PNG, JPEG und UTF-8-Textdateien.");
}
export async function uploadDocument(actor: Actor, eventId: string, name: string, data: Uint8Array, storage: DocumentStorage = store, malware: MalwareScanner = scanner) {
  if (!name.trim() || name.length > 200 || /[\r\n\/\\]/.test(name) || !data.length || data.length > maxDocumentSize) throw new DomainError("Ungültiger Dateiname oder Dateigröße (maximal 10 MiB).");
  const mimeType = documentMime(data);
  await eventMutation(actor, eventId, "event.edit", async () => {});
  const key = randomUUID(); await storage.put(key, data);
  try {
    const scanStatus = await malware.scan(data);
    if (scanStatus === "INFECTED") throw new DomainError("Die Sicherheitsprüfung hat die Datei abgelehnt.");
    return await eventMutation(actor, eventId, "event.edit", async (tx) => {
      const doc = await tx.eventDocument.create({ data: { eventId, name: name.trim(), storageKey: key, mimeType, sizeBytes: data.length, scanStatus, uploadedById: actor.id } });
      await audit(tx, actor, eventId, "document.uploaded", "EventDocument", doc.id, { scanStatus, sizeBytes: data.length }); return doc.id;
    });
  } catch (e) { await storage.remove(key).catch(() => {}); throw e; }
}
export async function documents(actor: Actor, eventId: string) {
  return eventMutation(actor, eventId, "event.edit", async (tx) => tx.eventDocument.findMany({ where: { eventId }, select: { id: true, name: true, sizeBytes: true, scanStatus: true, uploadedAt: true }, orderBy: { uploadedAt: "desc" } }));
}
export async function downloadDocument(actor: Actor, eventId: string, id: string, storage: DocumentStorage = store) {
  uuid.parse(id); return eventMutation(actor, eventId, "event.edit", async (tx) => {
    const doc = await tx.eventDocument.findFirst({ where: { id, eventId, scanStatus: "CLEAN" } }); if (!doc) throw new AccessError(404);
    const data = await storage.read(doc.storageKey); await audit(tx, actor, eventId, "document.downloaded", "EventDocument", id); return { name: doc.name, mimeType: doc.mimeType, data };
  });
}
export async function rescanPendingDocuments(storage: DocumentStorage = store, malware: MalwareScanner = scanner) {
  const pending = await db.eventDocument.findMany({ where: { scanStatus: "PENDING" }, take: 50 }); let processed = 0;
  for (const doc of pending) {
    const result = await malware.scan(await storage.read(doc.storageKey));
    if (result === "PENDING") continue;
    await db.$transaction(async (tx) => {
      await tx.eventDocument.update({ where: { id: doc.id }, data: { scanStatus: result } });
      await tx.auditLog.create({ data: { eventId: doc.eventId, action: "document.scanned", entityType: "EventDocument", entityId: doc.id, changes: { result } } });
    });
    if (result === "INFECTED") await storage.remove(doc.storageKey).catch(() => {});
    processed++;
  }
  return processed;
}
