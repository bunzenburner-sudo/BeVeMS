import { mkdir, readFile, writeFile, unlink } from "node:fs/promises";
import path from "node:path";
import net from "node:net";
export interface DocumentStorage { put(key: string, data: Uint8Array): Promise<void>; read(key: string): Promise<Uint8Array>; remove(key: string): Promise<void>; }
export class PrivateFileStorage implements DocumentStorage {
  constructor(private directory = process.env.DOCUMENT_STORAGE_PATH || path.join(process.cwd(), ".local/documents")) {}
  private file(key: string) { if (!/^[0-9a-f-]{36}$/.test(key)) throw new Error("Invalid storage key"); return path.join(this.directory, key); }
  async put(key: string, data: Uint8Array) { await mkdir(this.directory, { recursive: true, mode: 0o700 }); await writeFile(this.file(key), data, { flag: "wx", mode: 0o600 }); }
  async read(key: string) { return readFile(this.file(key)); }
  async remove(key: string) { await unlink(this.file(key)); }
}
export interface MalwareScanner { scan(data: Uint8Array): Promise<"CLEAN" | "INFECTED" | "PENDING">; }
export class ClamAvScanner implements MalwareScanner {
  async scan(data: Uint8Array): Promise<"CLEAN" | "INFECTED" | "PENDING"> {
    const host = process.env.CLAMAV_HOST; if (!host) return "PENDING";
    const port = Number(process.env.CLAMAV_PORT || 3310); if (!Number.isInteger(port) || port < 1 || port > 65535) throw new Error("Invalid scanner port");
    return new Promise((resolve) => {
      const socket = net.createConnection({ host, port }); let response = "", complete = false;
      const finish = (result: "CLEAN" | "INFECTED" | "PENDING") => { if (!complete) { complete = true; socket.destroy(); resolve(result); } };
      socket.setTimeout(15000, () => finish("PENDING")); socket.on("error", () => finish("PENDING"));
      socket.on("connect", () => { socket.write("zINSTREAM\0"); for (let i = 0; i < data.length; i += 65536) { const chunk = data.subarray(i, i + 65536), header = Buffer.alloc(4); header.writeUInt32BE(chunk.length); socket.write(header); socket.write(chunk); } socket.write(Buffer.alloc(4)); });
      socket.on("data", (chunk) => { response += chunk.toString("utf8"); if (response.length > 4096) return finish("PENDING"); if (response.includes("\0") || response.includes("\n")) finish(response.includes(" FOUND") ? "INFECTED" : /: OK(?:\0|\n)/.test(response) ? "CLEAN" : "PENDING"); });
      socket.on("end", () => finish(response.includes(" FOUND") ? "INFECTED" : response.trim().endsWith(": OK") ? "CLEAN" : "PENDING"));
    });
  }
}
