import "server-only";
import { db } from "@/lib/db";
import { AccessError, hasPermission, type Actor } from "@/domains/identity/policy";

export async function listLocations(actor: Actor) {
  if (!hasPermission(actor, "location.view")) throw new AccessError(403);
  const grants = actor.grants.filter((grant) => grant.permission === "location.view");
  const all = grants.some((grant) => grant.scope === "ALL");
  return db.location.findMany({
    where: { active: true, ...(all ? {} : { id: { in: grants.filter((grant) => grant.scope === "LOCATION" && grant.locationId).map((grant) => grant.locationId!) } }) },
    select: { id: true, name: true, address: true, building_location: { where: { active: true }, select: {
      id: true, name: true, shortCode: true, room_building: { where: { active: true }, select: {
        id: true, name: true, code: true, capacity: true, accessible: true, type: { select: { name: true } },
        workshop_room: { select: { name: true, maxVisitors: true, trade: { select: { name: true } } } },
      } },
    } } }, orderBy: { name: "asc" },
  });
}
