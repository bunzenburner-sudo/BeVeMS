import type { Prisma } from "@/generated/prisma/client";
import type { Actor } from "@/domains/identity/policy";

export function involvementWhere(actor: Actor): Prisma.EventWhereInput {
  return { OR: [
    { ownerId: actor.employeeId },
    { eventInvolvement_event: { some: { employeeId: actor.employeeId } } },
    { eventResponsibility_event: { some: { employeeId: actor.employeeId } } },
    { eventTask_event: { some: { assigneeId: actor.employeeId } } },
    { eventScheduleItem_event: { some: { responsibleId: actor.employeeId } } },
  ] };
}

export function visibleEventsWhere(actor: Actor): Prisma.EventWhereInput {
  const grants = actor.grants.filter((grant) => grant.permission === "event.view");
  if (!grants.length) return { id: { in: [] } };
  const all = grants.some((grant) => grant.scope === "ALL");
  const scope: Prisma.EventWhereInput[] = grants.flatMap((grant): Prisma.EventWhereInput[] => {
    switch (grant.scope) {
      case "ALL": return [];
      case "OWN": return [{ ownerId: actor.employeeId }];
      case "ASSIGNED": return [involvementWhere(actor)];
      case "LOCATION": return grant.locationId ? [{ eventLocation_event: { some: { locationId: grant.locationId } } }] : [];
    }
  });
  const sensitive = actor.grants.some((grant) => grant.permission === "event.view_sensitive" && grant.scope === "ALL");
  const visibility: Prisma.EventWhereInput = sensitive ? {} : { OR: [
    { visibility: "ALL_EMPLOYEES" },
    { visibility: "LOCATIONS", eventVisibilityLocation_event: { some: { locationId: actor.locationId } } },
    { visibility: "UNITS", eventVisibilityUnit_event: { some: { unitId: actor.unitId } } },
    { visibility: "GROUPS", eventVisibilityGroup_event: { some: { groupId: { in: actor.groups } } } },
    involvementWhere(actor),
  ] };
  const scopeWhere: Prisma.EventWhereInput = all ? {} : scope.length ? { OR: scope } : { id: { in: [] } };
  return { AND: [scopeWhere, visibility] };
}
