import "server-only";
import { z } from "zod";
import { db } from "@/lib/db";
import { visibleEventsWhere } from "./policy";
import { permitted, type Actor } from "@/domains/identity/policy";
import type { Prisma } from "@/generated/prisma/client";
// Participant results require the same view permission and scope as a participant list.
function participantEventsWhere(actor: Actor): Prisma.EventWhereInput {
  const grants = actor.grants.filter((g) => g.permission === "participant.view");
  const scopes: Prisma.EventWhereInput[] = grants.flatMap((g): Prisma.EventWhereInput[] => g.scope === "OWN" ? [{ ownerId: actor.employeeId }] : g.scope === "LOCATION" && g.locationId ? [{ eventLocation_event: { some: { locationId: g.locationId } } }] : []);
  return { AND: [visibleEventsWhere(actor), grants.some((g) => g.scope === "ALL") ? {} : scopes.length ? { OR: scopes } : { id: { in: [] } }] };
}
export async function searchAll(actor: Actor, query: string) {
  const q = z.string().trim().min(2).max(120).parse(query);
  const contains = { contains: q, mode: "insensitive" as const };
  const isDate = /^\d{4}-\d{2}-\d{2}$/.test(q) && !Number.isNaN(Date.parse(q));
  const [events, participants, organisations, rooms, employees] = await Promise.all([
    db.event.findMany({ where: { AND: [visibleEventsWhere(actor)], OR: [{ title: contains }, { type: { name: contains } }, ...(isDate ? [{ start: { gte: new Date(`${q}T00:00Z`), lt: new Date(Date.parse(`${q}T00:00Z`) + 86400000) } }] : [])] }, select: { id: true, title: true, start: true }, take: 30, orderBy: { start: "desc" } }),
    db.eventParticipant.findMany({ where: { event: participantEventsWhere(actor), OR: [{ firstName: contains }, { lastName: contains }] }, select: { id: true, firstName: true, lastName: true, eventId: true }, take: 30 }),
    permitted(actor, "participant.view") ? db.organisation.findMany({ where: { OR: [{ name: contains }, { externalContact_organisation: { some: { OR: [{ firstName: contains }, { lastName: contains }] } } }] }, select: { id: true, name: true }, take: 30 }) : [],
    permitted(actor, "location.view") ? db.room.findMany({ where: { active: true, OR: [{ name: contains }, { code: contains }, { building: { name: contains } }, { building: { location: { name: contains } } }, { workshop_room: { name: contains } }, { workshop_room: { trade: { name: contains } } }] }, select: { id: true, name: true }, take: 30 }) : [],
    permitted(actor, "employee.view") ? db.employee.findMany({ where: { active: true, OR: [{ firstName: contains }, { lastName: contains }] }, select: { id: true, firstName: true, lastName: true }, take: 30 }) : [],
  ]);
  return { events, participants, organisations, rooms, employees };
}
