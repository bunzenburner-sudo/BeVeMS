import "server-only";
import { z } from "zod";
import { db } from "@/lib/db";
import { AccessError, type Actor } from "@/domains/identity/policy";
import { visibleEventsWhere } from "./policy";
import type { Prisma } from "@/generated/prisma/client";

const summary = {
  id: true, title: true, description: true, start: true, end: true,
  structure: true, participantCount: true, timeZone: true,
  type: { select: { name: true } }, status: { select: { code: true, name: true } },
  owner: { select: { firstName: true, lastName: true } },
  eventLocation_event: { select: { location: { select: { id: true, name: true } } } },
} satisfies Prisma.EventSelect;

export async function listEvents(actor: Actor, search = "") {
  const query = z.string().trim().max(120).parse(search);
  return db.event.findMany({ where: { AND: [visibleEventsWhere(actor), query ? { title: { contains: query, mode: "insensitive" } } : {}] }, select: summary, orderBy: { start: "asc" }, take: 100 });
}
export async function eventDetail(actor: Actor, id: string) {
  if (!z.uuid().safeParse(id).success) throw new AccessError(404);
  const event = await db.event.findFirst({ where: { AND: [{ id }, visibleEventsWhere(actor)] }, select: summary });
  if (!event) throw new AccessError(404);
  return event;
}
