import "server-only";
import { db } from "@/lib/db";
import { AccessError, hasPermission, permitted, type Actor } from "@/domains/identity/policy";

export async function listEmployees(actor: Actor) {
  if (!hasPermission(actor, "employee.view")) throw new AccessError(403);
  const grants = actor.grants.filter((grant) => grant.permission === "employee.view");
  const all = grants.some((grant) => grant.scope === "ALL");
  const rows = await db.employee.findMany({ where: { active: true, ...(all ? {} : { OR: grants.map((grant) => {
    if (grant.scope === "LOCATION" && grant.locationId) return { locationId: grant.locationId };
    return { id: actor.employeeId };
  }) }) }, select: { id: true, firstName: true, lastName: true, function: true, locationId: true, location: { select: { name: true } }, unit: { select: { name: true } } }, orderBy: { lastName: "asc" } });
  // Do not fetch language profiles into a projection which the caller cannot access.
  return Promise.all(rows.map(async (employee) => ({
    ...employee,
    ...(permitted(actor, "employee.view_languages", { ownerId: employee.id, locationIds: [employee.locationId] }) ? {
      languages: await db.employeeLanguage.findMany({ where: { employeeId: employee.id }, select: { level: true, language: { select: { name: true } } } }),
    } : {}),
  })));
}
