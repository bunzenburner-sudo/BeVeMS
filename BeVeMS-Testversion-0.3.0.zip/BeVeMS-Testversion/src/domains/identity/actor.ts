import "server-only";
import { getServerSession } from "next-auth";
import { cache } from "react";
import { db } from "@/lib/db";
import { authOptions } from "./auth";
import { AccessError, type Actor } from "./policy";

export async function loadActor(userId: string): Promise<Actor | null> {
  const user = await db.user.findUnique({ where: { id: userId }, include: {
    employee_user: { include: { unit: true, location: true } },
    groupMembership_user: { where: { group: { active: true } } },
    userRole_user: { where: { role: { active: true } }, include: { role: { include: { rolePermission_role: { include: { permission: true } } } }, location: true } },
  } });
  const employee = user?.employee_user;
  if (!user?.active || !employee?.active || !employee.unit.active || !employee.location.active) return null;
  return {
    id: user.id, employeeId: employee.id, locationId: employee.locationId, unitId: employee.unitId,
    name: `${employee.firstName} ${employee.lastName}`,
    groups: user.groupMembership_user.map((membership) => membership.groupId),
    grants: user.userRole_user.filter((binding) => !binding.locationId || binding.location?.active).flatMap((binding) =>
      binding.role.rolePermission_role
        .filter((grant) => grant.scope === "LOCATION" ? !!binding.locationId : !binding.locationId)
        .map((grant) => ({ permission: grant.permission.code, scope: grant.scope, locationId: binding.locationId }))),
  };
}

// React cache is request-scoped; roles are reloaded on every new request.
export const currentActor = cache(async () => {
  const session = await getServerSession(authOptions);
  return session?.user.id ? loadActor(session.user.id) : null;
});
export async function requireActor() {
  const actor = await currentActor();
  if (!actor) throw new AccessError(401);
  return actor;
}
