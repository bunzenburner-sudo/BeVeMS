import AzureADProvider from "next-auth/providers/azure-ad";

export function createEntraProvider(tenantId: string, clientId: string, clientSecret: string) {
  const provider = AzureADProvider({
    tenantId, clientId, clientSecret,
    authorization: { params: { scope: "openid profile email" } },
    checks: ["pkce", "state", "nonce"],
  });
  // The provider's default profile mapper fetches a Graph photo. Phase-2 login
  // needs only verified OIDC identity; names/rights are read from the local DB.
  provider.profile = (profile) => ({ id: profile.sub });
  return provider;
}
