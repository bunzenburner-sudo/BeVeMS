export type Scope = "ALL" | "LOCATION" | "OWN" | "ASSIGNED";
export type Actor = {
  id: string; employeeId: string; locationId: string; unitId: string;
  name: string; groups: string[];
  grants: { permission: string; scope: Scope; locationId: string | null }[];
};
export type Context = { ownerId?: string; assignedEmployeeId?: string; locationIds?: string[] };

export function hasPermission(actor: Actor, permission: string) {
  return actor.grants.some((grant) => grant.permission === permission && (grant.scope !== "LOCATION" || !!grant.locationId));
}
export function permitted(actor: Actor, permission: string, context: Context = {}) {
  return actor.grants.some((grant) => grant.permission === permission && (
    grant.scope === "ALL" ||
    (grant.scope === "OWN" && context.ownerId === actor.employeeId) ||
    (grant.scope === "ASSIGNED" && context.assignedEmployeeId === actor.employeeId) ||
    (grant.scope === "LOCATION" && !!grant.locationId && !!context.locationIds?.includes(grant.locationId))
  ));
}

export class AccessError extends Error {
  constructor(public readonly status: 401 | 403 | 404) { super("Access denied"); }
}
