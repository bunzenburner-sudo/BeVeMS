import { z } from "zod";

export function identityConfig(env: Record<string, string | undefined> = process.env) {
  const keys = [env.ENTRA_TENANT_ID, env.ENTRA_CLIENT_ID, env.ENTRA_CLIENT_SECRET];
  const configured = keys.every(Boolean);
  if (keys.some(Boolean) && !configured) throw new Error("Entra configuration must be complete.");
  if (configured) {
    z.uuid().parse(env.ENTRA_TENANT_ID);
    z.uuid().parse(env.ENTRA_CLIENT_ID);
    if (env.NODE_ENV === "production" && !env.NEXTAUTH_URL?.startsWith("https://")) throw new Error("Production authentication requires an HTTPS NEXTAUTH_URL.");
  }
  const demo = env.DEMO_AUTH_ENABLED === "true" && env.NODE_ENV === "development";
  if (demo && (!env.DEMO_AUTH_PASSWORD || env.DEMO_AUTH_PASSWORD.length < 20)) {
    throw new Error("Development demo login requires a password of at least 20 characters.");
  }
  if ((configured || demo) && (!env.AUTH_SECRET || env.AUTH_SECRET.length < 32)) {
    throw new Error("Authentication requires AUTH_SECRET of at least 32 characters.");
  }
  if (env.NODE_ENV === "production" && env.DEMO_AUTH_ENABLED === "true") {
    throw new Error("Demo authentication is forbidden in production.");
  }
  return { configured, demo };
}
