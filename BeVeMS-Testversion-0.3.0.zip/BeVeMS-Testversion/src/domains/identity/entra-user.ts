import "server-only";
import { z } from "zod";
import { db } from "@/lib/db";
export async function resolveEntraIdentity(profile: unknown, expectedTenant: string | undefined) {
  const claims = z.object({ tid: z.uuid(), oid: z.uuid() }).safeParse(profile);
  if (!expectedTenant || !claims.success || claims.data.tid !== expectedTenant) return null;
  const identity = await db.user.findUnique({ where: { tenantId_subject: { tenantId: claims.data.tid, subject: claims.data.oid } }, include: { employee_user: true } });
  return identity?.active && identity.employee_user?.active ? identity : null;
}
