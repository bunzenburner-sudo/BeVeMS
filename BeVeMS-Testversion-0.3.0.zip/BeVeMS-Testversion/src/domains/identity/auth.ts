import "server-only";
import { timingSafeEqual } from "node:crypto";
import type { NextAuthOptions } from "next-auth";
import CredentialsProvider from "next-auth/providers/credentials";
import { z } from "zod";
import { db } from "@/lib/db";
import { identityConfig } from "./config";
import { resolveEntraIdentity } from "./entra-user";
import { createEntraProvider } from "./entra-provider";

const configuration = identityConfig();
const attempts = new Map<string, { count: number; until: number }>();

export const authOptions: NextAuthOptions = {
  secret: process.env.AUTH_SECRET,
  session: { strategy: "jwt", maxAge: 60 * 60 * 8 },
  pages: { signIn: "/login", error: "/login" },
  providers: [
    ...(configuration.configured ? [createEntraProvider(process.env.ENTRA_TENANT_ID!, process.env.ENTRA_CLIENT_ID!, process.env.ENTRA_CLIENT_SECRET!)] : []),
    ...(configuration.demo ? [CredentialsProvider({
      name: "Lokale Entwicklung",
      credentials: { profile: { label: "Profil", type: "text" }, password: { label: "Passwort", type: "password" } },
      async authorize(credentials) {
        const parsed = z.object({ profile: z.enum(["admin", "organizer", "employee", "instructor", "site"]), password: z.string().max(256) }).safeParse(credentials);
        if (!parsed.success) return null;
        const key = parsed.data.profile;
        const limit = attempts.get(key);
        if (limit && limit.until > Date.now() && limit.count >= 5) return null;
        const expected = Buffer.from(process.env.DEMO_AUTH_PASSWORD!);
        const supplied = Buffer.from(parsed.data.password);
        if (expected.length !== supplied.length || !timingSafeEqual(expected, supplied)) {
          attempts.set(key, { count: limit && limit.until > Date.now() ? limit.count + 1 : 1, until: Date.now() + 60_000 });
          return null;
        }
        attempts.delete(key);
        const user = await db.user.findUnique({ where: { tenantId_subject: { tenantId: "local-demo", subject: key } }, include: { employee_user: true } });
        if (!user?.active || !user.employee_user?.active) return null;
        return { id: user.id, name: `${user.employee_user.firstName} ${user.employee_user.lastName}` };
      },
    })] : []),
  ],
  callbacks: {
    async signIn({ user, account, profile }) {
      if (account?.provider === "credentials") return configuration.demo;
      if (account?.provider !== "azure-ad") return false;
      // Only an explicitly provisioned, active local identity can log in. Never match by email.
      const identity = await resolveEntraIdentity(profile, process.env.ENTRA_TENANT_ID);
      if (!identity) return false;
      user.id = identity.id;
      return true;
    },
    async jwt({ token, user, account }) {
      if (user && account) { token.localUserId = user.id; token.authProvider = account.provider; }
      return token;
    },
    async session({ session, token }) {
      const allowedProvider = (token.authProvider === "azure-ad" && configuration.configured) || (token.authProvider === "credentials" && configuration.demo);
      session.user = { id: allowedProvider && typeof token.localUserId === "string" ? token.localUserId : "" };
      return session;
    },
  },
};
