import "server-only";
import { z } from "zod";
import { db } from "@/lib/db";
import { AccessError, permitted, type Actor } from "@/domains/identity/policy";
import { instant, requireRight, timeRange, uuid } from "@/domains/planning/shared";
import { findConflicts } from "./service";
export const levels = { A1: 1, A2: 2, B1: 3, B2: 4, C1: 5, C2: 6, NATIVE: 7 };
export function languageRecommendation(level: number) { return level >= 5 ? "Sehr gut geeignet" : level >= 4 ? "Geeignet" : "Übersetzung erforderlich"; }
export async function suggestWorkshops(actor: Actor, raw: unknown) {
  const input = z.object({ start: instant, end: instant, visitors: z.coerce.number().int().min(1), languageId: uuid, alternativeLanguageIds: z.array(uuid).default([]), tradeIds: z.array(uuid).min(1).max(50) }).parse(raw);
  timeRange(input.start, input.end);
  if (!actor.grants.some((g) => ["event.create", "event.edit"].includes(g.permission))) throw new AccessError(403);
  const workshops = await db.workshop.findMany({ where: { active: true, tradeId: { in: input.tradeIds }, room: { active: true, building: { active: true, location: { active: true } } } }, include: { room: { include: { building: true } }, trade: true, workshopEmployee_workshop: { where: { employee: { active: true } }, include: { employee: { select: { id: true, firstName: true, lastName: true } } } } } });
  const results = [];
  for (const w of workshops) {
    const context = { locationIds: [w.room.building.locationId], ownerId: actor.employeeId };
    if (!permitted(actor, "event.create", context) && !permitted(actor, "event.edit", context)) continue;
    const candidates = [];
    for (const assignment of w.workshopEmployee_workshop) {
      const e = assignment.employee;
      const check = await findConflicts(db, { ...input, roomId: w.roomId, setupMinutes: 0, teardownMinutes: 0, instructorIds: [e.id], overrideReason: "", status: "TENTATIVE", localOnlyAcknowledged: false });
      if (check.conflicts.length) continue;
      // Never fetch a language profile unless the separate permission authorizes this employee.
      const disclose = permitted(actor, "employee.view_languages", { ownerId: e.id, assignedEmployeeId: e.id, locationIds: [w.room.building.locationId] });
      const languages = disclose ? await db.employeeLanguage.findMany({ where: { employeeId: e.id, languageId: { in: [input.languageId, ...input.alternativeLanguageIds] }, language: { active: true } } }) : [];
      const primary = languages.find((l) => l.languageId === input.languageId);
      const best = primary && levels[primary.level] >= 4 ? primary : languages.sort((a, b) => levels[b.level] - levels[a.level])[0];
      const score = best ? levels[best.level] : 0;
      candidates.push({ employeeId: e.id, name: `${e.firstName} ${e.lastName}`, score, primary: !!best && best.languageId === input.languageId, level: best?.level ?? null, recommendation: disclose ? languageRecommendation(score) : "Sprachprüfung erfordert gesonderte Berechtigung" });
    }
    candidates.sort((a, b) => Number(b.primary && b.score >= 4) - Number(a.primary && a.score >= 4) || b.score - a.score);
    results.push({ id: w.id, name: w.name, roomId: w.roomId, trade: w.trade.name, safetyRequirements: w.safetyRequirements, maxVisitors: Math.min(w.maxVisitors, w.room.capacity), candidates, available: candidates.length > 0, external: "Externe FM-Verfügbarkeit ungeprüft" });
  }
  return results.sort((a, b) => Number(b.available) - Number(a.available) || Number(!!b.candidates[0]?.primary && b.candidates[0].score >= 4) - Number(!!a.candidates[0]?.primary && a.candidates[0].score >= 4) || (b.candidates[0]?.score ?? 0) - (a.candidates[0]?.score ?? 0));
}
