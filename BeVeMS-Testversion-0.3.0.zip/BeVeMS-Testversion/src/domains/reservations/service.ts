import { queueEvent } from "@/domains/notifications/queue";
import "server-only";
import { z } from "zod";
import { db } from "@/lib/db";
import type { Actor } from "@/domains/identity/policy";
import { permitted } from "@/domains/identity/policy";
import { audit, DomainError, eventMutation, instant, notes, text, timeRange, uuid, type Tx } from "@/domains/planning/shared";
import { roomAvailability } from "@/domains/integrations/rooms";
export const reservationInput = z.object({ roomId: uuid, start: instant, end: instant, visitors: z.coerce.number().int().min(1).max(100000), setupMinutes: z.coerce.number().int().min(0).max(1440).default(0), teardownMinutes: z.coerce.number().int().min(0).max(1440).default(0), instructorIds: z.array(uuid).max(30).default([]), overrideReason: notes, status: z.enum(["TENTATIVE", "CONFIRMED"]).default("TENTATIVE"), localOnlyAcknowledged: z.boolean().default(false) });
export type Conflict = { code: string; resourceId: string; hard: boolean; message: string };
export class ConflictError extends DomainError { constructor(public conflicts: Conflict[]) { super(conflicts.map((c) => c.message).join(" ")); } }
const active = () => ({ status: { in: ["TENTATIVE", "CONFIRMED"] as ("TENTATIVE" | "CONFIRMED")[] }, OR: [{ expiresAt: null }, { expiresAt: { gt: new Date() } }, { status: "CONFIRMED" as const }] });
export async function findConflicts(tx: Tx, input: z.infer<typeof reservationInput>, ignoreId?: string) {
  const occupancyStart = new Date(+input.start - input.setupMinutes * 60000), occupancyEnd = new Date(+input.end + input.teardownMinutes * 60000);
  const room = await tx.room.findUnique({ where: { id: input.roomId }, include: { building: { include: { location: true } }, workshop_room: { include: { workshopEmployee_workshop: true } } } });
  const conflicts: Conflict[] = [];
  const push = (code: string, resourceId: string, hard: boolean, message: string) => conflicts.push({ code, resourceId, hard, message });
  if (!room || !room.active || !room.building.active || !room.building.location.active || room.workshop_room?.active === false) push("INACTIVE", input.roomId, true, "Ressource ist nicht aktiv.");
  if (room && input.visitors > Math.min(room.capacity, room.workshop_room?.maxVisitors ?? room.capacity)) push("CAPACITY", input.roomId, true, "Die Kapazität reicht nicht aus.");
  const overlap = { start: { lt: occupancyEnd }, end: { gt: occupancyStart } };
  for (const block of await tx.roomBlock.findMany({ where: { roomId: input.roomId, ...overlap } })) push("BLOCK", block.id, block.hard, "Der Raum ist im gewünschten Zeitraum gesperrt.");
  const bookings = await tx.reservation.findMany({ where: { roomId: input.roomId, ...active(), occupancyStart: { lt: occupancyEnd }, occupancyEnd: { gt: occupancyStart }, ...(ignoreId ? { id: { not: ignoreId } } : {}) }, select: { id: true } });
  for (const booking of bookings) push("ROOM_BUSY", booking.id, false, "Der Raum ist einschließlich Auf- und Abbauzeit bereits belegt.");
  if (room?.workshop_room && !input.instructorIds.length) push("INSTRUCTOR_REQUIRED", input.roomId, true, "Für die Werkstatt ist ein zuständiger Ausbilder erforderlich.");
  for (const employeeId of new Set(input.instructorIds)) {
    if (!await tx.employee.count({ where: { id: employeeId, active: true } })) push("INSTRUCTOR_INACTIVE", employeeId, true, "Ausbilder ist nicht aktiv.");
    if (room?.workshop_room && !room.workshop_room.workshopEmployee_workshop.some((e) => e.employeeId === employeeId)) push("INSTRUCTOR_UNASSIGNED", employeeId, true, "Ausbilder ist dieser Werkstatt nicht zugeordnet.");
    if (await tx.employeeUnavailability.count({ where: { employeeId, ...overlap } })) push("INSTRUCTOR_UNAVAILABLE", employeeId, true, "Ausbilder ist in diesem Zeitraum nicht verfügbar.");
    if (await tx.reservationInstructor.count({ where: { employeeId, reservation: { ...active(), occupancyStart: { lt: occupancyEnd }, occupancyEnd: { gt: occupancyStart }, ...(ignoreId ? { id: { not: ignoreId } } : {}) } } })) push("INSTRUCTOR_BUSY", employeeId, false, "Ausbilder ist bereits anderweitig eingeplant.");
  }
  return { conflicts, room, occupancyStart, occupancyEnd };
}
export async function reserveRoom(actor: Actor, eventId: string, raw: unknown) {
  const input = reservationInput.parse(raw); timeRange(input.start, input.end);
  const external = await roomAvailability.check(input.roomId, input.start, input.end);
  if (external.state === "BUSY" || (input.status === "CONFIRMED" && external.state === "UNKNOWN" && !input.localOnlyAcknowledged)) throw new DomainError("Externe FM-Belegung ist unbekannt. Lokale Bestätigung muss ausdrücklich bestätigt werden; sie ersetzt keine FM-Freigabe.");
  return eventMutation(actor, eventId, "room.reserve", async (tx, event) => {
    if (["CANCELLED", "COMPLETED"].includes(event.status.code)) throw new DomainError("Für diesen Status kann nicht reserviert werden.");
    if (input.start < event.start || input.end > event.end) throw new DomainError("Die Besuchszeit muss innerhalb der Veranstaltung liegen.");
    // Transaction-level locks serialize both shared rooms and instructors, including cross-event races.
    for (const resource of [...new Set([`room:${input.roomId}`, ...input.instructorIds.map((id) => `employee:${id}`)])].sort()) await tx.$queryRaw`SELECT pg_advisory_xact_lock(hashtextextended(${resource}, 0))::text`;
    const { conflicts, room, occupancyStart, occupancyEnd } = await findConflicts(tx, input);
    if (!room || !event.eventLocation_event.some((l) => l.locationId === room.building.locationId)) throw new DomainError("Raum gehört nicht zum Veranstaltungsstandort.");
    if (conflicts.length && (conflicts.some((c) => c.hard) || !permitted(actor, "reservation.override", { ownerId: event.ownerId, locationIds: [room.building.locationId] }) || input.overrideReason.trim().length < 15)) throw new ConflictError(conflicts);
    const reservation = await tx.reservation.create({ data: { eventId, roomId: input.roomId, createdById: actor.id, start: input.start, end: input.end, setupMinutes: input.setupMinutes, teardownMinutes: input.teardownMinutes, occupancyStart, occupancyEnd, visitors: input.visitors, status: input.status, expiresAt: input.status === "TENTATIVE" ? new Date(Date.now() + 86400000) : null, externalCheckedAt: external.checkedAt, externalReference: external.state === "UNKNOWN" ? "LOCAL_ONLY_NOT_FM_CLEARED" : external.source, reservationInstructor_reservation: { create: [...new Set(input.instructorIds)].map((employeeId) => ({ employeeId })) } } });
    for (const c of conflicts) await tx.reservationOverride.create({ data: { reservationId: reservation.id, approvedById: actor.id, reason: input.overrideReason, conflictCode: c.code, conflictingResourceId: c.resourceId } });
    await audit(tx, actor, eventId, "reservation.created", "Reservation", reservation.id, { status: input.status, roomId: input.roomId, localOnly: external.state === "UNKNOWN", overrides: conflicts.map((c) => c.code) }); await queueEvent(tx, eventId, "Ressourcenreservierung angelegt."); return reservation.id;
  });
}
export async function cancelReservation(actor: Actor, eventId: string, id: string) {
  uuid.parse(id); return eventMutation(actor, eventId, "room.reserve", async (tx) => {
    const r = await tx.reservation.findFirst({ where: { id, eventId } }); if (!r) throw new DomainError("Reservierung nicht gefunden.");
    await tx.reservation.update({ where: { id }, data: { status: "CANCELLED" } }); await audit(tx, actor, eventId, "reservation.cancelled", "Reservation", id); await queueEvent(tx, eventId, "Ressourcenreservierung storniert.");
  });
}
export async function roomOptions() {
  return db.room.findMany({ where: { active: true, building: { active: true, location: { active: true } } }, include: { building: true, workshop_room: true }, orderBy: { name: "asc" } });
}
export async function confirmReservation(actor: Actor, eventId: string, id: string, acknowledge: boolean) {
  uuid.parse(id);
  if (!acknowledge) throw new DomainError("Bitte die außerhalb von BeVeMS geprüfte FM-Belegung ausdrücklich bestätigen.");
  return eventMutation(actor, eventId, "room.reserve", async (tx, event) => {
    const r = await tx.reservation.findFirst({ where: { id, eventId }, include: { reservationInstructor_reservation: true } });
    if (!r || r.status !== "TENTATIVE" || r.expiresAt && r.expiresAt < new Date()) throw new DomainError("Vormerkung ist nicht mehr gültig. Bitte neu buchen.");
    if (["COMPLETED", "CANCELLED"].includes(event.status.code)) throw new DomainError("Veranstaltung ist abgeschlossen.");
    const instructorIds = r.reservationInstructor_reservation.map((i) => i.employeeId);
    for (const resource of [...new Set([`room:${r.roomId}`, ...instructorIds.map((id) => `employee:${id}`)])].sort()) await tx.$queryRaw`SELECT pg_advisory_xact_lock(hashtextextended(${resource}, 0))::text`;
    const result = await findConflicts(tx, { roomId: r.roomId, start: r.start, end: r.end, visitors: r.visitors, setupMinutes: r.setupMinutes, teardownMinutes: r.teardownMinutes, instructorIds, status: "CONFIRMED", overrideReason: "", localOnlyAcknowledged: true }, r.id);
    // Existing soft overrides must be re-approved through a new reservation if a conflict persists.
    if (result.conflicts.length) throw new ConflictError(result.conflicts);
    await tx.reservation.update({ where: { id }, data: { status: "CONFIRMED", expiresAt: null, externalReference: "LOCAL_ONLY_NOT_FM_CLEARED" } });
    await audit(tx, actor, eventId, "reservation.confirmed", "Reservation", id, { localOnly: true }); await queueEvent(tx, eventId, "Ressourcenreservierung bestätigt.");
  });
}
