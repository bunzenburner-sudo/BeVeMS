import "server-only";
import { z } from "zod";
import { db } from "@/lib/db";
export const bootstrapInput = z.object({ tenantId: z.uuid(), subject: z.uuid(), firstName: z.string().trim().min(1).max(100), lastName: z.string().trim().min(1).max(100), email: z.email().max(254), locationName: z.string().trim().min(1).max(200), locationAddress: z.string().trim().min(1).max(500), unitName: z.string().trim().min(1).max(200) });
export async function bootstrapInstallation(raw: unknown) {
  const input = bootstrapInput.parse(raw);
  if (process.env.ALLOW_INITIAL_BOOTSTRAP !== "true") throw new Error("Initial bootstrap must be explicitly enabled.");
  return db.$transaction(async (tx) => {
    await tx.$queryRaw`SELECT pg_advisory_xact_lock(hashtextextended('bevems:initial-bootstrap', 0))::text`;
    if (await tx.user.count() || await tx.employee.count() || await tx.location.count()) throw new Error("Installation is not empty. Use normal administration/provisioning instead of bootstrap.");
    const codes = ["event.view", "event.view_sensitive", "event.create", "event.edit", "event.cancel", "event.delete", "room.reserve", "reservation.override", "task.edit", "employee.view", "employee.view_languages", "participant.view", "participant.export", "participant.checkin", "audit.view", "administration.manage", "location.view"];
    const admin = await tx.role.upsert({ where: { code: "admin" }, create: { code: "admin", name: "Administrator" }, update: { active: true } });
    for (const code of codes) { const p = await tx.permission.upsert({ where: { code }, create: { code, description: code }, update: {} }); await tx.rolePermission.upsert({ where: { roleId_permissionId_scope: { roleId: admin.id, permissionId: p.id, scope: "ALL" } }, create: { roleId: admin.id, permissionId: p.id, scope: "ALL" }, update: {} }); }
    const statusNames: Record<string, string> = { DRAFT: "Entwurf", PLANNING: "In Planung", CONFIRMED: "Bestätigt", PREPARATION: "In Vorbereitung", READY: "Bereit", IN_PROGRESS: "Läuft", COMPLETED: "Abgeschlossen", CANCELLED: "Abgesagt" };
    for (const [code, name] of Object.entries(statusNames)) await tx.eventStatus.upsert({ where: { code }, create: { code, name }, update: {} });
    const edit = await tx.permission.findUniqueOrThrow({ where: { code: "event.edit" } });
    const flow = ["DRAFT", "PLANNING", "CONFIRMED", "PREPARATION", "READY", "IN_PROGRESS", "COMPLETED"];
    for (let i = 1; i < flow.length; i++) { const from = await tx.eventStatus.findUniqueOrThrow({ where: { code: flow[i - 1] } }), to = await tx.eventStatus.findUniqueOrThrow({ where: { code: flow[i] } }); await tx.eventStatusTransition.upsert({ where: { fromId_toId: { fromId: from.id, toId: to.id } }, create: { fromId: from.id, toId: to.id, permissionId: edit.id }, update: {} }); }
    for (const [i, name] of ["Delegation", "Schulklasse", "Meisterfeier", "Freisprechungsfeier", "Nacht der Technik", "Workshop", "Politische Veranstaltung", "Seminar", "Messe", "Sonstige Veranstaltung"].entries()) await tx.eventType.upsert({ where: { code: `TYPE_${i}` }, create: { code: `TYPE_${i}`, name }, update: {} });
    for (const [i, name] of ["Konferenzraum", "Seminarraum", "Veranstaltungssaal", "Foyer", "Mensa", "Besprechungsraum", "Lehrwerkstatt", "Außenfläche", "Sonstiger Raum"].entries()) await tx.roomType.upsert({ where: { code: `ROOM_${i}` }, create: { code: `ROOM_${i}`, name }, update: {} });
    for (const [i, name] of ["Elektro", "SHK", "Tischler", "Metall", "Schweißen", "Kfz", "Maler und Lackierer", "Weitere Gewerke"].entries()) await tx.trade.upsert({ where: { code: `TRADE_${i}` }, create: { code: `TRADE_${i}`, name }, update: {} });
    for (const [code, name] of [["de", "Deutsch"], ["en", "Englisch"], ["fr", "Französisch"], ["es", "Spanisch"]]) await tx.language.upsert({ where: { code }, create: { code, name }, update: {} });
    for (const [i, name] of ["Parkplatz", "Mensa", "Foyer", "Zufahrt", "Raum", "Werkstatt", "Lärm", "Öffnungszeiten", "Sicherheit", "Besucheraufkommen"].entries()) await tx.impactCategory.upsert({ where: { code: `IMPACT_${i}` }, create: { code: `IMPACT_${i}`, name }, update: {} });
    for (const [i, name] of ["Mitarbeiter", "Politik", "Unternehmen", "Ehrenamt", "Delegation", "Schüler", "Presse", "Referent", "Begleitperson", "Sonstige"].entries()) await tx.participantCategory.upsert({ where: { code: `PARTICIPANT_${i}` }, create: { code: `PARTICIPANT_${i}`, name }, update: {} });
    for (const [i, name] of ["Empfang", "Mensa", "IT", "Hausmeister", "Technik", "Öffentlichkeitsarbeit", "Geschäftsführung", "Sicherheitsbeauftragte", "Ausbilder / Lehrwerkstätten"].entries()) await tx.responsibilityArea.upsert({ where: { code: `AREA_${i}` }, create: { code: `AREA_${i}`, name }, update: {} });
    const location = await tx.location.create({ data: { name: input.locationName, address: input.locationAddress } });
    const unit = await tx.organisationUnit.upsert({ where: { name: input.unitName }, create: { name: input.unitName }, update: { active: true } });
    const user = await tx.user.create({ data: { tenantId: input.tenantId.toLowerCase(), subject: input.subject.toLowerCase(), employee_user: { create: { firstName: input.firstName, lastName: input.lastName, email: input.email.toLowerCase(), locationId: location.id, unitId: unit.id } }, userRole_user: { create: { roleId: admin.id } } } });
    await tx.auditLog.create({ data: { actorId: user.id, action: "installation.bootstrapped", entityType: "User", entityId: user.id, changes: { role: "admin" } } });
    return { userId: user.id };
  }, { timeout: 30000 });
}
