import "server-only";
import { db } from "@/lib/db";
import { AccessError, permitted, type Actor } from "@/domains/identity/policy";

export async function administrationOverview(actor: Actor) {
  if (!permitted(actor, "administration.manage")) throw new AccessError(403);
  const [roles, types, statuses] = await Promise.all([
    db.role.findMany({ include: { rolePermission_role: { include: { permission: true } } }, orderBy: { name: "asc" } }),
    db.eventType.findMany({ orderBy: { name: "asc" } }),
    db.eventStatus.findMany(),
  ]);
  return { roles, types, statuses };
}
