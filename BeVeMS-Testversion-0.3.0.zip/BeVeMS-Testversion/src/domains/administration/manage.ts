import "server-only";
import { z } from "zod";
import { db } from "@/lib/db";
import type { Actor } from "@/domains/identity/policy";
import { audit, DomainError, requireRight, text, notes, uuid } from "@/domains/planning/shared";
export const catalogs = ["eventType", "roomType", "trade", "language", "impactCategory", "participantCategory", "responsibilityArea", "organisationUnit", "userGroup"] as const;
export async function manageRecord(actor: Actor, kind: string, id: string, raw: unknown) {
  requireRight(actor, "administration.manage"); if (id) uuid.parse(id);
  return db.$transaction(async (tx) => {
    // Match the same locks used by bookings before changing capacity, hierarchy or instructor availability.
    const roomIds = new Set<string>(); const employeeIds = new Set<string>();
    const values = raw as Record<string, unknown>;
    if (kind === "room" && id) roomIds.add(id);
    if (["roomBlock", "workshop"].includes(kind) && typeof values.roomId === "string") { uuid.parse(values.roomId); roomIds.add(values.roomId); }
    if (kind === "workshop" && id) { const w = await tx.workshop.findUnique({ where: { id } }); if (w) roomIds.add(w.roomId); }
    if (kind === "building" && id) for (const r of await tx.room.findMany({ where: { buildingId: id }, select: { id: true } })) roomIds.add(r.id);
    if (kind === "location" && id) for (const r of await tx.room.findMany({ where: { building: { locationId: id } }, select: { id: true } })) roomIds.add(r.id);
    if (kind === "employee" && id) employeeIds.add(id);
    for (const resource of [...[...roomIds].map((r) => `room:${r}`), ...[...employeeIds].map((e) => `employee:${e}`)].sort()) await tx.$queryRaw`SELECT pg_advisory_xact_lock(hashtextextended(${resource}, 0))::text`;
    if (["location", "building", "workshop", "employee"].includes(kind) && id && values.active === false) {
      const hasBookings = roomIds.size ? await tx.reservation.count({ where: { roomId: { in: [...roomIds] }, status: { in: ["TENTATIVE", "CONFIRMED"] } } }) : employeeIds.size ? await tx.reservationInstructor.count({ where: { employeeId: id, reservation: { status: { in: ["TENTATIVE", "CONFIRMED"] } } } }) : 0;
      if (hasBookings) throw new DomainError("Vor der Deaktivierung bitte aktive Buchungen stornieren.");
    }
    let entityId: string;
    if (catalogs.includes(kind as typeof catalogs[number])) {
      const isCode = !["organisationUnit", "userGroup"].includes(kind);
      const input = z.object({ name: text, code: text.regex(/^[A-Za-z0-9_-]+$/).optional(), active: z.boolean() }).parse(raw);
      const data = { name: input.name, active: input.active };
      const coded = { ...data, code: input.code || input.name.normalize("NFD").replace(/[\u0300-\u036f]/g, "").replace(/[^A-Za-z0-9]/g, "_").toUpperCase() };
      switch (kind) {
        case "eventType": entityId = (id ? await tx.eventType.update({ where: { id }, data: coded }) : await tx.eventType.create({ data: coded })).id; break;
        case "roomType": entityId = (id ? await tx.roomType.update({ where: { id }, data: coded }) : await tx.roomType.create({ data: coded })).id; break;
        case "trade": entityId = (id ? await tx.trade.update({ where: { id }, data: coded }) : await tx.trade.create({ data: coded })).id; break;
        case "language": entityId = (id ? await tx.language.update({ where: { id }, data: coded }) : await tx.language.create({ data: coded })).id; break;
        case "impactCategory": entityId = (id ? await tx.impactCategory.update({ where: { id }, data: coded }) : await tx.impactCategory.create({ data: coded })).id; break;
        case "participantCategory": entityId = (id ? await tx.participantCategory.update({ where: { id }, data: coded }) : await tx.participantCategory.create({ data: coded })).id; break;
        case "responsibilityArea": entityId = (id ? await tx.responsibilityArea.update({ where: { id }, data: coded }) : await tx.responsibilityArea.create({ data: coded })).id; break;
        case "organisationUnit": entityId = (id ? await tx.organisationUnit.update({ where: { id }, data }) : await tx.organisationUnit.create({ data })).id; break;
        case "userGroup": entityId = (id ? await tx.userGroup.update({ where: { id }, data }) : await tx.userGroup.create({ data })).id; break;
        default: throw new DomainError("Unbekannter Katalog.");
      }
    } else if (kind === "location") {
      const data = z.object({ name: text, address: text, description: notes, active: z.boolean() }).parse(raw);
      entityId = (id ? await tx.location.update({ where: { id }, data }) : await tx.location.create({ data })).id;
    } else if (kind === "building") {
      const data = z.object({ name: text, shortCode: text, locationId: uuid, description: notes, active: z.boolean() }).parse(raw);
      if (id && await tx.room.count({ where: { buildingId: id, reservation_room: { some: { status: { in: ["TENTATIVE", "CONFIRMED"] } } } } })) {
        const existing = await tx.building.findUniqueOrThrow({ where: { id } }); if (existing.locationId !== data.locationId) throw new DomainError("Gebäude mit Buchungen darf nicht verschoben werden.");
      }
      entityId = (id ? await tx.building.update({ where: { id }, data }) : await tx.building.create({ data })).id;
    } else if (kind === "room") {
      const data = z.object({ name: text, code: text, buildingId: uuid, typeId: uuid, capacity: z.coerce.number().int().min(1).max(100000), floor: notes, technicalNotes: notes, accessible: z.boolean(), active: z.boolean() }).parse(raw);
      if (id && await tx.reservation.count({ where: { roomId: id, status: { in: ["TENTATIVE", "CONFIRMED"] } } })) {
        const old = await tx.room.findUniqueOrThrow({ where: { id } }); if (old.buildingId !== data.buildingId || old.capacity !== data.capacity || !data.active) throw new DomainError("Gebuchte Räume erst nach Stornierung verschieben, verkleinern oder deaktivieren.");
      }
      entityId = (id ? await tx.room.update({ where: { id }, data }) : await tx.room.create({ data })).id;
    } else if (kind === "workshop") {
      const data = z.object({ name: text, roomId: uuid, tradeId: uuid, description: notes, maxVisitors: z.coerce.number().int().min(1).max(100000), defaultDurationMinutes: z.coerce.number().int().min(1).max(1440), safetyRequirements: notes, demonstrations: notes, active: z.boolean() }).parse(raw);
      if (id && await tx.reservation.count({ where: { roomId: { in: [...roomIds] }, status: { in: ["TENTATIVE", "CONFIRMED"] } } })) {
        const old = await tx.workshop.findUniqueOrThrow({ where: { id } });
        if (old.roomId !== data.roomId || old.maxVisitors !== data.maxVisitors) throw new DomainError("Gebuchte Werkstätten erst nach Stornierung verschieben oder Kapazität ändern.");
      }
      entityId = (id ? await tx.workshop.update({ where: { id }, data }) : await tx.workshop.create({ data })).id;
    } else if (kind === "employee") {
      const data = z.object({ firstName: text, lastName: text, email: z.email().max(254), function: notes, locationId: uuid, unitId: uuid, active: z.boolean() }).parse(raw);
      entityId = (id ? await tx.employee.update({ where: { id }, data }) : await tx.employee.create({ data })).id;
    } else if (kind === "employeeLanguage") {
      const data = z.object({ employeeId: uuid, languageId: uuid, level: z.enum(["A1", "A2", "B1", "B2", "C1", "C2", "NATIVE"]) }).parse(raw);
      entityId = (await tx.employeeLanguage.upsert({ where: { employeeId_languageId: { employeeId: data.employeeId, languageId: data.languageId } }, create: data, update: { level: data.level } })).id;
    } else if (kind === "workshopEmployee") {
      const data = z.object({ workshopId: uuid, employeeId: uuid }).parse(raw);
      entityId = (await tx.workshopEmployee.upsert({ where: { workshopId_employeeId: data }, create: data, update: {} })).id;
    } else if (kind === "roomBlock") {
      const data = z.object({ roomId: uuid, start: z.iso.datetime({ offset: true }).transform((s) => new Date(s)), end: z.iso.datetime({ offset: true }).transform((s) => new Date(s)), reason: text }).parse(raw);
      if (data.end <= data.start) throw new DomainError("Ungültiger Sperrzeitraum.");
      await tx.$queryRaw`SELECT pg_advisory_xact_lock(hashtextextended(${'room:' + data.roomId}, 0))::text`;
      if (await tx.reservation.count({ where: { roomId: data.roomId, status: { in: ["TENTATIVE", "CONFIRMED"] }, occupancyStart: { lt: data.end }, occupancyEnd: { gt: data.start } } })) throw new DomainError("Im Sperrzeitraum bestehen noch aktive Buchungen. Diese zuerst klären und stornieren.");
      entityId = (await tx.roomBlock.create({ data: { ...data, hard: true } })).id;
    } else throw new DomainError("Unbekannter Datensatztyp.");
    if (["employee", "location", "organisationUnit"].includes(kind) && !await tx.userRole.count({ where: { locationId: null, user: { active: true, employee_user: { active: true, location: { active: true }, unit: { active: true } } }, role: { active: true, rolePermission_role: { some: { scope: "ALL", permission: { code: "administration.manage" } } } } } })) throw new DomainError("Mindestens eine aktive globale Administration muss erhalten bleiben.");
    await audit(tx, actor, null, "administration.saved", kind, entityId);
    return entityId;
  });
}
export async function manageRole(actor: Actor, raw: unknown, grantValues: string[]) {
  requireRight(actor, "administration.manage");
  const input = z.object({ id: z.union([uuid, z.literal("")]), code: text.regex(/^[A-Za-z0-9_-]+$/), name: text, active: z.enum(["on", ""]).transform((v) => v === "on").default(false) }).parse(raw);
  const grants = z.array(z.string().max(100)).max(500).parse(grantValues).map((v) => { const [permissionId, scope] = v.split(":"); return { permissionId: uuid.parse(permissionId), scope: z.enum(["ALL", "OWN", "LOCATION", "ASSIGNED"]).parse(scope) }; });
  return db.$transaction(async (tx) => {
    await tx.$queryRaw`SELECT pg_advisory_xact_lock(hashtextextended('administration:roles', 0))::text`;
    const { id, ...data } = input;
    const role = id ? await tx.role.update({ where: { id }, data }) : await tx.role.create({ data });
    await tx.rolePermission.deleteMany({ where: { roleId: role.id } });
    await tx.rolePermission.createMany({ data: grants.map((g) => ({ ...g, roleId: role.id })), skipDuplicates: true });
    if (!await tx.userRole.count({ where: { locationId: null, user: { active: true, employee_user: { active: true, location: { active: true }, unit: { active: true } } }, role: { active: true, rolePermission_role: { some: { scope: "ALL", permission: { code: "administration.manage" } } } } } })) throw new DomainError("Mindestens eine aktive globale Administration muss erhalten bleiben.");
    await audit(tx, actor, null, "role.updated", "Role", role.id, { grants: grants.length });
  });
}
