"use client";
import { useState } from "react";
import { berlinInput, berlinToIso } from "@/lib/dates";
export function DateField({ name, label, value, required = true }: { name: string; label: string; value?: string; required?: boolean }) {
  const [local, setLocal] = useState(value ? berlinInput(value) : "");
  const iso = berlinToIso(local);
  return <label>{label} <small>(Europe/Berlin)</small><input type="datetime-local" value={local} required={required} onChange={(e) => { setLocal(e.target.value); e.target.setCustomValidity(e.target.value && !berlinToIso(e.target.value) ? "Zeit bei Sommerzeitumstellung ist nicht eindeutig oder existiert nicht." : ""); }} /><input type="hidden" name={name} value={iso} />{local && !iso && <span className="form-error">Bitte eine eindeutige gültige Uhrzeit wählen.</span>}</label>;
}
