import Link from "next/link";
import { MapPin, Clock, ArrowUpRight } from "lucide-react";
import type { listEvents } from "@/domains/events/service";
export type EventSummary = Awaited<ReturnType<typeof listEvents>>[number];
export function EventCard({ event }: { event: EventSummary }) {
  const day = new Intl.DateTimeFormat("de-DE", { day: "2-digit", timeZone: event.timeZone }).format(event.start);
  const month = new Intl.DateTimeFormat("de-DE", { month: "short", timeZone: event.timeZone }).format(event.start);
  const time = new Intl.DateTimeFormat("de-DE", { hour: "2-digit", minute: "2-digit", timeZone: event.timeZone });
  return <Link href={`/events/${event.id}`} className="event-card"><div className="date-block"><strong>{day}</strong><span>{month}</span></div><div className="event-main"><div className="event-meta"><span className="type-label">{event.type.name}</span><span className={`status status-${event.status.code.toLowerCase()}`}>{event.status.name}</span></div><h3>{event.title}</h3><div className="event-facts"><span><Clock size={14} />{time.format(event.start)} – {time.format(event.end)}</span><span><MapPin size={14} />{event.eventLocation_event.map((location) => location.location.name).join(", ") || "Ort noch offen"}</span></div></div><ArrowUpRight size={20} className="muted" /></Link>;
}
