"use client";
import { useActionState, useEffect, useRef, useState } from "react";
import { useRouter } from "next/navigation";
import { mutate, type ActionResult } from "@/app/actions";
import { DateField } from "./date-field";
import { Field, Select, Notes } from "./fields";
import type { planningOptions } from "@/domains/planning/events";
type Options = Awaited<ReturnType<typeof planningOptions>>;
const steps = ["Was findet statt?", "Wann?", "Wo?", "Wer kommt?", "Wer organisiert?", "Vorbereitung", "Auswirkungen", "Kommunikation", "Zusammenfassung"];
export function EventWizard({ options, actorId }: { options: Options; actorId: string }) {
  const [step, setStep] = useState(0), [summary, setSummary] = useState<Record<string, string>>({});
  const [state, action, pending] = useActionState<ActionResult, FormData>(mutate, {});
  const ref = useRef<HTMLFormElement>(null), router = useRouter();
  useEffect(() => { if (state.href) router.push(state.href); }, [state.href, router]);
  const next = () => {
    const inputs = ref.current?.querySelectorAll<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>(`fieldset[data-step="${step}"] input,fieldset[data-step="${step}"] select,fieldset[data-step="${step}"] textarea`);
    if (inputs && [...inputs].some((el) => !el.reportValidity())) return;
    if (ref.current) setSummary(Object.fromEntries([...new FormData(ref.current)].map(([k, v]) => [k, String(v)])));
    setStep((s) => Math.min(s + 1, 8));
  };
  const employeeRows = options.employees.map((e) => ({ id: e.id, name: `${e.firstName} ${e.lastName}` }));
  return <form ref={ref} action={action} className="panel editor-form" onSubmit={(e) => { if (step !== 8) { e.preventDefault(); next(); } }}>
    <input type="hidden" name="operation" value="event.create" /><ol className="wizard-steps" aria-label="Planungsschritte">{steps.map((label, i) => <li key={label} aria-current={step === i ? "step" : undefined}>{i + 1}. {label}</li>)}</ol>
    <fieldset hidden={step !== 0} data-step={0}><legend>1. Was findet statt?</legend><Field label="Titel" name="title" required maxLength={300} /><Select label="Veranstaltungstyp" name="typeId" rows={options.types} /><Select label="Teilnehmerstruktur" name="structure" rows={[{ id: "EXTERNAL", name: "Extern" }, { id: "INTERNAL", name: "Intern" }, { id: "MIXED", name: "Gemischt" }]} /><Notes label="Beschreibung" name="description" /></fieldset>
    <fieldset hidden={step !== 1} data-step={1}><legend>2. Wann?</legend><DateField label="Beginn" name="start" /><DateField label="Ende" name="end" /><p>Serientermine können nach der Anlage aus dem geprüften Veranstaltungsentwurf erzeugt werden.</p></fieldset>
    <fieldset hidden={step !== 2} data-step={2}><legend>3. Wo?</legend><Select label="Standort" name="locationId" rows={options.locations} /><p className="notice">Räume und Werkstätten buchen Sie im nächsten Planungsschritt am gespeicherten Entwurf. Dort erfolgt die verbindliche Konfliktprüfung einschließlich Ausbildern und Pufferzeiten.</p></fieldset>
    <fieldset hidden={step !== 3} data-step={3}><legend>4. Wer kommt?</legend><Field label="Erwartete Teilnehmerzahl" name="participantCount" type="number" min={0} max={100000} value={0} required /><Field label="Herkunftsland" name="country" /><Select label="Hauptsprache" name="languageId" rows={options.languages} optional /><Select label="Gewünschte Gewerke" name="tradeIds" rows={options.trades} multiple optional /><p>Organisationen, Teilnehmergruppen und Einzelpersonen verwalten Sie am Entwurf. Werkstattvorschläge stehen unter „Werkstattsuche“ bereit.</p></fieldset>
    <fieldset hidden={step !== 4} data-step={4}><legend>5. Wer organisiert?</legend><Select label="Hauptverantwortung" name="ownerId" rows={employeeRows} value={actorId} /><p>Teilverantwortungen können nach der Anlage nach Bereichen zugeordnet werden.</p></fieldset>
    <fieldset hidden={step !== 5} data-step={5}><legend>6. Was muss vorbereitet werden?</legend><Field label="Erste Aufgabe (optional)" name="initialTask" maxLength={300} /><p>Die erste Aufgabe wird der Hauptverantwortung zugewiesen. Weitere Aufgaben und Vorlagen stehen in der Planung zur Verfügung.</p></fieldset>
    <fieldset hidden={step !== 6} data-step={6}><legend>7. Auswirkungen auf den Betrieb</legend><Field label="Erster betrieblicher Hinweis (optional)" name="initialImpact" maxLength={300} /><p>Der Hinweis gilt für den Veranstaltungszeitraum. Weitere Kategorien, Zeiträume und Zielgruppen können Sie anschließend ergänzen.</p></fieldset>
    <fieldset hidden={step !== 7} data-step={7}><legend>8. Kommunikation</legend><Notes label="Weitere E-Mail-Empfänger (eine Adresse je Zeile)" name="initialRecipients" /><Select label="Sichtbarkeit" name="visibility" value="INVOLVED" rows={[{ id: "INVOLVED", name: "Nur Beteiligte" }, { id: "ALL_EMPLOYEES", name: "Alle Mitarbeiter" }, { id: "LOCATIONS", name: "Eigener Veranstaltungsstandort" }]} /><p>Benachrichtigungen werden intern angelegt und für den Versand vorgemerkt. Ohne eingerichteten Versanddienst wird keine E-Mail versendet.</p></fieldset>
    <fieldset hidden={step !== 8} data-step={8}><legend>9. Zusammenfassung</legend><dl className="detail-grid"><div><dt>Veranstaltung</dt><dd>{summary.title}</dd></div><div><dt>Beginn</dt><dd>{summary.start ? new Date(summary.start).toLocaleString("de-DE", { timeZone: "Europe/Berlin" }) : "Fehlt"}</dd></div><div><dt>Ende</dt><dd>{summary.end ? new Date(summary.end).toLocaleString("de-DE", { timeZone: "Europe/Berlin" }) : "Fehlt"}</dd></div><div><dt>Standort</dt><dd>{options.locations.find((l) => l.id === summary.locationId)?.name}</dd></div><div><dt>Teilnehmerzahl</dt><dd>{summary.participantCount}</dd></div><div><dt>Verantwortung</dt><dd>{employeeRows.find((e) => e.id === summary.ownerId)?.name}</dd></div><div><dt>Erste Aufgabe</dt><dd>{summary.initialTask || "Noch keine"}</dd></div><div><dt>Betrieblicher Hinweis</dt><dd>{summary.initialImpact || "Noch keiner"}</dd></div></dl><p className="notice">Die Veranstaltung wird als Entwurf gespeichert. Räume sind noch nicht reserviert. Prüfen Sie danach Reservierungen, Verantwortlichkeiten und Kommunikation, bevor Sie den Status bestätigen.</p></fieldset>
    {state.error && <p role="alert" className="form-error">{state.error}</p>}<div className="toolbar">{step > 0 && <button type="button" className="secondary-button" onClick={() => setStep(step - 1)}>Zurück</button>}{step < 8 ? <button key="next" className="button" type="button" onClick={(e) => { e.preventDefault(); next(); }}>Weiter</button> : <button key="submit" type="submit" className="button" disabled={pending}>{pending ? "Wird angelegt …" : "Entwurf anlegen"}</button>}</div>
  </form>;
}
