"use client";
import { useEffect, useState } from "react";
export function QrDisplay({ eventId, token }: { eventId: string; token: string }) {
  const [image, setImage] = useState(""), [error, setError] = useState(false);
  useEffect(() => { let address = "", active = true; const controller = new AbortController();
    fetch(`/api/events/${eventId}/qr`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ token }), signal: controller.signal }).then(async (r) => { if (!r.ok) { if (active) setError(true); return; } const blob = await r.blob(); if (active) { address = URL.createObjectURL(blob); setImage(address); } }).catch(() => { if (active) setError(true); });
    return () => { active = false; controller.abort(); if (address) URL.revokeObjectURL(address); };
  }, [eventId, token]);
  return <div className="notice"><p>Einmalige Ausgabe. Eine neue Ausgabe macht den alten Code ungültig.</p>{image ? <><img src={image} alt="QR-Code für den Check-in" width={240} height={240} /><p><a className="secondary-button" download="checkin.svg" href={image}>QR-Code speichern</a></p></> : <p role="status">{error ? "QR-Code konnte nicht geladen werden. Bitte erneut ausgeben." : "QR-Code wird erstellt …"}</p>}<p>Scannerinhalt: <code>{token}</code></p></div>;
}
