"use client";
import { useActionState, useEffect } from "react";
import { useRouter } from "next/navigation";
import { QrDisplay } from "./qr-display";
import { mutate, type ActionResult } from "@/app/actions";
export function MutationForm({ operation, eventId, children, submit = "Speichern", className = "editor-form" }: { operation: string; eventId?: string; children?: React.ReactNode; submit?: string; className?: string }) {
  const [state, action, pending] = useActionState<ActionResult, FormData>(mutate, {});
  const router = useRouter();
  useEffect(() => { if (state.href) router.push(state.href); }, [state.href, router]);
  return <form action={action} className={className}><input type="hidden" name="operation" value={operation} />{eventId && <input type="hidden" name="eventId" value={eventId} />}{children}<button className="button" disabled={pending}>{pending ? "Wird gespeichert …" : submit}</button>{state.error && <p role="alert" className="form-error">{state.error}</p>}{state.success && <p role="status" className="form-success">{state.success}</p>}{state.token && eventId && <QrDisplay eventId={eventId} token={state.token} />}{state.suggestions && <div className="suggestions">{state.suggestions.map((w) => <article className="resource-card" key={w.id}><h3>{w.name} · {w.trade}</h3><p>{w.available ? "Lokal verfügbar" : "Keine passende freie Betreuung / Kapazität"} · bis {w.maxVisitors} Gäste</p><p>{w.safetyRequirements}</p>{w.candidates.map((e) => <p key={e.employeeId}>{e.name}: {e.recommendation}{e.level ? ` (${e.level}${e.primary ? ", Hauptsprache" : ", Alternativsprache"})` : ""}</p>)}<small>{w.external}</small></article>)}</div>}</form>;
}
