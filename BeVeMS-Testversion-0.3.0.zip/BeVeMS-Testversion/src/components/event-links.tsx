import Link from "next/link";
import { permitted, type Actor, type Context } from "@/domains/identity/policy";
export function EventLinks({ id, actor, context = {}, showPlan = true }: { id: string; actor: Actor; context?: Context; showPlan?: boolean }) {
  return <nav className="tab-links" aria-label="Veranstaltungsbereiche"><Link href={`/events/${id}`}>Übersicht</Link>{showPlan && <Link href={`/events/${id}/plan`}>Planung & Ressourcen</Link>}{permitted(actor, "participant.view", context) && <Link href={`/events/${id}/participants`}>Teilnehmer</Link>}{permitted(actor, "event.edit", context) && <Link href={`/events/${id}/documents`}>Dokumente</Link>}{permitted(actor, "audit.view", context) && <Link href={`/events/${id}/history`}>Historie & Nachbereitung</Link>}</nav>;
}
