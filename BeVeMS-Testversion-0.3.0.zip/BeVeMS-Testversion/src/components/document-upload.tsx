"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";
export function DocumentUpload({ eventId }: { eventId: string }) {
  const [message, setMessage] = useState(""), [pending, setPending] = useState(false), router = useRouter();
  return <form className="editor-form" onSubmit={async (e) => { e.preventDefault(); const form = e.currentTarget; setPending(true); setMessage(""); try { const r = await fetch(`/api/events/${eventId}/documents`, { method: "POST", body: new FormData(form) }); const result = await r.json(); setMessage(r.ok ? "Hochgeladen. Die Datei wird nach bestandener Sicherheitsprüfung freigegeben." : result.error); if (r.ok) { form.reset(); router.refresh(); } } catch { setMessage("Upload fehlgeschlagen. Bitte erneut versuchen."); } finally { setPending(false); } }}><label>Dokument (PDF, PNG, JPEG oder Text, maximal 10 MiB)<input name="file" type="file" accept=".pdf,.png,.jpg,.jpeg,.txt" required /></label><button className="button" disabled={pending}>Dokument hochladen</button>{message && <p role="status">{message}</p>}</form>;
}
