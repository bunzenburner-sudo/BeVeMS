export function Field({ label, name, type = "text", value, required = false, ...props }: { label: string; name: string; type?: string; value?: string | number; required?: boolean; min?: number; max?: number; maxLength?: number }) {
  return <label>{label}<input name={name} type={type} defaultValue={value} required={required} {...props} /></label>;
}
export function Select({ label, name, rows, value, optional = false, multiple = false }: { label: string; name: string; rows: { id: string; name: string }[]; value?: string | string[]; optional?: boolean; multiple?: boolean }) {
  return <label>{label}<select key={Array.isArray(value) ? value.join(":") : value} name={name} defaultValue={value} multiple={multiple} required={!optional}>{optional && !multiple && <option value="">Bitte wählen / keine</option>}{rows.map((r) => <option key={r.id} value={r.id}>{r.name}</option>)}</select>{multiple && <small>Mehrfachauswahl mit Strg / Cmd</small>}</label>;
}
export function Notes({ label, name, value = "", required = false }: { label: string; name: string; value?: string; required?: boolean }) { return <label>{label}<textarea name={name} defaultValue={value} maxLength={5000} rows={3} required={required} /></label>; }
export function Hidden({ name, value }: { name: string; value: string | number }) { return <input type="hidden" name={name} value={value} />; }
