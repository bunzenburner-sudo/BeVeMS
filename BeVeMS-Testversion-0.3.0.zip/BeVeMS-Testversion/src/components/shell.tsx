import Link from "next/link";
import { CalendarDays, House, MapPin, Users, Settings, ArrowUpRight } from "lucide-react";
import { hasPermission, type Actor } from "@/domains/identity/policy";
import { SignOutButton } from "./auth-controls";
import { NavLink } from "./nav-link";
export function Shell({ actor, children }: { actor: Actor; children: React.ReactNode }) {
  const environmentLabel = process.env.NODE_ENV === "development" && process.env.DEMO_AUTH_ENABLED === "true" ? "Demoumgebung" : "Interner Arbeitsbereich";
  const nav = [
    { href: "/", label: "Startseite", icon: House, permission: "event.view" },
    { href: "/search", label: "Suche", icon: House, permission: "event.view" },
    { href: "/events", label: "Veranstaltungen", icon: CalendarDays, permission: "event.view" },
    { href: "/calendar", label: "Kalender", icon: CalendarDays, permission: "event.view" },
    { href: "/tasks", label: "Meine Aufgaben", icon: House, permission: "task.edit" },
    { href: "/notifications", label: "Benachrichtigungen", icon: House, permission: "event.view" },
    { href: "/organisations", label: "Organisationen & Gäste", icon: Users, permission: "participant.view" },
    { href: "/workshops", label: "Werkstattsuche", icon: MapPin, permission: "event.edit" },
    { href: "/templates", label: "Vorlagen", icon: CalendarDays, permission: "event.create" },
    { href: "/history", label: "Historie", icon: CalendarDays, permission: "event.view" },
    { href: "/locations", label: "Orte & Ressourcen", icon: MapPin, permission: "location.view" },
    { href: "/employees", label: "Mitarbeiter", icon: Users, permission: "employee.view" },
    { href: "/administration", label: "Administration", icon: Settings, permission: "administration.manage" },
  ];
  return <div className="app-shell"><a className="skip-link" href="#main">Zum Inhalt</a><aside className="sidebar">
    <Link href="/" className="brand">HWK <span>Handwerkskammer<br />Koblenz</span></Link>
    <div className="app-name">BeVeMS <span>Veranstaltungen & Besuche</span></div>
    <p className="nav-label">ARBEITSBEREICH</p><nav aria-label="Hauptnavigation">{nav.filter((item) => hasPermission(actor, item.permission)).map(({ href, label, icon: Icon }) => <NavLink key={href} href={href}><Icon size={19} /><span>{label}</span><ArrowUpRight size={13} className="nav-arrow" /></NavLink>)}</nav>
    <div className="sidebar-footer"><span className="avatar">{actor.name.split(" ").map((s) => s[0]).slice(0, 2).join("")}</span><div><strong>{actor.name}</strong><small>Persönlicher Arbeitsbereich</small></div><SignOutButton /></div>
  </aside><div className="workspace"><header className="topbar"><span>Handwerkskammer Koblenz <span className="muted">/</span> Veranstaltungsmanagement</span><span className="foundation-badge">{environmentLabel}</span><span className="mobile-signout"><SignOutButton /></span></header><main id="main">{children}</main><footer className="page-footer">BeVeMS · Besondere Veranstaltungen. Gemeinsam organisiert.</footer></div></div>;
}
