"use client";
import { signIn, signOut } from "next-auth/react";
import { useState } from "react";

export function SignOutButton() { return <button className="quiet-button" onClick={() => signOut({ callbackUrl: "/login" })}>Abmelden</button>; }
export function LoginForm({ entra, demo }: { entra: boolean; demo: boolean }) {
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  return <div className="login-actions">
    {entra && <button className="button" disabled={busy} onClick={() => { setBusy(true); void signIn("azure-ad", { callbackUrl: "/" }); }}>Mit Microsoft anmelden <span aria-hidden>↗</span></button>}
    {demo && <form onSubmit={async (event) => {
      event.preventDefault(); setBusy(true); setError("");
      const values = new FormData(event.currentTarget);
      try {
        const result = await signIn("credentials", { profile: values.get("profile"), password: values.get("password"), redirect: false, callbackUrl: "/" });
        if (result?.ok) window.location.assign("/");
        else setError("Anmeldung fehlgeschlagen. Bitte Zugang und Profil prüfen.");
      } catch { setError("Anmeldung derzeit nicht möglich."); }
      finally { setBusy(false); }
    }}>
      <div className="notice">Lokale Entwicklung · ausschließlich fiktive Demo-Daten</div>
      <label htmlFor="profile">Demo-Profil</label>
      <select id="profile" name="profile"><option value="employee">Mitarbeiter</option><option value="organizer">Veranstaltungsmanagement</option><option value="admin">Administrator</option><option value="instructor">Ausbilder</option><option value="site">Standortverantwortlicher</option></select>
      <label htmlFor="password">Lokales Demo-Passwort</label>
      <input id="password" name="password" type="password" required autoComplete="current-password" maxLength={256} />
      <button className="button" disabled={busy}>{busy ? "Anmeldung läuft …" : "Demo öffnen"}</button>
      {error && <p className="error" role="alert">{error}</p>}
    </form>}
  </div>;
}
