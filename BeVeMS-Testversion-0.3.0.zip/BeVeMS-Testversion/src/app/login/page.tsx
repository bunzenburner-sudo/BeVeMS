import { identityConfig } from "@/domains/identity/config";
import { LoginForm } from "@/components/auth-controls";
import { CalendarDays, ShieldCheck } from "lucide-react";
export const dynamic = "force-dynamic";
export default async function LoginPage({ searchParams }: { searchParams: Promise<{ error?: string }> }) {
  const config = identityConfig();
  const { error } = await searchParams;
  return <main className="login-page"><section className="login-story">
    <div className="brand">HWK <span>Handwerkskammer<br />Koblenz</span></div>
    <div><p className="eyebrow light">VERANSTALTUNGEN & BESUCHE</p><h1>Besondere Momente.<br />Gemeinsam geplant.</h1><p>Ein Ort für Veranstaltungen, Räume und die Menschen, die alles möglich machen.</p></div>
    <small>BeVeMS · Veranstaltungs- & Besuchsmanagement</small>
  </section><section className="login-panel"><div className="login-box">
    <div className="icon-tile"><CalendarDays size={27} /></div><p className="eyebrow">WILLKOMMEN BEI BEVEMS</p><h2>Gut organisiert beginnt hier.</h2><p className="muted">Melden Sie sich an, um Veranstaltungen und betriebliche Informationen zu sehen.</p>
    {error && <p className="error" role="alert">Die Anmeldung wurde nicht abgeschlossen. Ihr Konto muss für BeVeMS freigeschaltet sein.</p>}
    <LoginForm entra={config.configured} demo={config.demo} />
    {!config.configured && !config.demo && <div className="notice">Die Anmeldung ist noch nicht eingerichtet. Bitte wenden Sie sich an die Administration.</div>}
    <p className="secure-note"><ShieldCheck size={17} /> Zugriff nur für freigeschaltete Benutzer</p>
  </div></section></main>;
}
