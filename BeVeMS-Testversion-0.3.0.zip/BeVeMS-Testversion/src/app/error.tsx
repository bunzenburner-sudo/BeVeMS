"use client";
export default function ErrorPage({ reset }: { reset: () => void }) { return <section className="panel"><h1>Das hat gerade nicht funktioniert.</h1><p>Bitte versuchen Sie es erneut. Falls der Fehler bleibt, wenden Sie sich an die Administration.</p><button className="button" onClick={reset}>Erneut versuchen</button></section>; }
