import Link from "next/link";
export default function NotFound() { return <main className="standalone-message"><h1>Seite nicht verfügbar</h1><p>Diese Seite existiert nicht oder ist für Sie nicht freigegeben.</p><Link className="button" href="/">Zur Startseite</Link></main>; }
