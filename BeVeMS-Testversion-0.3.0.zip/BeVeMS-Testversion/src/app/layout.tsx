import type { Metadata } from "next";
import "./globals.css";
export const metadata: Metadata = { title: { default: "BeVeMS · Handwerkskammer Koblenz", template: "%s · BeVeMS" }, description: "Besondere Veranstaltungen und Besuche gemeinsam organisieren." };
export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="de"><body>{children}</body></html>;
}
