import { db } from "@/lib/db";
import { pageActor, pageResult } from "@/lib/page-access";
import { requireRight } from "@/domains/planning/shared";
import { MutationForm } from "@/components/mutation-form";
import { Hidden } from "@/components/fields";
import { formatDate } from "@/lib/dates";
export default async function Delivery() {
  const actor = await pageActor(); await pageResult(async () => requireRight(actor, "administration.manage"));
  const rows = await db.outboxMessage.findMany({ select: { id: true, kind: true, state: true, attempts: true, lastErrorCode: true, createdAt: true }, orderBy: { createdAt: "desc" }, take: 100 });
  return <><h1>Versandprotokoll</h1><p className="notice">Vorgemerkte Nachrichten werden erst durch den freigeschalteten Versanddienst zugestellt. Bei unklarem Ausgang zuerst im Postfach nachsehen: erneuter Versand kann eine Nachricht doppelt zustellen.</p>{rows.map((m) => <article key={m.id} className="panel"><h2>{m.kind === "CALENDAR_SYNC" ? "Outlook-Abgleich" : "E-Mail-Benachrichtigung"} · {m.state}</h2><p>{formatDate(m.createdAt)} · {m.attempts} Versuche · {m.lastErrorCode ?? "Kein Fehler"}</p>{m.state === "FAILED" && <MutationForm operation="communication.retry" submit="Erneut zur Zustellung vormerken"><Hidden name="id" value={m.id} /><label className="check-label"><input name="confirmed" type="checkbox" />Unklaren Ausgang geprüft; mögliche Doppelzustellung bewusst freigeben</label></MutationForm>}</article>)}</>;
}
