import Link from "next/link";
import { db } from "@/lib/db";
import { pageActor, pageResult } from "@/lib/page-access";
import { requireRight } from "@/domains/planning/shared";
import { AdminForm } from "@/components/admin-forms";
import { Field, Notes, Select } from "@/components/fields";
export default async function ResourceEditor({ searchParams }: { searchParams: Promise<{ kind?: string }> }) {
  const actor = await pageActor(); await pageResult(async () => requireRight(actor, "administration.manage"));
  const { kind = "location" } = await searchParams;
  const [locations, buildings, roomTypes, rooms, trades, units] = await Promise.all([db.location.findMany(), db.building.findMany(), db.roomType.findMany(), db.room.findMany(), db.trade.findMany(), db.organisationUnit.findMany()]);
  const rows = kind === "location" ? locations : kind === "building" ? buildings : kind === "room" ? rooms : kind === "workshop" ? await db.workshop.findMany() : kind === "employee" ? await db.employee.findMany() : [];
  return <><h1>Stammdaten bearbeiten</h1><nav className="tab-links">{[["location", "Standorte"], ["building", "Gebäude"], ["room", "Räume"], ["workshop", "Werkstätten"], ["employee", "Mitarbeiter"]].map(([k, label]) => <Link key={k} href={`/administration/resources?kind=${k}`}>{label}</Link>)}</nav><p>Einträge werden deaktiviert statt gelöscht, damit die Veranstaltungshistorie erhalten bleibt.</p>{rows.map((row) => {
    const r = row as unknown as Record<string, string | number | boolean | null>;
    const field = (name: string, label: string, type = "text") => <Field key={name} name={name} label={label} type={type} value={String(r[name] ?? "")} required={["name", "firstName", "lastName", "email", "capacity", "code", "shortCode", "address", "maxVisitors", "defaultDurationMinutes"].includes(name)} />;
    const select = (name: string, label: string, options: { id: string; name: string }[]) => <Select key={name} name={name} label={label} rows={options} value={String(r[name] ?? "")} />;
    const note = (name: string, label: string) => <Notes key={name} name={name} label={label} value={String(r[name] ?? "")} />;
    return <section className="panel" key={String(r.id)}><details><summary>{String(r.name ?? `${r.firstName} ${r.lastName}`)}{!r.active && " · inaktiv"}</summary><AdminForm kind={kind} id={String(r.id)} active={!!r.active}>
      {kind !== "employee" && field("name", "Name")}
      {kind === "location" && <>{field("address", "Adresse")}{note("description", "Beschreibung")}</>}
      {kind === "building" && <>{field("shortCode", "Kurzbezeichnung")}{select("locationId", "Standort", locations)}{note("description", "Beschreibung")}</>}
      {kind === "room" && <>{field("code", "Raumbezeichnung")}{select("buildingId", "Gebäude", buildings)}{select("typeId", "Raumtyp", roomTypes)}{field("floor", "Etage")}{field("capacity", "Kapazität", "number")}{note("technicalNotes", "Technische Hinweise")}<label className="check-label"><input name="accessible" type="checkbox" defaultChecked={!!r.accessible} />Barrierefrei</label></>}
      {kind === "workshop" && <>{select("roomId", "Raum", rooms)}{select("tradeId", "Gewerk", trades)}{field("maxVisitors", "Maximale Besucherzahl", "number")}{field("defaultDurationMinutes", "Standarddauer (Minuten)", "number")}{note("description", "Beschreibung")}{note("safetyRequirements", "Sicherheitsanforderungen")}{note("demonstrations", "Vorführungen / Specials")}</>}
      {kind === "employee" && <>{field("firstName", "Vorname")}{field("lastName", "Nachname")}{field("email", "E-Mail", "email")}{field("function", "Funktion")}{select("locationId", "Standort", locations)}{select("unitId", "Organisationseinheit", units)}</>}
    </AdminForm></details></section>;
  })}</>;
}
