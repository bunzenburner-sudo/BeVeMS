import Link from "next/link";
import { db } from "@/lib/db";
import { pageActor } from "@/lib/page-access";
import { visibleEventsWhere } from "@/domains/events/policy";
import { MutationForm } from "@/components/mutation-form";
import { Hidden, Select } from "@/components/fields";
import { formatDate } from "@/lib/dates";
export default async function Tasks() {
  const actor = await pageActor();
  const tasks = await db.eventTask.findMany({ where: { assigneeId: actor.employeeId, event: visibleEventsWhere(actor) }, include: { event: { select: { title: true } } }, orderBy: [{ status: "asc" }, { dueAt: "asc" }], take: 200 });
  return <><h1>Meine Aufgaben</h1><div className="resource-grid">{tasks.map((t) => <article className="panel" key={t.id}><h2>{t.critical && "⚠ "}{t.title}</h2><Link href={`/events/${t.eventId}/plan`}>{t.event.title}</Link><p>{t.dueAt ? formatDate(t.dueAt) : "Keine Frist"}{t.dueAt && t.dueAt < new Date() && t.status !== "DONE" ? " · Überfällig" : ""}</p><MutationForm operation="task.status" eventId={t.eventId}><Hidden name="id" value={t.id} /><Select label="Status" name="status" value={t.status} rows={[{ id: "OPEN", name: "Offen" }, { id: "IN_PROGRESS", name: "In Arbeit" }, { id: "DONE", name: "Erledigt" }]} /></MutationForm></article>)}</div>{!tasks.length && <p className="empty-state">Keine Aufgaben zugewiesen.</p>}</>;
}
