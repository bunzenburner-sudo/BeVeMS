import { db } from "@/lib/db";
import { pageActor, pageResult } from "@/lib/page-access";
import { requireRight } from "@/domains/planning/shared";
import { MutationForm } from "@/components/mutation-form";
import { Hidden } from "@/components/fields";
import { DateField } from "@/components/date-field";
export default async function Templates() { const actor = await pageActor(); await pageResult(async () => requireRight(actor, "event.create")); const rows = await db.eventTemplate.findMany({ where: { active: true, ...(actor.grants.some((g) => g.permission === "administration.manage" && g.scope === "ALL") ? {} : { OR: [{ ownerId: actor.employeeId }, { shared: true }] }) }, select: { id: true, name: true }, orderBy: { name: "asc" } }); return <><h1>Veranstaltungsvorlagen</h1><p>Vorlagen speichern Sie aus der Historie einer Veranstaltung. Neue Entwürfe müssen fachlich geprüft und Räume neu gebucht werden.</p>{rows.map((t) => <article className="panel" key={t.id}><h2>{t.name}</h2><MutationForm operation="template.use" submit="Entwurf aus Vorlage"><Hidden name="id" value={t.id} /><DateField name="start" label="Beginn" /></MutationForm></article>)}</>; }
