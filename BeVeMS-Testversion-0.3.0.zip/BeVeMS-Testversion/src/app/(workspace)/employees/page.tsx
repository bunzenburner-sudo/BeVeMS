import { listEmployees } from "@/domains/employees/service";
import { pageActor, pageResult } from "@/lib/page-access";
export default async function EmployeesPage() {
  const actor = await pageActor();
  const employees = await pageResult(() => listEmployees(actor));
  return <><div className="page-heading"><div><p className="eyebrow">MENSCHEN & ORGANISATION</p><h1>Mitarbeiter</h1><p className="muted">Verantwortliche und Ausbilder im freigegebenen Arbeitsbereich.</p></div></div><div className="resource-grid">{employees.map((employee) => <article className="panel employee-card" key={employee.id}><span className="avatar">{employee.firstName[0]}{employee.lastName[0]}</span><h2>{employee.firstName} {employee.lastName}</h2><p>{employee.function}</p><p className="muted">{employee.unit.name}<br />{employee.location.name}</p>{"languages" in employee && <div className="language-list">{employee.languages?.map((language) => <span className="count-badge" key={language.language.name}>{language.language.name} · {language.level === "NATIVE" ? "Muttersprache" : language.level}</span>)}</div>}</article>)}</div></>;
}
