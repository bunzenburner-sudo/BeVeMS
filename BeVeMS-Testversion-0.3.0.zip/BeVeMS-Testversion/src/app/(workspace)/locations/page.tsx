import { listLocations } from "@/domains/locations/service";
import { pageActor, pageResult } from "@/lib/page-access";
export default async function LocationsPage() {
  const actor = await pageActor();
  const locations = await pageResult(() => listLocations(actor));
  return <><div className="page-heading"><div><p className="eyebrow">ORTE & RESSOURCEN</p><h1>Raum für Ihre Veranstaltung.</h1><p className="muted">Standorte, Gebäude, Räume und Lehrwerkstätten.</p></div></div>{locations.map((location) => <section key={location.id} className="panel"><h2>{location.name}</h2><p className="muted">{location.address}</p>{location.building_location.map((building) => <div key={building.id} className="building"><h3>{building.name} <span className="muted">· {building.shortCode}</span></h3><div className="resource-grid">{building.room_building.map((room) => <article key={room.id} className="resource-card"><span className="type-label">{room.type.name}</span><h3>{room.name}</h3><p className="muted">{room.code} · {room.capacity} Plätze{room.accessible ? " · Barrierefrei" : ""}</p>{room.workshop_room && <p>{room.workshop_room.trade.name} · max. {room.workshop_room.maxVisitors} Besucher</p>}</article>)}</div></div>)}</section>)}</>;
}
