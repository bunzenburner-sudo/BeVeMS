import { EventLinks } from "@/components/event-links";
import { planningDetail } from "@/domains/planning/events";
import { formatDate } from "@/lib/dates";
import Link from "next/link";
import { eventDetail } from "@/domains/events/service";
import { pageActor, pageResult } from "@/lib/page-access";
export default async function EventPage({ params }: { params: Promise<{ id: string }> }) {
  const actor = await pageActor();
  const event = await pageResult(() => params.then(({ id }) => eventDetail(actor, id)));
  const planning = await planningDetail(actor, event.id);
  const format = new Intl.DateTimeFormat("de-DE", { dateStyle: "full", timeStyle: "short", timeZone: event.timeZone });
  return <><Link className="back-link" href="/events">← Alle Veranstaltungen</Link><div className="page-heading"><div><p className="eyebrow">{event.type.name}</p><h1>{event.title}</h1><p className="muted">{event.description}</p></div><span className="status">{event.status.name}</span></div><EventLinks id={event.id} actor={actor} context={planning.context} showPlan={planning.canEdit || planning.tasks.length > 0 || planning.reservations.length > 0} />{planning.impacts.map((i) => <aside className="notice" key={i.id}><strong>⚠ {i.category?.name ?? "Betrieblicher Hinweis"}</strong><p>{i.publicSummary}</p><small>{formatDate(i.start)} – {formatDate(i.end)}</small></aside>)}<section className="panel"><h2>Auf einen Blick</h2><dl className="detail-grid"><div><dt>Beginn</dt><dd>{format.format(event.start)}</dd></div><div><dt>Ende</dt><dd>{format.format(event.end)}</dd></div><div><dt>Standort</dt><dd>{event.eventLocation_event.map((row) => row.location.name).join(", ") || "Noch offen"}</dd></div><div><dt>Hauptverantwortung</dt><dd>{event.owner.firstName} {event.owner.lastName}</dd></div><div><dt>Teilnehmerzahl</dt><dd>{event.participantCount}</dd></div><div><dt>Teilnehmerstruktur</dt><dd>{{ INTERNAL: "Intern", EXTERNAL: "Extern", MIXED: "Gemischt" }[event.structure]}</dd></div></dl></section></>;
}
