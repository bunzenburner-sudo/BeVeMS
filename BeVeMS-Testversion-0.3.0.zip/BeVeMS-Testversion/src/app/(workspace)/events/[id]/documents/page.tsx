import { pageActor, pageResult } from "@/lib/page-access";
import { planningDetail } from "@/domains/planning/events";
import { documents } from "@/domains/documents/service";
import { EventLinks } from "@/components/event-links";
import { DocumentUpload } from "@/components/document-upload";
export default async function Documents({ params }: { params: Promise<{ id: string }> }) { const actor = await pageActor(), { id } = await params, rows = await pageResult(() => documents(actor, id)); const p = await planningDetail(actor, id); return <><h1>Veranstaltungsdokumente</h1><EventLinks id={id} actor={actor} context={p.context} /><section className="panel"><DocumentUpload eventId={id} /></section><section className="panel"><h2>Dokumente</h2>{rows.map((d) => <p key={d.id}>{d.scanStatus === "CLEAN" ? <a href={`/api/events/${id}/documents/${d.id}`}>{d.name} herunterladen</a> : <span>{d.name} · Sicherheitsprüfung ausstehend</span>} · {Math.ceil(d.sizeBytes / 1024)} KiB</p>)}{!rows.length && <p>Noch keine Dokumente.</p>}</section></>; }
