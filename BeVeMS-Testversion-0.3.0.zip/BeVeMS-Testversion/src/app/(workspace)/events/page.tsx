import Link from "next/link";
import { hasPermission } from "@/domains/identity/policy";
import { listEvents } from "@/domains/events/service";
import { pageActor } from "@/lib/page-access";
import { EventCard } from "@/components/event-card";
export default async function EventsPage({ searchParams }: { searchParams: Promise<{ q?: string }> }) {
  const actor = await pageActor();
  const params = await searchParams;
  const query = typeof params.q === "string" ? params.q.slice(0, 120) : "";
  const events = await listEvents(actor, query);
  return <><div className="page-heading"><div><p className="eyebrow">EVENTS & BEGEGNUNGEN</p><h1>Veranstaltungen</h1><p className="muted">Besondere Termine, externe Besuche und ihre Verantwortlichen.</p></div><span className="count-badge">{events.length} sichtbar</span></div><div className="toolbar"><Link className="secondary-button" href="/calendar">Kalender öffnen</Link>{hasPermission(actor, "event.create") && <Link className="button" href="/events/new">Neue Veranstaltung</Link>}</div><form className="search-form"><label className="sr-only" htmlFor="q">Veranstaltungen suchen</label><input id="q" name="q" placeholder="Nach Veranstaltung suchen …" defaultValue={query} maxLength={120} /><button className="button">Suchen</button></form><div className="event-list">{events.map((event) => <EventCard key={event.id} event={event} />)}{!events.length && <div className="empty-state">Keine passenden Veranstaltungen gefunden.</div>}</div></>;
}
