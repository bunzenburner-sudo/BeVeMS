import { pageActor, pageResult } from "@/lib/page-access";
import { planningOptions } from "@/domains/planning/events";
import { EventWizard } from "@/components/event-wizard";
export default async function NewEvent() { const actor = await pageActor(), options = await pageResult(() => planningOptions(actor)); return <><h1>Neue Veranstaltung</h1><p className="muted">Schritt für Schritt zum überprüfbaren Veranstaltungsentwurf.</p><EventWizard options={options} actorId={actor.employeeId} /></>; }
