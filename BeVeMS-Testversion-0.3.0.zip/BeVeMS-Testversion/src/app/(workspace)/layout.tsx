import { redirect } from "next/navigation";
import { currentActor } from "@/domains/identity/actor";
import { Shell } from "@/components/shell";
export const dynamic = "force-dynamic";
export default async function WorkspaceLayout({ children }: { children: React.ReactNode }) {
  const actor = await currentActor();
  if (!actor) redirect("/login");
  return <Shell actor={actor}>{children}</Shell>;
}
