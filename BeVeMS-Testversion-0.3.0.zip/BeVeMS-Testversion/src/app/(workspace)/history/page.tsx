import { db } from "@/lib/db";
import { pageActor } from "@/lib/page-access";
import { visibleEventsWhere } from "@/domains/events/policy";
import Link from "next/link";
import { formatDate } from "@/lib/dates";
export default async function History() { const actor = await pageActor(); const rows = await db.event.findMany({ where: { AND: [visibleEventsWhere(actor)], status: { code: "COMPLETED" } }, select: { id: true, title: true, start: true }, orderBy: { start: "desc" }, take: 200 }); return <><h1>Abgeschlossene Veranstaltungen</h1>{rows.map((e) => <Link className="event-card" href={`/events/${e.id}`} key={e.id}>{formatDate(e.start)} · {e.title}</Link>)}{!rows.length && <p>Noch keine abgeschlossenen Veranstaltungen sichtbar.</p>}</>; }
