import { dashboard } from "@/domains/planning/dashboard";
import { berlinInput } from "@/lib/dates";
import Link from "next/link";
import { ArrowRight, CalendarDays, MapPin, ShieldCheck } from "lucide-react";
import { pageActor } from "@/lib/page-access";
import { listEvents } from "@/domains/events/service";
import { EventCard } from "@/components/event-card";
export default async function HomePage() {
  const actor = await pageActor();
  const events = await listEvents(actor);
  const overview = await dashboard(actor);
  const today = events.filter((e) => berlinInput(e.start).slice(0, 10) <= overview.day && berlinInput(new Date(+e.end - 1)).slice(0, 10) >= overview.day && e.status.code !== "CANCELLED");
  const upcoming = events.filter((event) => event.end >= new Date() && event.status.code !== "CANCELLED");
  const date = new Intl.DateTimeFormat("de-DE", { weekday: "long", day: "numeric", month: "long", year: "numeric", timeZone: "Europe/Berlin" }).format(new Date());
  return <><div className="page-heading"><div><p className="eyebrow">GEMEINSAM DEN ÜBERBLICK BEHALTEN</p><h1>Willkommen, {actor.name.split(" ")[0]}.</h1><p className="muted">Besondere Veranstaltungen und Besuche auf einen Blick.</p></div><span className="today-label">{date}</span></div>
    <section className="welcome-banner"><div><span className="eyebrow light">RAUM FÜR BEGEGNUNGEN</span><h2>Was steht bei uns an?</h2><p>Entdecken Sie die kommenden Veranstaltungen und ihre Verantwortlichen.</p><Link href="/events">Alle Veranstaltungen <ArrowRight size={17} /></Link></div><CalendarDays size={100} strokeWidth={1} aria-hidden /></section>
    <section className="stats" aria-label="Übersicht"><article><CalendarDays /><div><strong>{upcoming.length}</strong><span>Kommende sichtbare Events</span></div></article><article><MapPin /><div><strong>{new Set(events.flatMap((event) => event.eventLocation_event.map((location) => location.location.id))).size}</strong><span>Beteiligte Standorte</span></div></article><article><ShieldCheck /><div><strong>Ihr Arbeitsbereich</strong><span>Informationen nach Ihren Rechten</span></div></article></section>
    <section className="panel"><h2>Heute bei uns</h2>{today.map((e) => <p key={e.id}><Link href={`/events/${e.id}`}>{e.title}</Link></p>)}{!today.length && <p>Heute keine besonderen Veranstaltungen in Ihrem Sichtbereich.</p>}</section>
    {!!overview.impacts.length && <section className="panel"><h2>Betriebliche Hinweise · diese Woche</h2>{overview.impacts.map((i) => <aside className="notice" key={i.id}><strong>⚠ {i.category?.name ?? "Hinweis"}</strong><p>{i.publicSummary}</p><Link href={`/events/${i.event.id}`}>{i.event.title}</Link></aside>)}</section>}
    <section className="panel"><h2>Für mich relevant</h2>{overview.relevant.map((e) => <p key={e.id}><Link href={`/events/${e.id}/plan`}>{e.title}</Link></p>)}{!overview.relevant.length && <p>Keine kommenden Beteiligungen.</p>}<Link className="secondary-button" href="/tasks">Meine Aufgaben ({overview.tasks.length} offen)</Link></section>
    {!!overview.organizing.length && <section className="panel"><h2>Planungsübersicht</h2>{overview.organizing.slice(0, 10).map((e) => { const tasks = e.eventTask_event, open = tasks.filter((t) => t.status !== "DONE"); return <article className="resource-card" key={e.id}><h3><Link href={`/events/${e.id}/plan`}>{e.title}</Link></h3><p>{tasks.length ? Math.round((tasks.length - open.length) / tasks.length * 100) + " % erledigt" : "Noch keine Aufgaben"} · {open.filter((t) => t.critical).length} kritisch · {open.filter((t) => t.dueAt && t.dueAt < new Date()).length} überfällig · {e.reservation_event.length} unbestätigte Reservierungen</p></article>; })}</section>}
    <div className="section-title"><div><h2>Kommende Veranstaltungen</h2><p className="muted">Die nächsten Begegnungen in der Handwerkskammer.</p></div><Link href="/events">Alle ansehen <ArrowRight size={16} /></Link></div>
    <div className="event-list">{upcoming.slice(0, 5).map((event) => <EventCard key={event.id} event={event} />)}{!upcoming.length && <div className="empty-state">Derzeit sind keine kommenden Veranstaltungen für Sie sichtbar.</div>}</div>
  </>;
}
