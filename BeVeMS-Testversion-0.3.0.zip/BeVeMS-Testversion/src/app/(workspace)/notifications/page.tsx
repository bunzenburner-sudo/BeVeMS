import Link from "next/link";
import { notifications } from "@/domains/notifications/service";
import { pageActor } from "@/lib/page-access";
import { MutationForm } from "@/components/mutation-form";
import { Hidden } from "@/components/fields";
import { formatDate } from "@/lib/dates";
export default async function Notifications() { const rows = await notifications(await pageActor()); return <><h1>Benachrichtigungen</h1>{rows.map((n) => <article className="panel" key={n.id}><h2>{n.eventId ? <Link href={`/events/${n.eventId}`}>{n.title}</Link> : n.title}</h2><p>{n.body}</p><small>{formatDate(n.createdAt)}</small>{!n.readAt && <MutationForm operation="notification.read" submit="Als gelesen markieren"><Hidden name="id" value={n.id} /></MutationForm>}</article>)}{!rows.length && <p>Keine Benachrichtigungen.</p>}</>; }
