import Link from "next/link";
import { db } from "@/lib/db";
import { visibleEventsWhere } from "@/domains/events/policy";
import { pageActor } from "@/lib/page-access";
import { berlinInput, berlinToIso, formatDate } from "@/lib/dates";
import { z } from "zod";
export default async function Calendar({ searchParams }: { searchParams: Promise<Record<string, string | undefined>> }) {
  const actor = await pageActor(), s = await searchParams;
  const day = /^\d{4}-\d{2}-\d{2}$/.test(s.date ?? "") && !Number.isNaN(Date.parse(`${s.date}T12:00:00Z`)) ? s.date! : berlinInput(new Date()).slice(0, 10);
  const view = ["day", "week", "month", "list"].includes(s.view ?? "") ? s.view! : "month";
  const pivot = new Date(`${day}T12:00:00Z`), first = new Date(pivot);
  if (view === "month") first.setUTCDate(1);
  else if (view === "week") first.setUTCDate(first.getUTCDate() - (first.getUTCDay() + 6) % 7);
  const count = view === "day" ? 1 : view === "week" ? 7 : view === "month" ? new Date(Date.UTC(pivot.getUTCFullYear(), pivot.getUTCMonth() + 1, 0)).getUTCDate() : 31;
  const days = Array.from({ length: count }, (_, i) => new Date(+first + i * 86400000).toISOString().slice(0, 10));
  const end = new Date(+first + count * 86400000).toISOString().slice(0, 10);
  const uuidFilter = (v?: string) => z.uuid().safeParse(v).success ? v : undefined;
  const events = await db.event.findMany({ where: { AND: [visibleEventsWhere(actor)], start: { lt: new Date(berlinToIso(`${end}T00:00`)) }, end: { gt: new Date(berlinToIso(`${days[0]}T00:00`)) }, typeId: uuidFilter(s.typeId), ownerId: uuidFilter(s.ownerId), statusId: uuidFilter(s.statusId), structure: ["INTERNAL", "EXTERNAL", "MIXED"].includes(s.structure ?? "") ? s.structure as "INTERNAL" | "EXTERNAL" | "MIXED" : undefined,
    ...(uuidFilter(s.locationId) ? { eventLocation_event: { some: { locationId: s.locationId } } } : {}),
    ...(uuidFilter(s.buildingId) ? { OR: [{ reservation_event: { some: { room: { buildingId: s.buildingId }, status: { in: ["TENTATIVE", "CONFIRMED"] } } } }, { eventScheduleItem_event: { some: { buildingId: s.buildingId } } }] } : {}),
  }, select: { id: true, title: true, start: true, end: true, status: { select: { name: true } } }, orderBy: { start: "asc" }, take: 1000 });
  const [locations, buildings, types, statuses, ownerEvents] = await Promise.all([db.location.findMany({ where: { active: true } }), db.building.findMany({ where: { active: true } }), db.eventType.findMany({ where: { active: true } }), db.eventStatus.findMany({ where: { active: true } }), db.event.findMany({ where: visibleEventsWhere(actor), distinct: ["ownerId"], select: { owner: { select: { id: true, firstName: true, lastName: true } } } })]);
  const owners = ownerEvents.map((e) => ({ id: e.owner.id, name: `${e.owner.firstName} ${e.owner.lastName}` }));
  return <><h1>Veranstaltungskalender</h1><form className="panel editor-form"><div className="form-grid"><label>Datum<input name="date" type="date" defaultValue={day} /></label><label>Ansicht<select name="view" defaultValue={view}><option value="day">Tag</option><option value="week">Woche</option><option value="month">Monat</option><option value="list">Liste (31 Tage)</option></select></label>{[["locationId", "Standort", locations], ["buildingId", "Gebäude", buildings], ["typeId", "Typ", types], ["statusId", "Status", statuses], ["ownerId", "Verantwortung", owners]].map(([name, label, rows]) => <label key={String(name)}>{String(label)}<select name={String(name)} defaultValue={s[String(name)] ?? ""}><option value="">Alle</option>{(rows as { id: string; name: string }[]).map((r) => <option key={r.id} value={r.id}>{r.name}</option>)}</select></label>)}<label>Teilnehmerstruktur<select name="structure" defaultValue={s.structure ?? ""}><option value="">Alle</option><option value="INTERNAL">Intern</option><option value="EXTERNAL">Extern</option><option value="MIXED">Gemischt</option></select></label></div><button className="button">Anzeigen</button></form>
  {view === "list" ? <div className="event-list">{events.map((e) => <Link className="event-card" key={e.id} href={`/events/${e.id}`}>{formatDate(e.start)} · {e.title} · {e.status.name}</Link>)}</div> : <div className="table-scroll"><div className={view === "day" ? "event-list" : "calendar-grid"}>{view === "month" && Array.from({ length: (first.getUTCDay() + 6) % 7 }, (_, i) => <div key={`empty-${i}`} />)}{days.map((date) => <section key={date} className="calendar-cell"><strong>{new Intl.DateTimeFormat("de-DE", { weekday: "short", day: "numeric", month: "short", timeZone: "UTC" }).format(new Date(`${date}T12:00Z`))}</strong>{events.filter((e) => berlinInput(e.start).slice(0, 10) <= date && berlinInput(new Date(+e.end - 1)).slice(0, 10) >= date).map((e) => <Link href={`/events/${e.id}`} key={e.id}>{e.title}<br /><small>{formatDate(e.start)} · {e.status.name}</small></Link>)}</section>)}</div></div>}{!events.length && <p className="empty-state">Keine sichtbaren Veranstaltungen im gewählten Zeitraum.</p>}</>;
}
