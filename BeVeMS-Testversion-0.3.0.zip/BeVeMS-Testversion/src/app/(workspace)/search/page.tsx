import Link from "next/link";
import { searchAll } from "@/domains/events/search";
import { pageActor } from "@/lib/page-access";
import { formatDate } from "@/lib/dates";
export default async function Search({ searchParams }: { searchParams: Promise<{ q?: string }> }) {
  const actor = await pageActor(), { q = "" } = await searchParams;
  const query = typeof q === "string" ? q.trim().slice(0, 120) : "", result = query.length >= 2 ? await searchAll(actor, query) : null;
  return <><h1>Globale Suche</h1><form className="search-form"><input name="q" aria-label="Suchbegriff" placeholder="Veranstaltung, Organisation, Person, Raum oder Datum (JJJJ-MM-TT)" defaultValue={query} minLength={2} maxLength={120} required /><button className="button">Suchen</button></form>{result && <><section className="panel"><h2>Veranstaltungen</h2>{result.events.map((e) => <p key={e.id}><Link href={`/events/${e.id}`}>{e.title} · {formatDate(e.start)}</Link></p>)}</section><section className="panel"><h2>Teilnehmer</h2>{result.participants.map((p) => <p key={p.id}><Link href={`/events/${p.eventId}/participants`}>{p.firstName} {p.lastName}</Link></p>)}</section><section className="panel"><h2>Organisationen & Ansprechpartner</h2>{result.organisations.map((o) => <p key={o.id}><Link href={`/organisations?q=${encodeURIComponent(o.name)}`}>{o.name}</Link></p>)}</section><section className="panel"><h2>Orte, Werkstätten & Gewerke</h2>{result.rooms.map((r) => <p key={r.id}><Link href="/locations">{r.name}</Link></p>)}</section><section className="panel"><h2>Mitarbeiter</h2>{result.employees.map((e) => <p key={e.id}><Link href="/employees">{e.firstName} {e.lastName}</Link></p>)}</section></>}</>;
}
