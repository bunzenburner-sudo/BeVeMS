"use server";
import { revalidatePath } from "next/cache";
import { z } from "zod";
import { pageActor } from "@/lib/page-access";
import { AccessError } from "@/domains/identity/policy";
import { DomainError } from "@/domains/planning/shared";
import { createEvent, updateEvent, changeStatus, acknowledgeReview } from "@/domains/planning/events";
import { addTask, setTaskStatus, addImpact, addSchedule, addResponsibility, removePlanningItem, reorderSchedule } from "@/domains/planning/work";
import { reserveRoom, cancelReservation, confirmReservation } from "@/domains/reservations/service";
import { addParticipant, setInvitation, checkIn, issueCheckInToken, linkOrganisation, addParticipantGroup, removeParticipant } from "@/domains/participants/service";
import { addVendor, copyEvent, createSeries, saveLessons, saveTemplate, instantiateTemplate } from "@/domains/history/service";
import { suggestWorkshops } from "@/domains/reservations/matching";
import { manageRecord, manageRole } from "@/domains/administration/manage";
import { manageOrganisation, addContact } from "@/domains/organisations/service";
import { updateCommunication, markRead, retryDelivery } from "@/domains/notifications/service";
export type ActionResult = { error?: string; success?: string; href?: string; token?: string; suggestions?: Awaited<ReturnType<typeof suggestWorkshops>> };
export async function mutate(_previous: ActionResult, form: FormData): Promise<ActionResult> {
  const actor = await pageActor();
  const s = (key: string) => String(form.get(key) ?? "");
  const all = (key: string) => form.getAll(key).map(String).filter(Boolean);
  const eventId = s("eventId"), operation = s("operation");
  const data = Object.fromEntries(form.entries());
  try {
    let href: string | undefined, token: string | undefined;
    switch (operation) {
      case "event.create": href = `/events/${await createEvent(actor, { ...data, audienceIds: all("audienceIds"), tradeIds: all("tradeIds") })}`; break;
      case "event.update": await updateEvent(actor, eventId, { ...data, audienceIds: all("audienceIds"), tradeIds: all("tradeIds") }, z.coerce.number().int().min(1).parse(s("version"))); break;
      case "event.review": await acknowledgeReview(actor, eventId, s("confirmed") === "on"); break;
      case "event.status": await changeStatus(actor, eventId, s("statusId")); break;
      case "task.add": await addTask(actor, eventId, { ...data, critical: s("critical") === "on" }); break;
      case "task.status": await setTaskStatus(actor, eventId, s("id"), s("status")); break;
      case "impact.add": await addImpact(actor, eventId, { ...data, groupIds: all("groupIds") }); break;
      case "schedule.add": await addSchedule(actor, eventId, data); break;
      case "schedule.reorder": await reorderSchedule(actor, eventId, all("ids")); break;
      case "responsibility.add": await addResponsibility(actor, eventId, s("employeeId"), s("areaId")); break;
      case "item.remove": await removePlanningItem(actor, eventId, s("kind"), s("id")); break;
      case "reservation.add": await reserveRoom(actor, eventId, { ...data, instructorIds: all("instructorIds"), localOnlyAcknowledged: s("localOnlyAcknowledged") === "on" }); break;
      case "reservation.confirm": await confirmReservation(actor, eventId, s("id"), s("acknowledge") === "on"); break;
      case "reservation.cancel": await cancelReservation(actor, eventId, s("id")); break;
      case "organisation.link": await linkOrganisation(actor, eventId, data); break;
      case "participant.group": await addParticipantGroup(actor, eventId, data); break;
      case "contact.add": await addContact(actor, data); break;
      case "participant.remove": await removeParticipant(actor, eventId, s("id"), s("confirmed") === "on"); break;
      case "participant.add": await addParticipant(actor, eventId, data); break;
      case "invitation.status": await setInvitation(actor, eventId, s("id"), s("status")); break;
      case "participant.checkin": await checkIn(actor, eventId, { participantId: s("id"), token: s("token") }); break;
      case "participant.qr": token = await issueCheckInToken(actor, eventId, s("id")); break;
      case "event.copy": href = `/events/${await copyEvent(actor, eventId, data)}`; break;
      case "event.series": href = `/events/${await createSeries(actor, eventId, data)}`; break;
      case "template.save": await saveTemplate(actor, eventId, s("name")); break;
      case "template.use": href = `/events/${await instantiateTemplate(actor, s("id"), s("start"))}`; break;
      case "lessons.save": await saveLessons(actor, eventId, data); break;
      case "vendor.add": await addVendor(actor, eventId, data); break;
      case "workshop.suggest": return { suggestions: await suggestWorkshops(actor, { ...data, tradeIds: all("tradeIds"), alternativeLanguageIds: all("alternativeLanguageIds") }) };
      case "admin.save": await manageRecord(actor, s("kind"), s("id"), { ...data, active: s("active") === "on", accessible: s("accessible") === "on" }); break;
      case "admin.role": await manageRole(actor, data, all("grants")); break;
      case "organisation.save": await manageOrganisation(actor, data); break;
      case "communication.save": await updateCommunication(actor, eventId, { recipients: s("recipients"), calendar: s("calendar") === "on" }); break;
      case "communication.retry": await retryDelivery(actor, s("id"), s("confirmed") === "on"); break;
      case "notification.read": await markRead(actor, s("id")); break;
      default: throw new DomainError("Unbekannte Aktion.");
    }
    revalidatePath("/", "layout");
    return { success: "Gespeichert.", href, token };
  } catch (e) {
    if (e instanceof AccessError) return { error: "Keine Berechtigung oder Eintrag nicht sichtbar." };
    if (e instanceof DomainError) return { error: e.message };
    if (e instanceof z.ZodError) return { error: `Bitte die Eingaben prüfen: ${e.issues.slice(0, 3).map((i) => `${i.path.join(".")}: ${i.message}`).join("; ")}` };
    console.error("Mutation failed", { operation, code: e && typeof e === "object" && "code" in e ? e.code : "INTERNAL" });
    return { error: "Speichern fehlgeschlagen. Bitte Referenzen prüfen und die Seite neu laden." };
  }
}
