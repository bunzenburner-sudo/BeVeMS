import { requireActor } from "@/domains/identity/actor";
import { listEvents } from "@/domains/events/service";
import { authorizedResponse } from "@/lib/http";
export const dynamic = "force-dynamic";
export function GET() { return authorizedResponse(async () => listEvents(await requireActor())); }
