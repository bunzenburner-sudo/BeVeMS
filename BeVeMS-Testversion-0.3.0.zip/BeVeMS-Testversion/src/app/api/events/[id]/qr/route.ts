import { sameOriginRequest } from "@/lib/csrf";
import { boundedBody } from "@/lib/request-body";
import { createHash } from "node:crypto";
import QRCode from "qrcode";
import { db } from "@/lib/db";
import { currentActor } from "@/domains/identity/actor";
import { eventMutation } from "@/domains/planning/shared";
import { AccessError } from "@/domains/identity/policy";
export async function POST(request: Request, { params }: { params: Promise<{ id: string }> }) {
  const actor = await currentActor(); if (!actor) return new Response(null, { status: 401 });
  if (!sameOriginRequest(request)) return new Response(null, { status: 403 });
  if (Number(request.headers.get("content-length") ?? 0) > 1000) return new Response(null, { status: 413 });
  const body = await boundedBody(request, 1000).then((data) => JSON.parse(new TextDecoder().decode(data))).catch(() => null);
  const token = typeof body?.token === "string" ? body.token : null; if (!token || !/^[\w-]{43}$/.test(token)) return new Response(null, { status: 400 });
  try { const { id } = await params;
    const valid = await eventMutation(actor, id, "participant.checkin", async (tx) => tx.eventParticipant.count({ where: { eventId: id, qrTokenHash: createHash("sha256").update(token).digest("hex"), registrationStatus: "REGISTERED", eventInvitation_participant: { status: "ACCEPTED" } } }));
    if (!valid) return new Response(null, { status: 404 });
    return new Response(await QRCode.toString(token, { type: "svg", errorCorrectionLevel: "M", margin: 4 }), { headers: { "Content-Type": "image/svg+xml", "Cache-Control": "private, no-store", "Referrer-Policy": "no-referrer", "Content-Security-Policy": "default-src 'none'; style-src 'unsafe-inline'; sandbox" } });
  } catch (e) { return new Response(null, { status: e instanceof AccessError ? e.status : 400 }); }
}
