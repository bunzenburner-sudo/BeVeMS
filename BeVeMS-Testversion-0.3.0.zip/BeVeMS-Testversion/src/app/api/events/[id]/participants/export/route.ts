import { currentActor } from "@/domains/identity/actor";
import { exportParticipants } from "@/domains/participants/service";
import { AccessError } from "@/domains/identity/policy";
export async function GET(_request: Request, { params }: { params: Promise<{ id: string }> }) {
  const actor = await currentActor(); if (!actor) return new Response(null, { status: 401 });
  try { const { id } = await params; const csv = await exportParticipants(actor, id); return new Response(csv, { headers: { "Content-Type": "text/csv; charset=utf-8", "Content-Disposition": 'attachment; filename="teilnehmer.csv"', "Cache-Control": "private, no-store" } }); }
  catch (e) { if (e instanceof AccessError) return new Response(null, { status: e.status }); return new Response(null, { status: 400 }); }
}
