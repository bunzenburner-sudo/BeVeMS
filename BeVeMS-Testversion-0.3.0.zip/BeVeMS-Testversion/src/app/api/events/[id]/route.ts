import { requireActor } from "@/domains/identity/actor";
import { eventDetail } from "@/domains/events/service";
import { authorizedResponse } from "@/lib/http";
export function GET(_request: Request, context: { params: Promise<{ id: string }> }) {
  return authorizedResponse(async () => eventDetail(await requireActor(), (await context.params).id));
}
