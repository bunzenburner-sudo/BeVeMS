import { sameOriginRequest } from "@/lib/csrf";
import { boundedBody, BodyLimitError } from "@/lib/request-body";
import { eventMutation } from "@/domains/planning/shared";
import { currentActor } from "@/domains/identity/actor";
import { AccessError } from "@/domains/identity/policy";
import { uploadDocument, maxDocumentSize } from "@/domains/documents/service";
export async function POST(request: Request, { params }: { params: Promise<{ id: string }> }) {
  const actor = await currentActor(); if (!actor) return Response.json({ error: "Nicht angemeldet." }, { status: 401 });
  if (!sameOriginRequest(request)) return new Response(null, { status: 403 });
  const length = Number(request.headers.get("content-length")); if (length > maxDocumentSize + 65536) return Response.json({ error: "Datei zu groß (maximal 10 MiB)." }, { status: 413 });
  try {
    const { id } = await params; await eventMutation(actor, id, "event.edit", async () => {}); const bytes = await boundedBody(request, maxDocumentSize + 65536);
    const form = await new Response(Buffer.from(bytes), { headers: { "Content-Type": request.headers.get("content-type") ?? "" } }).formData(); const file = form.get("file");
    if (!(file instanceof File) || file.size > maxDocumentSize) return new Response(null, { status: 400 });
    await uploadDocument(actor, id, file.name, new Uint8Array(await file.arrayBuffer())); return Response.json({ success: true }, { headers: { "Cache-Control": "no-store" } });
  } catch (e) { return Response.json({ error: "Upload nicht möglich. Bitte Berechtigung, Dateiformat und Sicherheitsprüfung beachten." }, { status: e instanceof BodyLimitError ? 413 : e instanceof AccessError ? e.status : 400 }); }
}
