import { currentActor } from "@/domains/identity/actor";
import { AccessError } from "@/domains/identity/policy";
import { downloadDocument } from "@/domains/documents/service";
export async function GET(_request: Request, { params }: { params: Promise<{ id: string; documentId: string }> }) {
  const actor = await currentActor(); if (!actor) return new Response(null, { status: 401 });
  try { const { id, documentId } = await params; const doc = await downloadDocument(actor, id, documentId); return new Response(Buffer.from(doc.data), { headers: { "Content-Type": doc.mimeType, "Content-Disposition": `attachment; filename*=UTF-8''${encodeURIComponent(doc.name)}`, "Cache-Control": "private, no-store", "X-Content-Type-Options": "nosniff" } }); }
  catch (e) { return new Response(null, { status: e instanceof AccessError ? e.status : 400 }); }
}
