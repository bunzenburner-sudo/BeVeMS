import { db } from "@/lib/db";
export const dynamic = "force-dynamic";
export async function GET() {
  try {
    // Touch application tables, not only a database socket.
    await db.eventType.count();
    return Response.json({ status: "ok" }, { headers: { "Cache-Control": "no-store" } });
  } catch {
    return Response.json({ status: "unavailable" }, { status: 503, headers: { "Cache-Control": "no-store" } });
  }
}
