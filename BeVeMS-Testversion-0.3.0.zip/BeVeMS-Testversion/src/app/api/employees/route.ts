import { requireActor } from "@/domains/identity/actor";
import { listEmployees } from "@/domains/employees/service";
import { authorizedResponse } from "@/lib/http";
export function GET() { return authorizedResponse(async () => listEmployees(await requireActor())); }
