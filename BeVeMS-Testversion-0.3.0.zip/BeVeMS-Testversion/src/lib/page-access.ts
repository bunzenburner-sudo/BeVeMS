import { notFound, redirect } from "next/navigation";
import { currentActor } from "@/domains/identity/actor";
import { AccessError } from "@/domains/identity/policy";
export async function pageActor() {
  const actor = await currentActor();
  if (!actor) redirect("/login");
  return actor;
}
export async function pageResult<T>(operation: () => Promise<T>): Promise<T> {
  try { return await operation(); }
  catch (error) { if (error instanceof AccessError) notFound(); throw error; }
}
