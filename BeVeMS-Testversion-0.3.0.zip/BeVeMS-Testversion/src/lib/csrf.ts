// Reverse proxies must preserve Host (or configure a canonical APP_BASE_URL).
export function sameOriginRequest(request: Request) {
  const origin = request.headers.get("origin"); if (!origin) return false;
  try {
    const supplied = new URL(origin);
    if (!["http:", "https:"].includes(supplied.protocol) || supplied.origin !== origin) return false;
    if (process.env.NODE_ENV === "production" && supplied.protocol !== "https:") return false;
    const canonical = process.env.APP_BASE_URL;
    return canonical ? supplied.origin === new URL(canonical).origin : supplied.host.toLowerCase() === request.headers.get("host")?.toLowerCase();
  } catch { return false; }
}
