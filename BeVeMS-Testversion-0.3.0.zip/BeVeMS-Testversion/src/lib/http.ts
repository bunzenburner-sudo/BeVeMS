import { NextResponse } from "next/server";
import { AccessError } from "@/domains/identity/policy";

export async function authorizedResponse(operation: () => Promise<unknown>) {
  try {
    return NextResponse.json(await operation(), { headers: { "Cache-Control": "private, no-store" } });
  } catch (error) {
    if (error instanceof AccessError) return NextResponse.json({ error: error.status === 401 ? "Anmeldung erforderlich" : "Nicht verfügbar" }, { status: error.status, headers: { "Cache-Control": "no-store" } });
    console.error("BeVeMS request failed", error instanceof Error ? error.name : "UnknownError");
    return NextResponse.json({ error: "Die Anfrage konnte nicht verarbeitet werden." }, { status: 500 });
  }
}
