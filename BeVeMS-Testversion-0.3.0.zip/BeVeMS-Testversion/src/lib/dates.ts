// All business wall times refer to Europe/Berlin, regardless of the browser's timezone.
export function berlinInput(date: Date | string) {
  const parts = Object.fromEntries(new Intl.DateTimeFormat("sv-SE", { timeZone: "Europe/Berlin", year: "numeric", month: "2-digit", day: "2-digit", hour: "2-digit", minute: "2-digit", hourCycle: "h23" }).formatToParts(new Date(date)).map((p) => [p.type, p.value]));
  return `${parts.year}-${parts.month}-${parts.day}T${parts.hour}:${parts.minute}`;
}
export function berlinToIso(value: string): string {
  if (!/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}$/.test(value)) return "";
  const wall = Date.parse(`${value}:00Z`);
  const candidates = [new Date(wall - 3600000), new Date(wall - 7200000)].filter((d) => berlinInput(d) === value);
  // DST fold/gap is deliberately rejected rather than silently choosing an instant.
  return candidates.length === 1 ? candidates[0].toISOString() : "";
}
export function formatDate(value: Date | string) { return new Intl.DateTimeFormat("de-DE", { dateStyle: "medium", timeStyle: "short", timeZone: "Europe/Berlin" }).format(new Date(value)); }
