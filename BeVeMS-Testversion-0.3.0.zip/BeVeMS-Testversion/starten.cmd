@echo off
setlocal
cd /d "%~dp0"
node tools\test-demo.cjs
if errorlevel 1 (
  echo.
  echo Bitte HIER-STARTEN.txt beachten.
  pause
)
